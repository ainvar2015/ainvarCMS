-- Backup AinvarCMS
-- Fecha: 2026-10-15 11:40:44

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `catalog_categories`;
CREATE TABLE `catalog_categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `catalog_categories` (`id`, `name`, `slug`, `description`, `image`, `sort_order`, `active`, `created_at`, `updated_at`) VALUES
('1', 'General', 'general', 'Categoría genérica', NULL, '0', '1', '2026-09-04 09:09:46', '2026-09-04 09:09:46'),
('2', 'Informática', 'informatica', 'Material de informática y electrónica', NULL, '0', '1', '2026-09-12 18:03:47', '2026-09-12 18:03:47');

DROP TABLE IF EXISTS `catalog_category_translations`;
CREATE TABLE `catalog_category_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned NOT NULL,
  `lang` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_id_lang` (`category_id`,`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `catalog_products`;
CREATE TABLE `catalog_products` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `sku` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `short_desc` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price_old` decimal(10,2) DEFAULT NULL,
  `stock` int NOT NULL DEFAULT '0',
  `image_main` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `images_gallery` json DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `meta_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `meta_desc` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category_id` (`category_id`),
  KEY `active` (`active`),
  KEY `featured` (`featured`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `catalog_products` (`id`, `category_id`, `name`, `slug`, `sku`, `description`, `short_desc`, `price`, `price_old`, `stock`, `image_main`, `images_gallery`, `featured`, `active`, `meta_title`, `meta_desc`, `created_at`, `updated_at`) VALUES
('1', '2', 'Ratón inalámbrico', 'raton-inalambrico', '', 'Ratón inalámbrico de alta calidad, se puede conectar por radio o por bluetooth', 'Ratón inalámbrico para PC', '35.00', '33.00', '5', 'uploads/catalog/1791104808_653eca50784935abf5f1.jpg', NULL, '0', '1', '', '', '2026-09-04 09:12:37', '2026-10-04 09:06:48'),
('2', '2', 'Teclado inalámbrico', 'teclado-inalambrico', '', '', 'Teclado por infrarrojos', '95.00', '105.00', '3', 'uploads/catalog/1791104822_5b8f66c90474a25b2fa9.jpg', NULL, '1', '1', '', '', '2026-09-12 17:59:26', '2026-10-04 09:12:58');

DROP TABLE IF EXISTS `cookie_consents`;
CREATE TABLE `cookie_consents` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `necessary` tinyint(1) NOT NULL DEFAULT '1',
  `analytics` tinyint(1) NOT NULL DEFAULT '0',
  `marketing` tinyint(1) NOT NULL DEFAULT '0',
  `language` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `user_agent` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT '',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `token` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `cookie_consents` (`id`, `token`, `necessary`, `analytics`, `marketing`, `language`, `user_agent`, `created_at`) VALUES
('1', 'a792b89ff6834fc7b75cfc26e60290af', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-20 15:38:19'),
('2', '0e8a6dc0216a2cd676299b20a6d3deb0', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-20 15:45:21'),
('3', 'f0297598e0089ae5cfeff092e81ccad3', '1', '1', '1', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-20 15:46:31'),
('4', '3a084da478fc6a84302351fd5e6e8714', '1', '1', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-23 09:40:10'),
('5', 'e5478cad2f17a0d2871d9d8066812713', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-29 19:18:26'),
('6', 'e5478cad2f17a0d2871d9d8066812713', '1', '1', '1', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-30 13:40:30'),
('7', 'e5478cad2f17a0d2871d9d8066812713', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-30 13:41:00'),
('8', 'e5478cad2f17a0d2871d9d8066812713', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-30 13:41:14'),
('9', 'e5478cad2f17a0d2871d9d8066812713', '1', '1', '1', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-30 13:41:23'),
('10', 'e5478cad2f17a0d2871d9d8066812713', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-30 18:16:04'),
('11', 'e5478cad2f17a0d2871d9d8066812713', '1', '1', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-30 18:16:29'),
('12', 'e5478cad2f17a0d2871d9d8066812713', '1', '1', '1', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-30 18:24:26'),
('13', 'e5478cad2f17a0d2871d9d8066812713', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0', '2026-09-30 18:24:43'),
('14', 'e5478cad2f17a0d2871d9d8066812713', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0', '2026-10-01 13:21:22'),
('15', 'e5478cad2f17a0d2871d9d8066812713', '1', '1', '1', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0', '2026-10-01 13:21:29'),
('16', 'e5478cad2f17a0d2871d9d8066812713', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0', '2026-10-01 13:25:13'),
('17', 'e5478cad2f17a0d2871d9d8066812713', '1', '1', '1', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0', '2026-10-01 13:26:31'),
('18', '5132c37d9b856330c4d0c8ffac1d8453', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0', '2026-10-01 13:52:41'),
('19', '6c2d906eb4f86c4edf13f9fac2f22a04', '1', '0', '0', 'es', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0', '2026-10-04 12:51:19');

DROP TABLE IF EXISTS `faq_categories`;
CREATE TABLE `faq_categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `position` int NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `faq_category_translations`;
CREATE TABLE `faq_category_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned NOT NULL,
  `language` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_id_language` (`category_id`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `faq_translations`;
CREATE TABLE `faq_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `faq_id` int unsigned NOT NULL,
  `language` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `pregunta` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `respuesta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `faq_id_language` (`faq_id`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `faqs`;
CREATE TABLE `faqs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned DEFAULT NULL,
  `position` int NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `form_entries`;
CREATE TABLE `form_entries` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int unsigned NOT NULL,
  `data` json DEFAULT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `form_fields`;
CREATE TABLE `form_fields` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int unsigned NOT NULL,
  `label` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `type` enum('text','email','textarea','select','checkbox','number','date') CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `options` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `form_submissions`;
CREATE TABLE `form_submissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int unsigned NOT NULL,
  `page_slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `data` json NOT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `form_submissions` (`id`, `page_id`, `page_slug`, `data`, `ip_address`, `user_agent`, `read`, `created_at`, `updated_at`) VALUES
('1', '4', 'contactar', '{\"nombre\": \"Manuel\", \"telefono\": \"653103722\", \"direccion\": \"Avenida de Madrid 7-6ºB\", \"poblacion\": \"Lugo\", \"provincia\": \"Lugo\", \"cod_postal\": \"27002\", \"observaciones\": \"Que voy observando poco a poco\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0', '1', '2026-09-16 14:50:55', '2026-09-16 14:51:20'),
('2', '9', 'contacto', '{\"nombre\": \"Manuel\", \"telefono\": \"653103722\", \"direccion\": \"Avenida de Madrid 7-6ºB\", \"poblacion\": \"Lugo\", \"provincia\": \"Lugo\", \"cod_postal\": \"27002\", \"observaciones\": \"ldknvclsdknvclk nlak na\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '1', '2026-09-20 14:51:33', '2026-09-20 14:51:43'),
('3', '9', 'contacto', '{\"nombre\": \"Manuel\", \"telefono\": \"653103722\", \"direccion\": \"Avenida de Madrid 7-6ºB\", \"poblacion\": \"Lugo\", \"provincia\": \"Lugo\", \"cod_postal\": \"27002\", \"observaciones\": \"Estaba yo aburrido, cuando de pronto observé una cosa muy interesante\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0', '1', '2026-09-22 14:51:54', '2026-10-03 12:53:27'),
('4', '9', 'contacto', '{\"nombre\": \"Manuel\", \"telefono\": \"653103722\", \"direccion\": \"Avenida de Madrid 7-6ºB\", \"poblacion\": \"Lugo\", \"provincia\": \"Lugo\", \"cod_postal\": \"27002\", \"observaciones\": \"lkhjbglbñ.lknl´ñk ni9on oj´`\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0', '1', '2026-10-01 14:52:15', '2026-10-03 12:53:07'),
('5', '9', 'contacto', '{\"nombre\": \"Manuel\", \"telefono\": \"653103722\", \"direccion\": \"Avda. Madrid, 7\", \"poblacion\": \"Lugo\", \"provincia\": \"Lugo\", \"cod_postal\": \"27002\", \"observaciones\": \"Observaciones\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0', '1', '2026-10-03 12:48:30', '2026-10-03 12:53:05');

DROP TABLE IF EXISTS `forms`;
CREATE TABLE `forms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `email_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `success_message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `gallery_album_translations`;
CREATE TABLE `gallery_album_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `album` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `lang` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `album_lang` (`album`,`lang`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `gallery_album_translations` (`id`, `album`, `lang`, `title`, `created_at`, `updated_at`) VALUES
('1', 'Principal', 'en', 'Main', '2026-09-13 13:32:28', '2026-09-13 13:32:28'),
('2', 'General', 'en', 'General', '2026-09-13 13:32:28', '2026-09-13 13:32:28'),
('3', 'Privado', 'en', 'Private', '2026-09-13 13:32:28', '2026-09-13 13:32:28');

DROP TABLE IF EXISTS `gallery_images`;
CREATE TABLE `gallery_images` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `album` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `album` (`album`),
  KEY `active` (`active`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `gallery_images` (`id`, `title`, `slug`, `description`, `album`, `file_path`, `sort_order`, `active`, `created_at`) VALUES
('1', 'slide-28-728', 'slide-28-728', '', 'General', 'uploads/media/1790863277_d2e90218a38c2cff8f9c.jpg', '0', '1', NULL),
('2', '2-Senecio-vulgaris', '2-senecio-vulgaris', '', 'General', 'uploads/gallery/1790761153_45929cc9b3f11493a619.jpg', '0', '1', NULL),
('3', '2Aerografito-ligero', '2aerografito-ligero', '', 'General', 'uploads/gallery/1790761153_3b7e4e76a8d4388ed5e4.jpg', '0', '1', NULL),
('4', '0DF', '0df', NULL, 'General', 'uploads/gallery/1791104911_3dfd0342f53a519a9993.jpg', '0', '1', NULL),
('5', '0EE', '0ee', NULL, 'General', 'uploads/gallery/1791104911_e430f8d6054fa4fcb96e.jpg', '0', '1', NULL),
('6', '2C2', '2c2', NULL, 'General', 'uploads/gallery/1791104911_2993d11d9ec99d3a84e3.jpg', '0', '1', NULL),
('7', '4B7', '4b7', NULL, 'General', 'uploads/gallery/1791104911_214410d26bbdde79ac90.jpg', '0', '1', NULL),
('8', '5CC', '5cc', NULL, 'General', 'uploads/gallery/1791104911_138d4423095dbd954002.png', '0', '1', NULL),
('9', '6DE', '6de', NULL, 'General', 'uploads/gallery/1791104911_5a3f6555c317c2895966.jpg', '0', '1', NULL),
('10', '6F4', '6f4', NULL, 'General', 'uploads/gallery/1791104911_dbf8f228cf59b2154e91.jpg', '0', '1', NULL),
('11', '9B2', '9b2', NULL, 'General', 'uploads/gallery/1791104911_e9b2de220d9be8e84a9f.jpg', '0', '1', NULL),
('12', '9B8', '9b8', NULL, 'General', 'uploads/gallery/1791104911_11961cd0ec5f70873b98.jpg', '0', '1', NULL),
('13', '16E', '16e', NULL, 'General', 'uploads/gallery/1791104911_532e9c7454f52cbe7e68.jpg', '0', '1', NULL),
('14', '28C', '28c', NULL, 'General', 'uploads/gallery/1791104911_9a16e0064a55a9151628.jpg', '0', '1', NULL),
('15', '44B', '44b', NULL, 'General', 'uploads/gallery/1791104911_1a7b0bbba74c559e5be9.jpg', '0', '1', NULL);

DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `flag` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `languages` (`id`, `code`, `name`, `flag`, `is_default`, `active`, `sort_order`) VALUES
('1', 'es', 'Español', '🇪🇸', '1', '1', '0');

DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `folder_id` int unsigned DEFAULT NULL,
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `original_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `size` int unsigned NOT NULL,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `alt_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `uploaded_by` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_folder_id_foreign` (`folder_id`),
  KEY `media_uploaded_by_foreign` (`uploaded_by`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `media` (`id`, `folder_id`, `file_path`, `original_name`, `mime_type`, `size`, `width`, `height`, `title`, `alt_text`, `uploaded_by`, `created_at`) VALUES
('1', '1', 'uploads/media/1788873374_c32d548d76c9ad3c42c4.jpg', '15178692_l.jpg', 'image/jpeg', '788486', '1672', '2508', NULL, NULL, '1', NULL),
('2', '1', 'uploads/media/1788873374_6312fbb318ab32e4d3f1.jpg', '30161557_l.jpg', 'image/jpeg', '813036', '1669', '2513', NULL, NULL, '1', NULL),
('3', '1', 'uploads/media/1788873374_89b55b8d3843a202621c.jpg', '11244816_l.jpg', 'image/jpeg', '488531', '2508', '1672', NULL, NULL, '1', NULL),
('4', '2', 'uploads/media/1788879005_6f1a445315d96aa6024a.jpg', '44700064_l.jpg', 'image/jpeg', '889771', '2520', '1665', NULL, NULL, '1', NULL),
('5', '2', 'uploads/media/1788879005_49f80ee5ef3d92a58b78.jpg', '45072221_l.jpg', 'image/jpeg', '250106', '2508', '1672', NULL, NULL, '1', NULL),
('6', '2', 'uploads/media/1788879005_05d338efa0e481915344.jpg', '34610527_l.jpg', 'image/jpeg', '308010', '2559', '1639', NULL, NULL, '1', NULL),
('7', NULL, 'uploads/gallery/1788437383_08798c9fe16962faf4e1.jpg', '11244816_l', 'image/jpeg', '488531', '2508', '1672', '11244816_l', '11244816_l', NULL, NULL),
('28', '1', 'uploads/media/1789730503_134b38bfeb9049a9aec1.png', '2026091800100443133.png', 'image/png', '1691514', '1280', '720', NULL, NULL, '1', NULL),
('9', NULL, 'uploads/gallery/1788437383_2a9e742c7c37eb1e086a.jpg', '30161557_l', 'image/jpeg', '813036', '1669', '2513', '30161557_l', '30161557_l', NULL, NULL),
('10', NULL, 'uploads/gallery/1788437383_5379f09064975f157502.jpg', '34610527_l', 'image/jpeg', '308010', '2559', '1639', '34610527_l', '34610527_l', NULL, NULL),
('11', NULL, 'uploads/gallery/1788437383_7df3136a4fa5eb16bc75.jpg', '44700064_l', 'image/jpeg', '889771', '2520', '1665', '44700064_l', '44700064_l', NULL, NULL),
('12', NULL, 'uploads/gallery/1788437383_df4ba35175a46fd3e2a3.jpg', '45072221_l', 'image/jpeg', '250106', '2508', '1672', '45072221_l', '45072221_l', NULL, NULL),
('13', NULL, 'uploads/gallery/1788437898_b0c08fb07900a1f306de.jpg', '1-hong-kong', 'image/jpeg', '153548', '800', '600', '1-hong-kong', '1-hong-kong', NULL, NULL),
('14', NULL, 'uploads/gallery/1788437898_f9919f7e97849317da91.jpg', '2-nyc', 'image/jpeg', '155228', '800', '600', '2-nyc', '2-nyc', NULL, NULL),
('15', NULL, 'uploads/gallery/1788437898_c931f83f3eea5256f0a5.jpg', '3-mex', 'image/jpeg', '142312', '800', '600', '3-mex', '3-mex', NULL, NULL),
('16', NULL, 'uploads/gallery/1788437898_0238f354f6e7bbeb0966.jpg', '4-prague', 'image/jpeg', '164595', '800', '600', '4-prague', '4-prague', NULL, NULL),
('17', NULL, 'uploads/gallery/1788437898_793a575fb38a8b0e16a9.png', '5-venice', 'image/png', '1677378', '800', '800', '5-venice', '5-venice', NULL, NULL),
('18', NULL, 'uploads/gallery/1788437898_287d40196258353efa05.jpg', '6-vancouv', 'image/jpeg', '130325', '800', '600', '6-vancouv', '6-vancouv', NULL, NULL),
('19', NULL, 'uploads/gallery/1788438738_72ca9faa0184c0e16475.jpeg', 'GHw_pBLWsAATqu0', 'image/jpeg', '55878', '451', '683', 'GHw_pBLWsAATqu0', 'GHw_pBLWsAATqu0', NULL, NULL),
('20', NULL, 'uploads/gallery/1788438738_8695b233fdfa0c4b3b45.jpeg', 'GHw_yqtXgAAaA8h', 'image/jpeg', '88804', '700', '466', 'GHw_yqtXgAAaA8h', 'GHw_yqtXgAAaA8h', NULL, NULL),
('21', NULL, 'uploads/gallery/1788438738_70cc2bcfe828f65c0df6.jpeg', 'GHw0dCYXoAAbIBJ', 'image/jpeg', '79589', '720', '900', 'GHw0dCYXoAAbIBJ', 'GHw0dCYXoAAbIBJ', NULL, NULL),
('22', NULL, 'uploads/gallery/1789131169_523aa10ba7c7b2374fa9.jpeg', 'GHw_pBLWsAATqu0.jpeg', 'image/jpeg', '55878', '451', '683', 'GHw_pBLWsAATqu0', 'GHw_pBLWsAATqu0', '1', NULL),
('29', '1', 'uploads/media/1789820474_d1b6d1610db047adf3f4.jpg', '6aad4d11562c2.r_d.949-561-5156.jpg', 'image/jpeg', '209471', '990', '557', '', '', '1', NULL),
('24', NULL, 'uploads/gallery/1789131169_781854c83b4457c917b7.jpeg', 'GHw0dCYXoAAbIBJ.jpeg', 'image/jpeg', '79589', '720', '900', 'GHw0dCYXoAAbIBJ', 'GHw0dCYXoAAbIBJ', '1', NULL),
('25', NULL, 'uploads/gallery/1789131169_3a71b40d40b05f30faf5.jpeg', 'GHw1BPqX0AA9ibP.jpeg', 'image/jpeg', '87962', '613', '900', 'GHw1BPqX0AA9ibP', 'GHw1BPqX0AA9ibP', '1', NULL),
('26', NULL, 'uploads/gallery/1789131169_3f6598a250cf7added8a.jpeg', 'GHw1iI9WMAAMIXU.jpeg', 'image/jpeg', '200263', '900', '900', 'GHw1iI9WMAAMIXU', 'GHw1iI9WMAAMIXU', '1', NULL),
('27', NULL, 'uploads/gallery/1789131169_8f125a24912afd0762a7.jpeg', 'GHw1L1kW4AAzGWZ.jpeg', 'image/jpeg', '45486', '800', '534', 'GHw1L1kW4AAzGWZ', 'GHw1L1kW4AAzGWZ', '1', NULL),
('30', '1', 'uploads/media/1789823103_c1614d16e321ab28c9ce.jpg', '6aad4d11562c2.r_d.949-561-5156.jpg', 'image/jpeg', '209471', '990', '557', NULL, NULL, '1', NULL),
('31', '1', 'uploads/media/1789823109_1549490e1c932b2acc2f.png', '6aad71edae87a.png', 'image/png', '2209924', '990', '557', NULL, NULL, '1', NULL),
('32', NULL, 'uploads/media/1789837270_97a695e3bf4e369a3c02.jpg', 'Fotos-tomadas-en-el-momento-justo-11.jpg', 'image/jpeg', '19800', '744', '400', NULL, NULL, '1', NULL),
('57', NULL, 'uploads/media/1790863277_d2e90218a38c2cff8f9c.jpg', 'slide-28-728.jpg', 'image/jpeg', '162695', '728', '546', NULL, NULL, '1', NULL),
('34', '1', 'uploads/media/1790759881_d905a4115a3651f5621a.jpg', '6A8.jpg', 'image/jpeg', '32033', '660', '371', NULL, NULL, '1', NULL),
('35', '2', 'uploads/media/1790759893_83f053254a52e8c6f3a3.jpg', '3-Volvox2-x100-DIC-JM-Babalian.jpg', 'image/jpeg', '133730', '640', '576', NULL, NULL, '1', NULL),
('36', NULL, 'uploads/media/1790760038_e9fd013b49eb1da36b14.jpg', '0k0029_punta_cabello_microscopico.jpg', 'image/jpeg', '42577', '520', '388', NULL, NULL, '1', NULL),
('37', NULL, 'uploads/media/1790760062_9676323109ab6d3f2616.jpg', '4-SmallWorld2.jpg', 'image/jpeg', '93111', '640', '640', NULL, NULL, '1', NULL),
('38', NULL, 'uploads/gallery/1790760170_7d53bd0f9aa04fc79826.jpeg', 'IMG_20220518_100554-aiedited-20260923202743.jpeg', 'image/jpeg', '524539', '1024', '1536', 'IMG_20220518_100554-aiedited-20260923202743', 'IMG_20220518_100554-aiedited-20260923202743', '1', NULL),
('39', NULL, 'uploads/gallery/1790761109_08fdcb003e7317de39a3.jpg', 'Fotos-tomadas-en-el-momento-justo-14.jpg', 'image/jpeg', '41950', '737', '709', 'Fotos-tomadas-en-el-momento-justo-14', 'Fotos-tomadas-en-el-momento-justo-14', '1', NULL),
('40', NULL, 'uploads/gallery/1790761153_aaf2f520f9ba1368f136.jpg', '0k0029_punta_cabello_microscopico.jpg', 'image/jpeg', '42577', '520', '388', '0k0029_punta_cabello_microscopico', '0k0029_punta_cabello_microscopico', '1', NULL),
('41', NULL, 'uploads/gallery/1790761153_f7fec4d54f1329064812.jpg', '1-HaCaT_cells.jpg', 'image/jpeg', '271811', '640', '640', '1-HaCaT_cells', '1-HaCaT_cells', '1', NULL),
('42', NULL, 'uploads/gallery/1790761153_0c2e6a690243f96ec9a2.jpg', '2a938138-3747-4b37-b751-9b7e00b40e34_insectos-4.jpg', 'image/jpeg', '74026', '630', '423', '2a938138-3747-4b37-b751-9b7e00b40e34_insectos-4', '2a938138-3747-4b37-b751-9b7e00b40e34_insectos-4', '1', NULL),
('43', NULL, 'uploads/gallery/1790761153_3b7e4e76a8d4388ed5e4.jpg', '2Aerografito-ligero.jpg', 'image/jpeg', '33987', '500', '328', '2Aerografito-ligero', '2Aerografito-ligero', '1', NULL),
('44', NULL, 'uploads/gallery/1790761153_45929cc9b3f11493a619.jpg', '2-Senecio-vulgaris.jpg', 'image/jpeg', '85581', '640', '400', '2-Senecio-vulgaris', '2-Senecio-vulgaris', '1', NULL),
('45', '4', 'uploads/media/1790762241_f08df860d5acfce6032a.jpg', '8-P4_Rat_Cochlea.jpg', 'image/jpeg', '100466', '640', '638', NULL, NULL, '1', NULL),
('46', '4', 'uploads/media/1790762241_9de6d32c57c4ae72eda9.jpg', '9-christmas_tree.jpg', 'image/jpeg', '69224', '640', '592', NULL, NULL, '1', NULL),
('47', '4', 'uploads/media/1790762242_dde68cf677c00468fbe1.jpg', '10-Phyllobius-roboretanus-(4-5--mm),-2,2x.-.jpg', 'image/jpeg', '98698', '543', '640', NULL, NULL, '1', NULL),
('48', '4', 'uploads/media/1790762242_3690e9cf8b247b2b5f29.jpg', '11-CREDIT-CARD-1-E10-AT-160X-FINAL-CONTEST.jpg', 'image/jpeg', '143720', '640', '427', NULL, NULL, '1', NULL),
('49', '4', 'uploads/media/1790762242_bb8d152ada28fa1b2105.jpg', '12-Krebs_1_NSW2017.jpg', 'image/jpeg', '61306', '640', '427', NULL, NULL, '1', NULL),
('50', '4', 'uploads/media/1790762242_e35a2579dfbca5b76268.jpg', '13-Orchid-Cuckoo-Bee_Side-View.jpg', 'image/jpeg', '54574', '640', '427', NULL, NULL, '1', NULL),
('51', '4', 'uploads/media/1790762242_8cf8323913d5df1f4b6c.jpg', '14-NikMestraTwo.jpg', 'image/jpeg', '93265', '640', '480', NULL, NULL, '1', NULL),
('52', '4', 'uploads/media/1790762242_4e1c647df29b21340160.jpg', '15-AdamsRA_Megaloglossus_woermanni.jpg', 'image/jpeg', '57999', '487', '640', NULL, NULL, '1', NULL),
('53', '4', 'uploads/media/1790762242_9db1e28ca18a1185d6f4.jpg', '72E.jpg', 'image/jpeg', '51787', '624', '351', NULL, NULL, '1', NULL),
('54', '4', 'uploads/media/1790762242_6e9401480cb82cd43879.jpg', '77B.jpg', 'image/jpeg', '77637', '624', '351', NULL, NULL, '1', NULL),
('55', '4', 'uploads/media/1790762243_b84f8fd3d4591df25ee0.jpg', '81D.jpg', 'image/jpeg', '42194', '624', '351', NULL, NULL, '1', NULL),
('56', '4', 'uploads/media/1790762243_0cbfd28a3f232c750d80.jpg', 'BC3.jpg', 'image/jpeg', '38758', '624', '351', NULL, NULL, '1', NULL),
('58', NULL, 'uploads/gallery/1791104911_3dfd0342f53a519a9993.jpg', '0DF.jpg', 'image/jpeg', '52924', '640', '434', '0DF', '0DF', '1', NULL),
('59', NULL, 'uploads/gallery/1791104911_e430f8d6054fa4fcb96e.jpg', '0EE.jpg', 'image/jpeg', '189526', '880', '1109', '0EE', '0EE', '1', NULL),
('60', NULL, 'uploads/gallery/1791104911_2993d11d9ec99d3a84e3.jpg', '2C2.jpg', 'image/jpeg', '129246', '880', '587', '2C2', '2C2', '1', NULL),
('61', NULL, 'uploads/gallery/1791104911_214410d26bbdde79ac90.jpg', '4B7.jpg', 'image/jpeg', '165571', '880', '560', '4B7', '4B7', '1', NULL),
('62', NULL, 'uploads/gallery/1791104911_138d4423095dbd954002.png', '5CC.png', 'image/png', '531455', '730', '483', '5CC', '5CC', '1', NULL),
('63', NULL, 'uploads/gallery/1791104911_5a3f6555c317c2895966.jpg', '6DE.jpg', 'image/jpeg', '104558', '880', '550', '6DE', '6DE', '1', NULL),
('64', NULL, 'uploads/gallery/1791104911_dbf8f228cf59b2154e91.jpg', '6F4.jpg', 'image/jpeg', '127728', '880', '880', '6F4', '6F4', '1', NULL),
('65', NULL, 'uploads/gallery/1791104911_e9b2de220d9be8e84a9f.jpg', '9B2.jpg', 'image/jpeg', '81257', '467', '700', '9B2', '9B2', '1', NULL),
('66', NULL, 'uploads/gallery/1791104911_11961cd0ec5f70873b98.jpg', '9B8.jpg', 'image/jpeg', '151017', '880', '1078', '9B8', '9B8', '1', NULL),
('67', NULL, 'uploads/gallery/1791104911_532e9c7454f52cbe7e68.jpg', '16E.jpg', 'image/jpeg', '79967', '449', '700', '16E', '16E', '1', NULL),
('68', NULL, 'uploads/gallery/1791104911_9a16e0064a55a9151628.jpg', '28C.jpg', 'image/jpeg', '123334', '880', '584', '28C', '28C', '1', NULL),
('69', NULL, 'uploads/gallery/1791104911_1a7b0bbba74c559e5be9.jpg', '44B.jpg', 'image/jpeg', '50526', '880', '587', '44B', '44B', '1', NULL),
('70', '1', 'uploads/media/1791192063_5d07f10bc1fe16385eec.jpeg', '6ac362e4f2f19.jpeg', 'image/jpeg', '317629', '990', '557', NULL, NULL, '1', NULL),
('71', NULL, 'uploads/media/1791204248_1ff1ecb12c5bcf4c10b0.jpeg', '6ac362e4f2f19.jpeg', 'image/jpeg', '317629', '990', '557', NULL, NULL, '1', NULL),
('72', NULL, 'uploads/media/1791206746_df9fc04b79ce03851f47.jpeg', '698880a35da10.jpeg', 'image/jpeg', '106688', '990', '557', NULL, NULL, '1', NULL),
('73', NULL, 'uploads/media/1791207021_92fa2b4c3794d1364a17.jpeg', '6ac340dd896aa.jpeg', 'image/jpeg', '158706', '990', '557', NULL, NULL, '1', NULL);

DROP TABLE IF EXISTS `media_folders`;
CREATE TABLE `media_folders` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `parent_id` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_folders_parent_id_foreign` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `media_folders` (`id`, `name`, `parent_id`, `created_at`) VALUES
('1', 'Pruebas', NULL, NULL),
('2', 'Interna', '1', NULL),
('4', 'Microfotografias', NULL, NULL);

DROP TABLE IF EXISTS `menu_translations`;
CREATE TABLE `menu_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int unsigned NOT NULL,
  `lang` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_id_lang` (`menu_id`,`lang`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `menu_translations` (`id`, `menu_id`, `lang`, `label`, `created_at`, `updated_at`) VALUES
('7', '11', 'en', 'About us', '2026-09-13 13:54:13', '2026-09-13 13:54:46'),
('2', '2', 'en', 'Home', '2026-09-09 13:26:28', '2026-09-13 17:27:44'),
('3', '9', 'en', 'Contact', '2026-09-09 13:26:43', '2026-09-09 13:26:43'),
('5', '5', 'en', 'Product Data Sheet', '2026-09-09 13:27:13', '2026-09-09 13:27:13'),
('8', '12', 'en', 'Where are we going?', '2026-09-13 13:55:09', '2026-09-13 13:55:09');

DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `lang` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT 'es',
  `page_id` int unsigned DEFAULT NULL,
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `parent_id` int unsigned DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `target` enum('_self','_blank') CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT '_self',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `menus` (`id`, `lang`, `page_id`, `label`, `url`, `icon`, `parent_id`, `sort_order`, `target`, `active`, `created_at`) VALUES
('11', 'es', '1', 'Quienes somos', NULL, NULL, NULL, '2', '_self', '1', NULL),
('2', 'es', '2', 'Inicio', NULL, NULL, NULL, '0', '_self', '1', NULL),
('12', 'es', '11', 'A donde vamos', NULL, NULL, '11', '0', '_self', '1', NULL),
('9', 'es', '9', 'Contacto', NULL, NULL, NULL, '6', '_self', '1', NULL),
('20', 'es', '19', 'Galería de fotos', NULL, NULL, NULL, '0', '_self', '1', NULL),
('21', 'es', '20', 'Catálogo de productos', NULL, NULL, NULL, '0', '_self', '1', NULL),
('22', 'es', '23', 'Noticias', NULL, NULL, NULL, '0', '_self', '1', NULL);

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `group` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `namespace` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `time` int NOT NULL,
  `batch` int unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
('1', '2026-08-30-135221', 'App\\Database\\Migrations\\CreatePagesTable', 'default', 'App', '1788099218', '1'),
('2', '2026-08-30-135221', 'App\\Database\\Migrations\\CreateUsersTable', 'default', 'App', '1788099218', '1'),
('3', '2026-08-30-135222', 'App\\Database\\Migrations\\CreateMenusTable', 'default', 'App', '1788099218', '1'),
('4', '2026-08-30-135222', 'App\\Database\\Migrations\\CreateModulesTable', 'default', 'App', '1788099218', '1'),
('5', '2026-08-30-135222', 'App\\Database\\Migrations\\CreateTemplatesTable', 'default', 'App', '1788099218', '1'),
('6', '2026-08-30-135222', 'App\\Database\\Migrations\\CreateThemesTable', 'default', 'App', '1788099218', '1'),
('7', '2026-08-30-135659', 'App\\Database\\Migrations\\CreateSettingsTable', 'default', 'App', '1788099218', '1'),
('8', '2026-09-01-114438', 'App\\Database\\Migrations\\CreateFormSubmissionsTable', 'default', 'App', '1788263144', '2'),
('10', '2026-09-02-105544', 'App\\Database\\Migrations\\CreateCategoriesTable', 'default', 'App', '1788351006', '3'),
('11', '2026-09-02-105606', 'App\\Database\\Migrations\\CreateProductsTable', 'default', 'App', '1788351006', '3'),
('30', '2026-09-03-000001', 'App\\Database\\Migrations\\CreateGalleryTable', 'default', 'App', '1790863392', '17'),
('27', '2026-09-03-000001', 'App\\Database\\Migrations\\CreateLanguagesTable', 'default', 'App', '1790700170', '16'),
('14', '2026-09-08-082700', 'App\\Database\\Migrations\\CreateMediaTables', 'default', 'App', '1788856261', '6'),
('15', '2026-09-08-172525', 'App\\Database\\Migrations\\CreatePageRevisions', 'default', 'App', '1788888422', '7'),
('16', '2026-09-09-112231', 'App\\Database\\Migrations\\CreatePageTranslations', 'default', 'App', '1788952980', '8'),
('17', '2026-09-09-131346', 'App\\Database\\Migrations\\CreateMenuTranslations', 'default', 'App', '1788959658', '9'),
('18', '2026-09-13-125116', 'App\\Database\\Migrations\\CreateNameTranslations', 'default', 'App', '1789304092', '10'),
('20', '2026-09-19-132332', 'App\\Database\\Migrations\\CreateRedirectsTable', 'default', 'App', '1789824894', '12'),
('38', '2026-09-20-102026', 'App\\Database\\Migrations\\CreateFaqTables', 'default', 'App', '1791725451', '21'),
('36', '2026-09-18-095724', 'App\\Database\\Migrations\\CreateNewsTables', 'default', 'App', '1791725190', '19'),
('24', '2026-09-20-150016', 'App\\Database\\Migrations\\CreateCookieConsents', 'default', 'App', '1789918109', '15'),
('39', '2026-09-19-162547', 'App\\Database\\Migrations\\CreateFormsTables', 'default', 'App', '1792064341', '22');

DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `version` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `namespace` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `has_admin` tinyint(1) NOT NULL DEFAULT '1',
  `has_front` tinyint(1) NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `installed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `modules` (`id`, `name`, `slug`, `version`, `description`, `namespace`, `path`, `has_admin`, `has_front`, `active`, `installed_at`) VALUES
('37', 'Redirecciones', 'redirects', '1.0.0', '', 'App\\Modules\\Redirects', 'app/Modules/redirects', '1', '0', '1', '2026-10-04 11:38:55'),
('44', 'FAQ', 'faq', '1.0', 'Preguntas frecuentes con categorías', 'App\\Modules\\Faq', 'app/Modules/faq', '1', '1', '1', '2026-10-11 13:30:51'),
('42', 'Noticias', 'news', '1.0.0', '', 'App\\Modules\\News', 'app/Modules/news', '1', '1', '1', '2026-10-11 13:26:30'),
('29', 'Multi-idioma', 'i18n', '1.0.0', 'Gestión de idiomas para páginas, menús y contenido.', 'App\\Modules\\I18n', 'app/Modules/i18n', '1', '0', '1', '2026-09-29 16:42:50'),
('32', 'Galería de Imágenes', 'gallery', '1.0.0', 'Gestión de álbumes e imágenes con lightbox.', 'App\\Modules\\Gallery', 'app/Modules/gallery', '1', '1', '1', '2026-10-01 14:03:12'),
('35', 'Catálogo de Productos', 'catalog', '1.0.0', 'Gestión de productos con categorías, stock, precios y galería de imágenes.', 'App\\Modules\\Catalog', 'app/Modules/catalog', '1', '1', '1', '2026-10-04 08:42:20'),
('45', 'Formularios', 'forms', '1.0.0', '', 'App\\Modules\\Forms', 'app/Modules/forms', '1', '1', '1', '2026-10-15 11:39:01');

DROP TABLE IF EXISTS `news_articles`;
CREATE TABLE `news_articles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `summary` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `image_main` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `meta_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `meta_desc` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`(250)),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `news_categories`;
CREATE TABLE `news_categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `sort_order` int NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `news_category_translations`;
CREATE TABLE `news_category_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned NOT NULL,
  `lang` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_id_lang` (`category_id`,`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `news_translations`;
CREATE TABLE `news_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int unsigned NOT NULL,
  `lang` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `summary` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `article_id_lang` (`article_id`,`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `page_revisions`;
CREATE TABLE `page_revisions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int unsigned NOT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `meta_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `meta_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `page_revisions_user_id_foreign` (`user_id`),
  KEY `page_id` (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `page_revisions` (`id`, `page_id`, `user_id`, `title`, `content`, `meta_title`, `meta_desc`, `created_at`) VALUES
('52', '11', '1', 'A donde vamos', '<p><img style=\"width: 640px;\" src=\"http://ainvarcms.loc/uploads/media/1790760062_9676323109ab6d3f2616.jpg\" data-filename=\"\"><br></p>', '', '', '2026-10-04 08:25:55'),
('53', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-10-04 08:27:47'),
('54', '11', '1', 'A donde vamos', '<p><img style=\"width: 640px;\" src=\"http://ainvarcms.loc/uploads/media/1790760062_9676323109ab6d3f2616.jpg\" data-filename=\"\"><br></p>', '', '', '2026-10-04 08:28:04'),
('55', '9', '1', 'Contacto', '{\"nombre\":\"\",\"direccion\":\"\",\"poblacion\":\"\",\"provincia\":\"\",\"cod_postal\":\"\",\"telefono\":\"\",\"observaciones\":\"\"}', '', '', '2026-10-04 08:28:12'),
('3', '1', '1', 'Quienes somos', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos', 'Texto sobre quienes somos y que hacemos', '2026-09-08 17:56:34'),
('4', '1', '1', 'Quienes somos?', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos', 'Texto sobre quienes somos y que hacemos', '2026-09-08 17:57:04'),
('5', '1', '1', 'Quienes somos?', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-08 17:57:34'),
('6', '1', '1', 'Quienes somos?', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-09 11:40:04'),
('7', '1', '1', 'Quienes somos?', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-09 11:47:30'),
('8', '2', '1', 'Inicio', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', '', '', '2026-09-09 12:04:10'),
('9', '9', '1', 'Contacto', '{\"nombre\":\"\",\"direccion\":\"\",\"poblacion\":\"\",\"provincia\":\"\",\"cod_postal\":\"\",\"telefono\":\"\",\"observaciones\":\"\"}', '', '', '2026-09-09 13:06:51'),
('10', '10', '1', 'Galería', NULL, '', '', '2026-09-09 13:07:07'),
('11', '5', '1', 'Ficha de producto', '{\"nombre\":\"Auriculares\",\"precio\":\"35\",\"precio_anterior\":\"45\",\"descripcion\":\"Auriculares muy buenos\",\"imagen\":\"\",\"categoria\":\"Sonido\",\"stock\":\"12\",\"sku\":\"\",\"etiquetas\":\"\"}', '', '', '2026-09-09 13:08:13'),
('12', '8', '1', 'Catálogo', NULL, '', '', '2026-09-09 13:08:29'),
('13', '1', '1', 'Quienes somos?', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-09 13:23:57'),
('14', '1', '1', 'Quienes somos?', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-09 13:26:02'),
('15', '2', '1', 'Inicio', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', '', '', '2026-09-09 13:26:28'),
('16', '9', '1', 'Contacto', '{\"nombre\":\"\",\"direccion\":\"\",\"poblacion\":\"\",\"provincia\":\"\",\"cod_postal\":\"\",\"telefono\":\"\",\"observaciones\":\"\"}', '', '', '2026-09-09 13:26:43'),
('17', '10', '1', 'Galería', NULL, '', '', '2026-09-09 13:26:56'),
('18', '5', '1', 'Ficha de producto', '{\"nombre\":\"Auriculares\",\"precio\":\"35\",\"precio_anterior\":\"45\",\"descripcion\":\"Auriculares muy buenos\",\"imagen\":\"\",\"categoria\":\"Sonido\",\"stock\":\"12\",\"sku\":\"\",\"etiquetas\":\"\"}', '', '', '2026-09-09 13:27:13'),
('19', '8', '1', 'Catálogo', NULL, '', '', '2026-09-09 13:27:26'),
('20', '5', '1', 'Ficha de producto', '{\"nombre\":\"Auriculares\",\"precio\":\"35\",\"precio_anterior\":\"45\",\"descripcion\":\"Auriculares muy buenos\",\"imagen\":\"\",\"categoria\":\"Sonido\",\"stock\":\"12\",\"sku\":\"\",\"etiquetas\":\"\"}', '', '', '2026-09-10 16:56:30'),
('21', '1', '1', 'Quienes somos?', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-11 12:22:07'),
('22', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-11 12:24:01'),
('23', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-11 12:25:07'),
('24', '9', '1', 'Contacto', '{\"nombre\":\"\",\"direccion\":\"\",\"poblacion\":\"\",\"provincia\":\"\",\"cod_postal\":\"\",\"telefono\":\"\",\"observaciones\":\"\"}', '', '', '2026-09-11 17:51:19'),
('25', '2', '1', 'Inicio', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', '', '', '2026-09-11 20:46:12'),
('26', '2', '1', '/Inicio', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', '', '', '2026-09-11 20:47:41'),
('27', '2', '1', 'Inicio', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', '', '', '2026-09-12 08:35:38'),
('28', '2', '1', 'Inicio', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', '', '', '2026-09-12 08:36:12'),
('29', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-13 12:36:38'),
('30', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-13 12:36:55'),
('31', '11', '1', 'A donde vamos', '', '', '', '2026-09-13 13:48:25'),
('32', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-13 13:53:00'),
('33', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-13 13:54:13'),
('34', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-09-13 13:54:46'),
('35', '11', '1', 'A donde vamos', '', '', '', '2026-09-13 13:55:09'),
('36', '12', '1', 'Prueba para inglés', '', '', '', '2026-09-13 14:04:14'),
('37', '12', '1', 'Prueba para inglés', '', '', '', '2026-09-13 14:04:59'),
('38', '13', '1', 'Prueba', '', '', '', '2026-09-13 14:16:00'),
('39', '13', '1', 'Prueba', '', '', '', '2026-09-13 14:16:11'),
('40', '2', '1', 'Inicio', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', '', '', '2026-09-13 17:27:44'),
('41', '13', '1', 'Prueba', '', '', '', '2026-09-14 13:05:00'),
('42', '13', '1', 'Prueba', '', '', '', '2026-09-14 13:15:06'),
('43', '15', '1', 'Noticias', '<p>[noticias limite=\"3\"]</p>', '', '', '2026-09-18 11:49:46'),
('44', '15', '1', 'Noticias', NULL, '', '', '2026-09-18 12:34:02'),
('45', '15', '1', 'Noticias', '<p>[noticias limite=\"3\"]</p>', '', '', '2026-09-18 12:45:46'),
('46', '11', '1', 'A donde vamos', '', '', '', '2026-09-30 09:40:43'),
('47', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-10-01 14:01:42'),
('48', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-10-04 08:24:56'),
('49', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-10-04 08:25:09'),
('50', '9', '1', 'Contacto', '{\"nombre\":\"\",\"direccion\":\"\",\"poblacion\":\"\",\"provincia\":\"\",\"cod_postal\":\"\",\"telefono\":\"\",\"observaciones\":\"\"}', '', '', '2026-10-04 08:25:28'),
('51', '1', '1', 'Quienes somos', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', '2026-10-04 08:25:42');

DROP TABLE IF EXISTS `page_translations`;
CREATE TABLE `page_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int unsigned NOT NULL,
  `lang` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `meta_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `meta_desc` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_id_lang` (`page_id`,`lang`),
  UNIQUE KEY `lang_slug` (`lang`,`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `page_translations` (`id`, `page_id`, `lang`, `title`, `slug`, `content`, `meta_title`, `meta_desc`, `created_at`, `updated_at`) VALUES
('1', '1', 'en', 'About us', 'about-us', '<h2>Our products:</h2>\r\n<p>Discover the best of our catalog:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">Do you have any question?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p><p></p>', 'Our products', 'Product list', '2026-09-09 11:47:30', '2026-09-13 13:54:46'),
('2', '2', 'en', 'Home', '/', '<p><h2>Our products</h2>Discover the best of our catalog:</p><p>[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">Do you have any questions?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p><p><br></p></p>', '', '', '2026-09-09 12:04:10', '2026-09-13 17:27:44'),
('3', '9', 'en', 'Contact', 'contact', '', '', '', '2026-09-09 13:06:51', '2026-09-11 17:51:19'),
('4', '10', 'en', 'Gallery', 'gallery', '', '', '', '2026-09-09 13:07:07', '2026-09-09 13:26:56'),
('5', '5', 'en', 'Product Data Sheet', 'product-data-sheet', '', '', '', '2026-09-09 13:08:13', '2026-09-10 16:56:30'),
('6', '8', 'en', 'Catalogue', 'catalogue', '', '', '', '2026-09-09 13:08:29', '2026-09-09 13:27:26'),
('7', '11', 'en', 'Where are we going?', 'where-are-we-going', '', '', '', '2026-09-13 13:48:09', '2026-09-13 13:55:09'),
('8', '12', 'en', 'Prueba para english', 'prueba-para-english', '', '', '', '2026-09-13 14:02:30', '2026-09-13 14:04:59'),
('9', '13', 'en', 'Test', 'test', '', '', '', '2026-09-13 14:14:16', '2026-09-14 13:15:06'),
('10', '14', 'en', 'News', 'news', '<p>[noticias limite=\"2\"]</p>', '', '', '2026-09-18 10:54:31', '2026-09-18 10:54:31'),
('11', '15', 'en', 'News', 'news-9bf4', '<p>[noticias limite=\"3\"]</p>', '', '', '2026-09-18 11:38:46', '2026-09-18 12:45:46'),
('12', '17', 'en', 'FAQ', 'faq', '', '', '', '2026-09-20 14:28:13', '2026-09-20 14:28:13'),
('13', '18', 'en', 'Cookies politic', 'cookies-politic', '<p align=\"center\"><u>This is our cookies politic</u></p><p>\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris et ultrices lorem, id tempor urna. Donec quam nisi, vulputate at facilisis at, malesuada non est. Phasellus convallis tellus sed orci dictum, ac gravida enim posuere. Vestibulum vitae metus id nisi pretium pulvinar venenatis eu libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris ultrices dui et eros consectetur, id rhoncus orci ultrices. Maecenas ac nibh ut mauris euismod posuere. Vestibulum quis velit lectus. Nunc porttitor tortor sit amet orci sagittis, vitae imperdiet diam accumsan. Proin porttitor sapien ex, eu ullamcorper nunc ullamcorper ac. Integer auctor quis orci vitae fermentum. Suspendisse potenti. Fusce accumsan dolor id leo ornare porttitor in at risus. Suspendisse auctor aliquet turpis.\r\n</p>\r\n<p>\r\nVestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Pellentesque eleifend magna vitae diam fringilla ultrices. Suspendisse lobortis semper sapien, sit amet euismod arcu cursus at. Mauris euismod vel turpis quis accumsan. Quisque ac ullamcorper nisi. Nullam at felis ornare, fermentum est ut, eleifend lacus. Aenean id porta odio. Donec tempor ut eros eu efficitur. Nunc imperdiet imperdiet est nec pellentesque. Donec sodales non lectus ac suscipit.\r\n</p>\r\n<p>\r\nMaecenas scelerisque dui sit amet congue pulvinar. Quisque volutpat eleifend nulla, ut suscipit justo ultrices eget. Duis at velit sed lectus commodo ultricies. Etiam eget efficitur mauris, non sollicitudin tellus. Vestibulum ac eros nec mi lobortis dignissim ac non ante. Morbi quis nisi ut neque tempor luctus. Pellentesque eu facilisis ex, aliquet ullamcorper libero. Donec ac eros a justo pellentesque faucibus non nec augue. Donec nulla quam, cursus non tempor ut, luctus at nisi. Ut auctor dui a massa imperdiet placerat.\r\n</p>\r\n<p>\r\nNam et congue ante. Fusce cursus ultricies dolor vitae venenatis. Nam at pellentesque ante. Phasellus condimentum pulvinar nunc, nec tempor nisl euismod ac. Donec non pharetra quam, vel aliquet massa. Praesent in felis eget urna porttitor lacinia. Nullam interdum magna et egestas maximus. Phasellus tempor finibus commodo. Proin quis augue et mauris fermentum feugiat a sagittis velit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.\r\n</p>\r\n<p>\r\nMaecenas velit est, ultricies vel commodo vitae, ultricies nec lacus. Cras a imperdiet mauris. Morbi nec scelerisque quam. Maecenas vel elit rutrum, sagittis eros sit amet, accumsan felis. Nullam vel pellentesque felis. Curabitur id nibh tristique, eleifend tortor a, dignissim nisl. Aenean id nunc et nisl condimentum commodo sed ut nisl. Vestibulum placerat justo nulla, vel aliquam dolor interdum eu.\r\n</p><p><br></p>', '', '', '2026-09-20 15:32:06', '2026-09-20 15:32:06');

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `lang` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT 'es',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `type` enum('normal','template','module') CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT 'normal',
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `template_id` int unsigned DEFAULT NULL,
  `module_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `meta_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `meta_desc` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `status` enum('published','draft','hidden') CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT 'draft',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `pages` (`id`, `lang`, `title`, `slug`, `type`, `content`, `template_id`, `module_name`, `meta_title`, `meta_desc`, `status`, `sort_order`, `created_at`, `updated_at`) VALUES
('1', 'es', 'Quienes somos', 'quienes-somos', 'normal', '<h2>Nuestros productos:</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Write to us\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/about-us\" clase=\"btn btn-outline-dark\"]Get to know us[/boton]\r\n</p>', NULL, NULL, 'Empresa de prueba - Quienes somos?', 'Texto sobre quienes somos y que hacemos', 'published', '3', '2026-08-31 11:30:35', '2026-10-04 08:27:47'),
('2', 'es', 'Inicio', '/', 'normal', '<h2>Nuestros productos</h2>\r\n<p>Descubre lo mejor de nuestro catálogo:</p>\r\n[productos limite=3]\r\n\r\n<h2 class=\"mt-5\">¿Tienes dudas?</h2>\r\n[contacto_form titulo=\"Escríbenos\"]\r\n\r\n<p class=\"mt-3\">\r\n    [boton url=\"/quienes-somos\" clase=\"btn btn-outline-dark\"]Conócenos[/boton]\r\n</p>', NULL, NULL, '', '', 'published', '0', '2026-08-31 12:24:49', '2026-09-13 17:27:44'),
('9', 'es', 'Contacto', 'contacto', 'template', '{\"nombre\":\"\",\"direccion\":\"\",\"poblacion\":\"\",\"provincia\":\"\",\"cod_postal\":\"\",\"telefono\":\"\",\"observaciones\":\"\"}', '1', NULL, '', '', 'published', '4', '2026-09-03 16:08:40', '2026-10-04 08:28:12'),
('11', 'es', 'A donde vamos', 'a-donde-vamos', 'normal', '<p><img style=\"width: 640px;\" src=\"http://ainvarcms.loc/uploads/media/1790760062_9676323109ab6d3f2616.jpg\" data-filename=\"\"><br></p>', NULL, NULL, '', '', 'published', '3', '2026-09-13 13:48:09', '2026-10-04 08:28:04'),
('19', 'es', 'Galería de fotos', 'galeria-de-fotos', 'module', NULL, NULL, 'gallery', 'galería de fotos', 'Galería de fotos de interés para el negocio', 'published', '1', '2026-09-30 18:19:32', '2026-09-30 18:19:32'),
('20', 'es', 'Catálogo de productos', 'catalogo-de-productos', 'module', NULL, NULL, 'catalog', 'Catálogo de productos', 'Aquí se muestran los productos propuestos por el cliente', 'published', '2', '2026-10-04 08:27:33', '2026-10-04 08:27:33'),
('21', 'es', 'Política de privacidad', 'politica-de-privacidad', 'normal', '<h2>Política de Privacidad y Cookies</h2>\r\n\r\n<p><strong>Última actualización:</strong> [fecha]</p>\r\n\r\n<h3>1. Responsable del tratamiento</h3>\r\n\r\n<p>El responsable del tratamiento de tus datos personales es <strong>[Nombre del titular / empresa]</strong>, con domicilio en <strong>[dirección]</strong> y correo electrónico de contacto: <strong>[email de contacto]</strong> (en adelante, \"el Sitio\", accesible en <strong>[dominio]</strong>).</p>\r\n\r\n<h3>2. Datos personales que recopilamos</h3>\r\n\r\n<p>Recopilamos datos personales únicamente en los siguientes casos:</p>\r\n\r\n<h4>2.1 Formulario de contacto</h4>\r\n\r\n<p>Cuando nos escribes a través del formulario de contacto recopilamos:</p>\r\n\r\n<p>- Nombre y dirección de correo electrónico (campos que tú cumplimentas).</p>\r\n<p>- Contenido del mensaje.</p>\r\n<p>- Dirección IP y agente de usuario de tu navegador, con fines de seguridad y prevención de abuso.</p>\r\n\r\n<h4>2.2 Registro de consentimientos de cookies</h4>\r\n\r\n<p>Cuando respondes al aviso de cookies, registramos tu decisión (categorías aceptadas o rechazadas) junto con un identificador técnico y la fecha, con el fin de acreditar el consentimiento conforme al art. 7 del RGPD.</p>\r\n\r\n<h4>2.3 Navegación</h4>\r\n\r\n<p>No elaboramos perfiles de navegación ni tomamos decisiones automatizadas sobre datos personales.</p>\r\n\r\n<h3>3. Finalidad y legitimación</h3>\r\n\r\n<table class=\"table table-striped table-hover\"><thead><tr><th>Tratamiento</th><th>Finalidad</th><th>Base legal</th></tr></thead><tbody><tr><td>Gestión de mensajes del formulario de contacto</td><td>Responder a tu consulta</td><td>Consentimiento del interesado (art. 6.1.a RGPD)</td></tr><tr><td>Registro de IP y agente de usuario</td><td>Seguridad, prevención de fraude y abuso</td><td>Interés legítimo (art. 6.1.f RGPD)</td></tr><tr><td>Registro de consentimientos de cookies</td><td>Acreditar el consentimiento otorgado</td><td>Obligación legal (art. 7.1 RGPD)</td></tr><tr><td>Cookies de análisis (Google Analytics 4)</td><td>Estadísticas de uso anonimizadas</td><td>Consentimiento (art. 6.1.a RGPD) — solo si las aceptas</td></tr></tbody></table>\r\n\r\n<h3>4. Conservación de los datos</h3>\r\n\r\n<p>- Los mensajes recibidos mediante el formulario de contacto se conservan durante <strong>[plazo, p. ej.: 24 meses]</strong> y después se eliminan.</p>\r\n<p>- El registro de consentimientos de cookies se conserva durante el plazo necesario para acreditar el consentimiento.</p>\r\n\r\n<h3>5. Destinatarios y transferencias</h3>\r\n\r\n<p>- <strong>No cedemos tus datos a terceros</strong>, salvo obligación legal.</p>\r\n<p>- Si aceptas las cookies de análisis, Google LLC (Google Analytics 4) tratará datos de navegación conforme a su propia política de privacidad. Estos datos pueden transferirse fuera del Espacio Económico Europeo con las garantías adecuadas (cláusulas contractuales tipo). Los datos de IP se anonimizan antes de su almacenamiento.</p>\r\n<p>- No se realizan transferencias internacionales de los datos del formulario de contacto.</p>\r\n\r\n<h3>6. Tus derechos</h3>\r\n\r\n<p>Puedes ejercer en cualquier momento los siguientes derechos:</p>\r\n\r\n<p>- <strong>Acceso</strong>: saber qué datos tuyos tratamos.</p>\r\n<p>- <strong>Rectificación</strong>: corregir datos inexactos.</p>\r\n<p>- <strong>Supresión</strong>: que eliminemos tus datos.</p>\r\n<p>- <strong>Oposición</strong>: oponerte a un tratamiento concreto.</p>\r\n<p>- <strong>Limitación</strong>: restringir el tratamiento en determinados supuestos.</p>\r\n<p>- <strong>Portabilidad</strong>: recibir tus datos en un formato estructurado.</p>\r\n\r\n<p>Para ejercerlos, escríbenos a <strong>[email de contacto]</strong> indicando el derecho que deseas ejercer. Adjuntaremos a la respuesta el impreso necesario para acreditar tu identidad si fuera preciso.</p>\r\n\r\n<p>Si consideras que no hemos atendido adecuadamente tu solicitud, puedes reclamar ante la <strong>Agencia Española de Protección de Datos (AEPD)</strong>: www.aepd.es.</p>\r\n\r\n<h3>7. Cookies</h3>\r\n\r\n<h4>7.1 ¿Qué son las cookies?</h4>\r\n\r\n<p>Las cookies son pequeños archivos que el Sitio almacena en tu dispositivo al navegar. Sirven, entre otras cosas, para que el Sitio funcione correctamente o para obtener información estadística sobre su uso.</p>\r\n\r\n<h4>7.2 Cookies que utilizamos</h4>\r\n\r\n<table class=\"table table-striped table-hover\"><thead><tr><th>Cookie</th><th>Tipo</th><th>Duración</th><th>Finalidad</th></tr></thead><tbody><tr><td>`ci_session`</td><td>Necesaria</td><td>Sesión</td><td>Mantener tu sesión activa mientras navegas.</td></tr><tr><td>`csrf_cookie_name`</td><td>Necesaria</td><td>Sesión</td><td>Protección contra falsificación de peticiones (seguridad del formulario).</td></tr><tr><td>`ainvar_consent`</td><td>Necesaria</td><td>1 año</td><td>Recuerda tu decisión sobre cookies para no volver a preguntarte.</td></tr><tr><td>`_ga`</td><td>Analítica</td><td>2 años</td><td>Google Analytics 4: distingue usuarios. <strong>Solo se instala si aceptas \"Analítica\".</strong></td></tr><tr><td>`_ga_`</td><td>Analítica</td><td>2 años</td><td>Google Analytics 4: estado de la sesión. <strong>Solo si aceptas \"Analítica\".</strong></td></tr><tr><td>`_gid`</td><td>Analítica</td><td>24 horas</td><td>Google Analytics 4: distingue usuarios. <strong>Solo si aceptas \"Analítica\".</strong></td></tr><tr><td>`_gat`</td><td>Analítica</td><td>1 minuto</td><td>Google Analytics 4: limita la frecuencia de peticiones. <strong>Solo si aceptas \"Analítica\".</strong></td></tr></tbody></table>\r\n\r\n<p>Las cookies de análisis <strong>no se descargan ni se ejecutan</strong> hasta que das tu consentimiento expreso: se sirven bloqueadas mediante el atributo `data-cookieconsent` y solo se activan si las aceptas en el aviso o en el panel de preferencias.</p>\r\n\r\n<h4>7.3 Cómo gestionar o retirar tu consentimiento</h4>\r\n\r\n<p>- <strong>Al visitar el Sitio por primera vez</strong>, un aviso te permite aceptar, rechazar o configurar las cookies por categorías.</p>\r\n<p>- <strong>En cualquier momento posterior</strong>, puedes modificar tu decisión pulsando el enlace \"Configuración de cookies\" del pie de página, o ejecutando `CookieConsent.open()` en la consola del navegador. Al retirar el consentimiento de una categoría, sus cookies se eliminan de tu dispositivo.</p>\r\n<p>- También puedes eliminar o bloquear las cookies desde la configuración de tu navegador (Chrome, Firefox, Safari, Edge). Ten en cuenta que deshabilitar las cookies necesarias puede impedir el funcionamiento del Sitio.</p>\r\n\r\n<h3>8. Cambios en esta política</h3>\r\n\r\n<p>Podemos actualizar esta política para adaptarla a novedades legislativas o técnicas. La fecha de la última revisión figura al inicio del documento. Te recomendamos revisarla periódicamente.</p>\r\n\r\n<h3>9. Legislación aplicable</h3>\r\n\r\n<p>El tratamiento de tus datos se rige por el <strong>Reglamento (UE) 2016/679 (RGPD)</strong> y la <strong>Ley Orgánica 3/2018 (LOPDGDD)</strong>, así como por la <strong>Ley 34/2002 (LSSI-CE)</strong> en materia de cookies.</p><p><br></p>', NULL, NULL, 'Política de privacidad', 'Aquí se define la política de privacidad de la empresa', 'published', '0', '2026-10-04 12:48:09', '2026-10-04 12:48:09'),
('22', 'es', 'Ayuda', 'ayuda', 'normal', '<div class=\"portada\">\r\n    <h1>CMS Ainvar</h1>\r\n    <p>Manual de usuario · Versión 1.1 · Septiembre 2026</p>\r\n    <p>Guía de uso del panel de administración y del sitio web</p>\r\n</div>\r\n\r\n<main>\r\n\r\n<div id=\"indice\">\r\n    <strong>Contenido</strong>\r\n    <ol><li><a>Acceder al panel</a></li><li><a>El escritorio</a></li><li><a>Páginas</a></li><li><a>Menús</a></li><li><a>Medios (biblioteca de archivos)</a></li><li><a>Galería</a></li><li><a>Noticias</a></li><li><a>Catálogo</a></li><li><a>Plantillas y temas</a></li><li><a>Usuarios y roles</a></li><li><a>Ajustes</a></li><li><a>Copias de seguridad</a></li><li><a>El sitio en varios idiomas</a></li><li><a>Solución de problemas</a></li></ol>\r\n    <p style=\"margin-bottom:0\"><span class=\"rol editor\">EDITOR</span> puede gestionar contenidos &nbsp;·&nbsp; <span class=\"rol admin\">ADMIN</span> además: usuarios, ajustes &nbsp;·&nbsp; <span class=\"rol super\">SUPERADMIN</span> además: copias de seguridad y módulos</p>\r\n</div>\r\n\r\n<h2 id=\"s1\">1. Acceder al panel</h2>\r\n<ol class=\"steps\"><li>Abre en el navegador la dirección del sitio seguida de <kbd>/admin</kbd> (p. ej. <code>www.tudominio.com/admin</code>).</li><li>Introduce tu usuario (o email) y contraseña y pulsa <strong>Entrar</strong>.</li></ol>\r\n<div class=\"nota\">\r\n    <strong>Bloqueo por inactividad.</strong> Por seguridad, si no mueves el ratón ni pulsas teclas durante el tiempo configurado (15 minutos por defecto), la pantalla se bloquea. Toca cualquier tecla y desbloquea escribiendo tu <strong>PIN</strong> (lo definiste al crear tu usuario). Recuperarás exactamente la pantalla donde estabas.\r\n</div>\r\n<div class=\"nota\">\r\n    <strong>Modo oscuro.</strong> En la parte superior de la barra lateral hay un botón con luna/sol para cambiar entre tema claro y oscuro. La elección se recuerda en ese navegador, y la pantalla de login la respeta.\r\n</div>\r\n<div class=\"nota aviso\">\r\n    <strong>Cierre de sesión.</strong> Usa siempre <strong>Salir</strong> en el menú lateral. Si cierras la pestaña sin salir, la sesión seguirá abierta hasta que caduque.\r\n</div>\r\n\r\n<h2 id=\"s2\">2. El escritorio</h2>\r\n<p>Al entrar verás el panel principal con:</p>\r\n<ul class=\"dots\"><li><strong>Tarjetas resumen</strong>: páginas, envíos, medios, etc.</li><li><strong>Gráfico de actividad</strong> semanal.</li><li><strong>Últimos envíos</strong> de formularios de contacto.</li></ul>\r\n<h3>Buscador global</h3>\r\n<p>En la parte superior hay un campo de búsqueda que encuentra páginas, archivos de medios, productos e imágenes de galería mientras escribes. Pulsa <kbd>Intro</kbd> para ir al primer resultado o <kbd>Esc</kbd> para cerrar.</p>\r\n<h3>Notificaciones de envíos</h3>\r\n<p>El menú <strong>Envíos</strong> muestra un contador rojo con los mensajes de contacto sin leer; el navegador te avisa con un aviso emergente cuando llega uno nuevo (sin recargar la página).</p>\r\n\r\n<h2 id=\"s3\">3. Páginas <span class=\"rol editor\">EDITOR</span></h2>\r\n<p>Las páginas son la base del sitio: cada entrada del menú principal corresponde a una página.</p>\r\n<h3>Crear una página</h3>\r\n<ol class=\"steps\"><li>Menú lateral → <strong>Páginas</strong> → botón <strong>Nueva página</strong>.</li><li>Rellena el <strong>título</strong>. El <em>slug</em> (la dirección web) se genera solo a partir del título; puedes cambiarlo si lo necesitas.</li><li>Elige el <strong>tipo</strong>:\r\n        <ul class=\"dots\"><li><strong>Normal</strong>: contenido libre con el editor visual.</li><li><strong>Plantilla</strong>: estructura predefinida con campos concretos (contacto, fichas, etc.).</li><li><strong>Módulo</strong>: la página muestra el contenido de un módulo instalado (Galería, Catálogo).</li></ul>\r\n    </li><li>Redacta el contenido con el editor. Para insertar imágenes usa el botón de imagen del propio editor: se abre la biblioteca de medios y la imagen queda vinculada a ella.</li><li>En la pestaña <strong>SEO</strong> puedes definir título y descripción para buscadores (si los dejas vacíos se usan los de la página).</li><li>Estado: <strong>Publicada</strong> (visible), <strong>Borrador</strong> (guardada sin publicar) u <strong>Oculta</strong>.</li><li>Guarda con el botón inferior.</li></ol>\r\n<h3>Añadir la página al menú</h3>\r\n<p>En el mismo formulario, activa <strong>«Añadir al menú de navegación»</strong> (tarjeta <em>Menú</em>):</p>\r\n<ul class=\"dots\"><li>La <strong>etiqueta</strong> es el texto que verá el visitante en el menú. Si la dejas vacía se usa el título de la página.</li><li>Puedes escribir una <strong>etiqueta distinta para cada idioma</strong>; si la dejas vacía, el menú usará automáticamente el título de la página en ese idioma.</li><li>Elige <strong>menú padre</strong> si debe aparecer como subopción desplegable, y el <strong>orden</strong>.</li></ul>\r\n<div class=\"nota\">Las páginas en borrador u ocultas <strong>no aparecen en el menú</strong> del sitio aunque tengan la casilla activada. Al publicarlas, aparecen automáticamente.</div>\r\n<h3>Versiones y restauración</h3>\r\n<p>Cada vez que editas una página, el sistema guarda una copia de la versión anterior (conserva las últimas 20). En el listado de páginas, el botón de versiones permite <strong>ver los cambios</strong> palabra a palabra y <strong>restaurar</strong> una versión anterior si algo salió mal.</p>\r\n<h3>Editar o borrar</h3>\r\n<p>Desde el listado de páginas: icono de lápiz para editar, papelera para borrar (pedirá confirmación; borrar una página la quita también del menú).</p>\r\n\r\n<h2 id=\"s4\">4. Menús <span class=\"rol editor\">EDITOR</span></h2>\r\n<p>En <strong>Menús</strong> gestionas la estructura completa de la barra de navegación: páginas del sitio y enlaces personalizados (a otras webs, PDFs, etc.).</p>\r\n<h3>Crear o editar un elemento</h3>\r\n<ol class=\"steps\"><li>Pulsa <strong>Añadir item</strong> (o el lápiz de uno existente).</li><li><strong>Enlazar a página</strong>: elige la página del desplegable — la URL se resuelve sola, incluso traducida.</li><li>O deja la página en «Ninguna» y escribe una <strong>URL manual</strong> (https://… o una ruta interna como /contacto). Marca «Nueva ventana» si debe abrirse en otra pestaña.</li><li>Escribe la <strong>etiqueta</strong> y, si quieres, su traducción para cada idioma activo.</li><li>Guarda.</li></ol>\r\n<h3>Orden y jerarquía</h3>\r\n<p>Los elementos se reordenan <strong>arrastrando</strong>: suelta un elemento sobre otro para hacerlo subopción suya (el menú del sitio lo mostrará como desplegable). Pulsa <strong>Guardar orden</strong> cuando termines — el botón aparece solo si has movido algo.</p>\r\n<h3>Iconos</h3>\r\n<p>Puedes asociar una imagen pequeña a cada elemento del menú (se muestra junto a la etiqueta en la barra de navegación).</p>\r\n\r\n<h2 id=\"s5\">5. Medios (biblioteca de archivos) <span class=\"rol editor\">EDITOR</span></h2>\r\n<p>Es la biblioteca central de imágenes del sitio. Todo lo que subas aquí puede reutilizarse en páginas, galería y catálogo.</p>\r\n<ol class=\"steps\"><li><strong>Subir</strong>: arrastra una o varias imágenes a la zona de subida (o haz clic para elegirlas). Revisa las vistas previas y pulsa <strong>Subir N imágenes</strong>. Máximo 5 MB por archivo, formatos JPG/PNG/GIF/WebP.</li><li><strong>Carpetas</strong>: crea carpetas para organizar (p. ej. «Sliders», «Equipo»). Solo se pueden borrar carpetas vacías.</li><li><strong>Editar</strong>: haz clic en una imagen para cambiar su <strong>título</strong> y su <strong>texto alternativo (alt)</strong> — importante para accesibilidad y SEO — o moverla de carpeta.</li><li><strong>Eliminar</strong>: desde esa misma ventana, con confirmación. Ojo: si la imagen se usa en alguna página, quedará rota.</li></ol>\r\n<div class=\"nota\">El sistema genera <strong>miniaturas automáticamente</strong> al subir: las listas cargan rápido y el visitante solo descarga la imagen grande cuando la abre.</div>\r\n\r\n<h2 id=\"s6\">6. Galería <span class=\"rol editor\">EDITOR</span></h2>\r\n<p>El módulo de galería muestra colecciones de imágenes en el sitio, organizadas en <strong>álbumes</strong>.</p>\r\n<h3>Subir imágenes</h3>\r\n<ol class=\"steps\"><li><strong>Galería → Subir imágenes</strong>.</li><li>Arrastra las fotos e indica el <strong>álbum</strong> (escribe el nombre: si existe lo autocompleta, si no, se crea al subir).</li><li>Pulsa <strong>Subir</strong> (verás la barra de progreso).</li><li>Opción <strong>«Añadir de la biblioteca»</strong>: toma imágenes ya subidas a Medios sin duplicar archivos.</li></ol>\r\n<h3>Gestionar</h3>\r\n<p>En el listado puedes filtrar por álbum y eliminar imágenes. Las imágenes pueden <strong>desactivarse</strong> (dejan de verse en el sitio sin borrarlas).</p>\r\n<h3>Traducir nombres de álbum</h3>\r\n<p>Botón <strong>«Traducir álbumes»</strong>: escribe el nombre de cada álbum en cada idioma activo. En el sitio, el visitante verá el nombre en su idioma; las direcciones web (URLs) no cambian, así que los enlaces nunca se rompen.</p>\r\n<div class=\"nota\">La galería del sitio se muestra a través de su <strong>página-módulo</strong> (p. ej. «Galería»). Si la galería no carga, comprueba en Páginas que esa página existe, es de tipo <em>módulo</em> y está publicada.</div>\r\n\r\n<h2 id=\"s7\">7. Noticias <span class=\"rol editor\">EDITOR</span></h2>\r\n<p>El módulo de noticias publica artículos en el sitio, organizados en <strong>categorías</strong> (prensa, actualidad, eventos…), con imagen destacada, fecha de publicación y contenido traducido por idioma.</p>\r\n<h3>Categorías</h3>\r\n<ol class=\"steps\"><li><strong>Noticias → Categorías → Nueva categoría</strong>: nombre, slug (se genera solo del nombre), descripción y orden.</li><li>Puedes escribir el <strong>nombre de la categoría en cada idioma</strong>; si lo dejas vacío se muestra el nombre principal.</li><li>No se pueden borrar categorías que contienen artículos.</li></ol>\r\n<h3>Crear un artículo</h3>\r\n<ol class=\"steps\"><li><strong>Noticias → Artículos → Nuevo artículo</strong>.</li><li>En la pestaña del idioma principal: <strong>título</strong>, <strong>resumen</strong> y <strong>contenido</strong> (editor visual con imágenes, enlaces y vídeos).</li><li>En las pestañas de los demás idiomas escribe las traducciones. Si un campo se deja vacío, el sitio muestra automáticamente el contenido del idioma principal.</li><li>En la columna lateral: <strong>categoría</strong>, <strong>imagen destacada</strong> (elegida desde la biblioteca de medios), <strong>fecha de publicación</strong> (puedes programarla en el futuro), interruptor <strong>destacado</strong> (se muestra grande en la cabecera del listado) e <strong>activo</strong>.</li><li>SEO: meta título y descripción propios del artículo (opcionales).</li><li>Guarda.</li></ol>\r\n<h3>Gestionar artículos</h3>\r\n<p>El listado permite <strong>buscar</strong> por título o resumen y <strong>filtrar por categoría</strong>. La estrella marca o desmarca el destacado; el botón verde/gris activa o desactiva el artículo (uno inactivo, o con fecha futura, no se muestra en el sitio). La papelera elimina el artículo y sus traducciones.</p>\r\n<h3>Cómo se ve en el sitio</h3>\r\n<ul class=\"dots\"><li>La página-módulo <strong>«Noticias»</strong> (créala como página de tipo <em>módulo → news</em> si no existe) muestra el listado: artículo destacado, filtros por categoría y tarjetas con fecha, imagen y resumen.</li><li>Cada tarjeta enlaza al <strong>detalle del artículo</strong>: contenido completo, migas de pan y noticias relacionadas de la misma categoría.</li><li>El selector de idioma del sitio muestra las noticias traducidas; los campos sin traducir caen al idioma principal automáticamente.</li></ul>\r\n<h3>Últimas noticias en cualquier página</h3>\r\n<p>Escribe <code>[noticias limite=\"3\"]</code> en el contenido de cualquier página (por ejemplo, la portada) para incrustar las últimas noticias en tarjetas. Cambia el número para mostrar más o menos.</p>\r\n\r\n<h2 id=\"s8\">8. Catálogo <span class=\"rol editor\">EDITOR</span></h2>\r\n<p>Gestión de productos y categorías si el módulo está activo.</p>\r\n<h3>Productos</h3>\r\n<ul class=\"dots\"><li><strong>Crear</strong>: nombre, descripciones corta y larga, precio y precio anterior (para mostrar descuento), imagen principal y galería de imágenes, categoría, SEO.</li><li><strong>Activar/desactivar</strong>: un producto inactivo no se muestra en el sitio.</li><li><strong>Importar</strong>: permite alta masiva desde archivo (formato indicado en la propia pantalla).</li></ul>\r\n<h3>Categorías</h3>\r\n<ul class=\"dots\"><li>Con nombre, slug, descripción, imagen y orden.</li><li>En el formulario puedes escribir el <strong>nombre de la categoría en cada idioma</strong> (si lo dejas vacío se muestra el nombre principal).</li><li>No se pueden borrar categorías con productos dentro.</li></ul>\r\n<div class=\"nota\">Los productos y categorías del sitio se muestran a través de la página-módulo «Catálogo» (debe existir y estar publicada, igual que la galería).</div>\r\n\r\n<h2 id=\"s9\">9. Plantillas y temas <span class=\"rol admin\">ADMIN</span></h2>\r\n<h3>Plantillas</h3>\r\n<p>Estructuras de página predefinidas con campos concretos (por ejemplo, una plantilla «Contacto» con mapa y horario). Al crear una página de tipo <em>plantilla</em> solo rellenas esos campos. Las plantillas las define el desarrollador.</p>\r\n<h3>Temas</h3>\r\n<p>En <strong>Temas</strong> se activa el aspecto visual del sitio (colores, tipografías, estructura). Activa uno y el cambio es inmediato. Los temas los instala el desarrollador en <code>public/themes/</code>.</p>\r\n<h3>Módulos</h3>\r\n<p><span class=\"rol super\">SUPERADMIN</span> Lista de módulos instalados (Galería, Catálogo…) con interruptor de activar/desactivar. Un módulo desactivado desaparece del sitio y del menú lateral sin perder sus datos.</p>\r\n\r\n<h2 id=\"s10\">10. Usuarios y roles <span class=\"rol admin\">ADMIN</span></h2>\r\n<table>\r\n    <tbody><tr><th>Rol</th><th>Qué puede hacer</th></tr>\r\n    <tr><td><strong>Editor</strong></td><td>Gestionar páginas, menús, medios, galería, catálogo y leer envíos.</td></tr>\r\n    <tr><td><strong>Admin</strong></td><td>Lo anterior + usuarios, ajustes, temas y plantillas.</td></tr>\r\n    <tr><td><strong>Superadmin</strong></td><td>Lo anterior + módulos y copias de seguridad.</td></tr>\r\n</tbody></table>\r\n<ol class=\"steps\"><li><strong>Usuarios → Nuevo usuario</strong>: nombre, email, contraseña, rol y <strong>PIN de desbloqueo</strong> (4-6 dígitos, para la pantalla de bloqueo).</li><li>Desde el listado puedes editar, desactivar o eliminar usuarios.</li></ol>\r\n<div class=\"nota aviso\">Por seguridad, tras 5 intentos fallidos de login, la cuenta se bloquea 15 minutos.</div>\r\n\r\n<h2 id=\"s11\">11. Ajustes <span class=\"rol admin\">ADMIN</span></h2>\r\n<p>Organizados en pestañas:</p>\r\n<ul class=\"dots\"><li><strong>General</strong>: nombre del sitio, <strong>idioma por defecto</strong>, email de contacto, <strong>página de portada</strong> (qué página se muestra al entrar al dominio: la que elijas o la portada del tema) y <strong>modo mantenimiento</strong>.</li><li><strong>SEO</strong>: descripción general del sitio para buscadores.</li><li><strong>Redes sociales</strong>: enlaces a perfiles.</li><li><strong>Empresa</strong>: datos fiscales y de contacto (pueden mostrarse en el pie del sitio según el tema).</li><li><strong>Bloqueo</strong>: minutos de inactividad antes de bloquear la pantalla del panel.</li></ul>\r\n<h3>Modo mantenimiento</h3>\r\n<p>Con el interruptor activado, los visitantes ven una página de «Volvemos enseguida» (error 503, que los buscadores respetan) y tú, estando logueado como admin, ves y trabajas con el sitio con normalidad. Los editores NO ven el sitio en mantenimiento. Para probarlo usa una ventana de incógnito.</p>\r\n<div class=\"nota\">El <strong>sitemap.xml</strong> (mapa del sitio para buscadores) se genera automáticamente e incluye las versiones en cada idioma. Está disponible en <code>/sitemap.xml</code>.</div>\r\n\r\n<h2 id=\"s12\">12. Copias de seguridad <span class=\"rol super\">SUPERADMIN</span></h2>\r\n<ol class=\"steps\"><li><strong>Copias de seguridad → Crear copia</strong>. El sistema empaqueta la base de datos completa y todas las imágenes subidas en un archivo ZIP.</li><li><strong>Descargar</strong> el ZIP y guárdalo fuera del servidor (tu equipo, disco externo, nube).</li><li><strong>Eliminar</strong> las copias antiguas del servidor cuando ya las tengas descargadas — ocupan espacio en el hosting.</li></ol>\r\n<div class=\"nota aviso\"><strong>Restaurar</strong> una copia es una tarea del desarrollador: requiere importar el SQL a la base de datos y descomprimir las imágenes, además de regenerar miniaturas (<code>thumbs:regenerate</code>). No es un proceso del día a día; ante necesidad, contacta con quien mantenga el sitio.</div>\r\n\r\n<h2 id=\"s13\">13. El sitio en varios idiomas</h2>\r\n<p>El CMS es multidioma de serie. Conceptos clave:</p>\r\n<ul class=\"dots\"><li><strong>Idioma por defecto</strong>: el configurado en Ajustes (p. ej. español). Su contenido se sirve sin prefijo en la URL (<code>/quienes-somos</code>).</li><li><strong>Idiomas adicionales</strong>: el visitante cambia con el selector (banderas) en la web; la URL lleva prefijo (<code>/en/about-us</code>).</li><li><strong>Traducción parcial</strong>: cada campo se traduce de forma independiente. Si un campo queda vacío en un idioma, el sitio muestra automáticamente el contenido del idioma por defecto — nunca se rompe.</li><li><strong>Qué se traduce</strong>: títulos y contenidos de páginas, etiquetas de menú, nombres de álbumes y de categorías (incluidas las de noticias), contenidos de artículos de noticias, y textos propios de los módulos (Galería, Catálogo…).</li><li><strong>Slugs (direcciones)</strong>: cada idioma tiene su propia dirección por página; los buscadores reciben la relación entre idiomas (hreflang) automáticamente.</li></ul>\r\n<div class=\"nota\">Consejo de trabajo: redacta primero todo en el idioma por defecto, publica, y después traduce página a página desde sus pestañas de idioma.</div>\r\n\r\n<h2 id=\"s14\">14. Solución de problemas</h2>\r\n<table>\r\n    <tbody><tr><th>Síntoma</th><th>Solución</th></tr>\r\n    <tr><td>Una página da «404 no encontrado»</td><td>Comprueba que está <strong>publicada</strong> (Páginas) y que la URL no tiene errores de mayúsculas.</td></tr>\r\n    <tr><td>La página no aparece en el menú</td><td>Debe estar publicada Y tener activada la opción «Añadir al menú» en su edición. Revisa también que el elemento del menú esté activo en la sección Menús.</td></tr>\r\n    <tr><td>El cambio de idioma lleva a otra página distinta</td><td>Cada página se enlaza con sus traducciones mediante el slug; si una traducción apunta a otra página, revisa las pestañas de idioma de ambas.</td></tr>\r\n    <tr><td>«El sitio está en mantenimiento» y no puedo entrar</td><td>Entra en <kbd>/admin</kbd> (el panel siempre es accesible), desactiva el modo mantenimiento en Ajustes. Si no recuerdas la contraseña, otro admin puede ayudarte.</td></tr>\r\n    <tr><td>La pantalla se bloqueó y no recuerdo el PIN</td><td>Cierra sesión (hay enlace en la pantalla de bloqueo) y entra de nuevo con usuario y contraseña.</td></tr>\r\n    <tr><td>He borrado contenido por error</td><td>Páginas: usa el historial de versiones para restaurar. Resto de contenidos: recupera la última copia de seguridad con ayuda del desarrollador.</td></tr>\r\n    <tr><td>Subo una imagen y no se ve en el sitio</td><td>Comprueba el formato (JPG/PNG/GIF/WebP) y el tamaño (máx. 5 MB). En medios, verifica que el archivo existe y en galería que la imagen está activa y en un álbum existente.</td></tr>\r\n    <tr><td>El buscador del panel no encuentra algo que existe</td><td>Escribe al menos 2 letras y espera medio segundo (busca al dejar de escribir).</td></tr>\r\n                <tr><td>Un artículo de noticias no aparece en el sitio</td><td>Comprueba que está <strong>activo</strong> y que su fecha de publicación no es futura.</td></tr>\r\n</tbody></table>\r\n\r\n<footer>CMS Ainvar · Manual de usuario v1.0 · Para actualizar este manual, edita <code>app/Views/docs/</code> o el documento fuente del proyecto.</footer>\r\n\r\n</main><p><br></p>', NULL, NULL, '', '', 'published', '0', '2026-10-04 13:30:24', '2026-10-04 13:30:24'),
('23', 'es', 'Noticias', 'noticias', 'module', NULL, NULL, 'news', '', '', 'published', '2', '2026-10-05 09:22:11', '2026-10-05 09:22:11');

DROP TABLE IF EXISTS `redirects`;
CREATE TABLE `redirects` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `from_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `to_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `code` smallint NOT NULL DEFAULT '301',
  `hits` int unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `from_path` (`from_path`(250))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `type` enum('string','int','bool','json') CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT 'string',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `settings` (`id`, `key`, `value`, `type`) VALUES
('1', 'site_name', 'CMS Ainvar', 'string'),
('2', 'contact_email', 'admin@ainvarcms.loc', 'string'),
('3', 'site_language', 'es', 'string'),
('4', 'site_meta_desc', '', 'string'),
('5', 'social_facebook', '', 'string'),
('6', 'social_instagram', '', 'string'),
('7', 'social_x', '', 'string'),
('8', 'social_youtube', '', 'string'),
('9', 'company_name', '', 'string'),
('10', 'company_nif', '', 'string'),
('11', 'company_address', '', 'string'),
('12', 'company_city', '', 'string'),
('13', 'company_province', '', 'string'),
('14', 'company_zip', '', 'string'),
('15', 'company_phone', '', 'string'),
('16', 'company_email', '', 'string'),
('17', 'lock_timeout', '20', 'string'),
('18', 'home_page_id', '0', 'int'),
('19', 'maintenance_mode', '0', 'int'),
('20', 'cookies_enabled', '1', 'int'),
('21', 'cookies_banner_title_es', 'Cookies', 'string'),
('22', 'cookies_banner_title_en', 'Cookies', 'string'),
('23', 'cookies_banner_text_es', 'Este sitio web utiliza cookies para mejorar la experiencia del usuario.', 'string'),
('24', 'cookies_banner_text_en', 'This website uses cookies to enhance the user experience.', 'string'),
('25', 'cookies_policy_slug', 'politica-de-privacidad', 'string'),
('26', 'social_bsky', NULL, 'string');

DROP TABLE IF EXISTS `templates`;
CREATE TABLE `templates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `fields` json DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `templates` (`id`, `name`, `slug`, `description`, `file_path`, `fields`, `active`, `created_at`, `updated_at`) VALUES
('1', 'Formulario de contacto', 'contacto', 'Plantilla para un formulario de contacto', '', '[{\"name\": \"nombre\", \"type\": \"text\", \"label\": \"Nombre\"}, {\"name\": \"direccion\", \"type\": \"text\", \"label\": \"Dirección\"}, {\"name\": \"poblacion\", \"type\": \"text\", \"label\": \"Población\"}, {\"name\": \"provincia\", \"type\": \"text\", \"label\": \"Provincia\"}, {\"name\": \"cod_postal\", \"type\": \"number\", \"label\": \"Código postal\"}, {\"name\": \"telefono\", \"type\": \"number\", \"label\": \"Teléfono\"}, {\"name\": \"observaciones\", \"type\": \"textarea\", \"label\": \"Observaciones\"}]', '1', '2026-09-01 08:16:24', '2026-09-10 18:50:57'),
('2', 'Ficha de producto', 'ficha-producto', 'Formulario para fichas de producto', '', '[{\"name\": \"nombre\", \"type\": \"text\", \"label\": \"Nombre\"}, {\"name\": \"precio\", \"type\": \"number\", \"label\": \"Precio\"}, {\"name\": \"precio_anterior\", \"type\": \"number\", \"label\": \"Precio anterior\"}, {\"name\": \"descripcion\", \"type\": \"textarea\", \"label\": \"Descripción\"}, {\"name\": \"imagen\", \"type\": \"image\", \"label\": \"Imagen\"}, {\"name\": \"categoria\", \"type\": \"text\", \"label\": \"Categoría\"}, {\"name\": \"stock\", \"type\": \"number\", \"label\": \"Stock\"}, {\"name\": \"sku\", \"type\": \"text\", \"label\": \"Sku\"}, {\"name\": \"etiquetas\", \"type\": \"text\", \"label\": \"Etiquetas\"}]', '1', '2026-09-01 12:13:09', '2026-09-01 12:13:09');

DROP TABLE IF EXISTS `themes`;
CREATE TABLE `themes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `version` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `screenshot` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `themes` (`id`, `name`, `slug`, `version`, `description`, `path`, `screenshot`, `is_default`, `active`) VALUES
('1', 'Default', 'default', '1.0.0', 'Tema por defecto del CMS', 'default', NULL, '1', '0'),
('6', 'Nature', 'nature', '1.0.0', 'Tema limpio con tonos verdes y tipografía moderna', 'nature', 'assets/screenshot.png', '0', '1'),
('9', 'Horizonte', 'horizonte', '1.0.0', 'Tema claro corporativo con tonos azules y diseño limpio', 'horizonte', 'assets/screenshot.png', '0', '0'),
('8', 'Medianoche', 'medianoche', '1.0.0', 'Tema oscuro elegante con acentos violeta y turquesa', 'medianoche', 'assets/screenshot.png', '0', '0');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `pin` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `role` enum('superadmin','admin','editor') CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT 'editor',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `failed_attempts` int NOT NULL DEFAULT '0',
  `locked_until` datetime DEFAULT NULL,
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `province` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `zip` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `bio` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `show_email` tinyint(1) NOT NULL DEFAULT '0',
  `show_name` tinyint(1) NOT NULL DEFAULT '0',
  `allow_contact` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `users` (`id`, `username`, `first_name`, `last_name`, `phone`, `email`, `password`, `pin`, `role`, `active`, `failed_attempts`, `locked_until`, `avatar`, `created_at`, `updated_at`, `address`, `city`, `province`, `zip`, `bio`, `show_email`, `show_name`, `allow_contact`) VALUES
('1', 'Manuel', 'Manuel', 'Ruiz-Falcó Couto', '653103722', 'admin@cms.local', '$2y$10$Y4XKVjU1rNbkyYDYusAhMu3GhD4bGSn/BGXfUgDl59VjZp5m7sgQm', '$2y$10$UCPWT1jwgGomjW1gfjKG1uEv/CPveCXODvghYb/8aKN.MjDia.RSa', 'superadmin', '1', '0', NULL, 'uploads/avatars/1791535593_961d6655f6d7df104ef7.jpg', '2026-08-30 14:15:34', '2026-10-15 11:36:57', 'Avenida de Madrid 7-6ºB', 'Lugo', 'Lugo', '27002', NULL, '0', '0', '1'),
('2', 'editor', 'Pepito', 'Pérez', '666777555', 'editor@cms.loc', '$2y$10$rh8JZYnDsQGcVHRs5VnnHutq2a.J7g4EJlz8BpNv1NHsqNue0VlHm', '$2y$10$WXZqsLjQEEYzKLrJLcqENuF50l4cbOBVhZjnanjUHPi5Ei5FaVY96', 'editor', '1', '0', NULL, 'uploads/avatars/1791535864_ad12a01e425127333284.jpeg', '2026-10-09 08:49:48', '2026-10-11 12:20:50', 'C/ del Pez, 13', 'Lugo', 'Lugo', '27004', NULL, '0', '0', '1'),
('3', 'admin', '', '', NULL, 'admin1@cms.loc', '$2y$10$ZHTkaPifirbAza6xuAckMu0cks8yj5rbbIaSiQ27Kj8k3ph/77xcW', '$2y$10$UHJoUoiSVyPVuPmQNl4WEu1UTdZXAOdfoP6aRhSWq741hazO/Z/Su', 'admin', '1', '0', NULL, 'uploads/avatars/1791622012_326dde155c2b2a9e3cca.jpg', '2026-10-09 21:58:08', '2026-10-10 09:36:51', NULL, NULL, NULL, NULL, NULL, '0', '0', '1');

SET FOREIGN_KEY_CHECKS=1;
