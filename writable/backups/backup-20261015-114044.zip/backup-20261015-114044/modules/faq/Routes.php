<?php

$routes->group('admin', ['filter' => 'auth'], static function ($routes) {
    $routes->get('faq',                     '\App\Modules\Faq\Controllers\Admin\Faq::index');
    $routes->get('faq/create',              '\App\Modules\Faq\Controllers\Admin\Faq::create');
    $routes->get('faq/edit/(:num)',         '\App\Modules\Faq\Controllers\Admin\Faq::edit/$1');
    $routes->post('faq/save/(:num)',        '\App\Modules\Faq\Controllers\Admin\Faq::save/$1');
    $routes->post('faq/save',               '\App\Modules\Faq\Controllers\Admin\Faq::save');
    $routes->post('faq/delete/(:num)',      '\App\Modules\Faq\Controllers\Admin\Faq::delete/$1');
    $routes->post('faq/move/(:num)/(:alpha)', '\App\Modules\Faq\Controllers\Admin\Faq::move/$1/$2');

    $routes->get('faq/categories',              '\App\Modules\Faq\Controllers\Admin\Faq::categories');
    $routes->get('faq/category/create',         '\App\Modules\Faq\Controllers\Admin\Faq::categoryForm');
    $routes->get('faq/category/edit/(:num)',    '\App\Modules\Faq\Controllers\Admin\Faq::categoryForm/$1');
    $routes->post('faq/category/save/(:num)',   '\App\Modules\Faq\Controllers\Admin\Faq::categorySave/$1');
    $routes->post('faq/category/save',          '\App\Modules\Faq\Controllers\Admin\Faq::categorySave');
    $routes->post('faq/category/delete/(:num)', '\App\Modules\Faq\Controllers\Admin\Faq::categoryDelete/$1');
    $routes->post('faq/category/move/(:num)/(:alpha)', '\App\Modules\Faq\Controllers\Admin\Faq::categoryMove/$1/$2');
});