<?php

return [
    'label'   => 'FAQ',
    'icon'    => 'bi-question-circle',
    'segment' => 'faq', // para detectar activo en admin/faq y admin/faq/categories
    'items'   => [
        [
            'label' => 'Preguntas',
            'url'   => 'admin/faq',
            'icon'  => 'bi-question-lg',
        ],
        [
            'label' => 'Categorías',
            'url'   => 'admin/faq/categories',
            'icon'  => 'bi-tags',
        ],
    ],
];