<?php
/** @var array $faqs */
/** @var string $id */
?>
<div class="accordion" id="<?= esc($id) ?>">
    <?php $i = 0; foreach ($faqs as $f): $i++;
        $abierta = $i === 1; ?>
        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button <?= $abierta ? '' : 'collapsed' ?>" type="button"
                        data-bs-toggle="collapse" data-bs-target="#<?= $id ?>-<?= (int) $f['id'] ?>"
                        aria-expanded="<?= $abierta ? 'true' : 'false' ?>"
                        aria-controls="<?= $id ?>-<?= (int) $f['id'] ?>">
                    <?= esc($f['pregunta']) ?>
                </button>
            </h2>
            <div id="<?= $id ?>-<?= (int) $f['id'] ?>"
                 class="accordion-collapse collapse <?= $abierta ? 'show' : '' ?>"
                 data-bs-parent="#<?= esc($id) ?>">
                <div class="accordion-body">
                    <?= $f['respuesta'] /* HTML de admin de confianza, como el content de páginas */ ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>