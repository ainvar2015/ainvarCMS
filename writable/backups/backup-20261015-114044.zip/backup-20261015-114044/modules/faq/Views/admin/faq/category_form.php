<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= esc($title) ?></h1>
    <a href="<?= base_url('admin/faq/categories') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Volver
    </a>
</div>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger"><ul class="mb-0">
        <?php foreach (session()->getFlashdata('errors') as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?>
    </ul></div>
<?php endif; ?>

<form action="<?= $action ?>" method="post">
    <?= csrf_field() ?>
    <div class="card shadow-sm">
        <div class="card-header bg-white">
            <ul class="nav nav-tabs card-header-tabs" id="langTabs">
                <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="tab" href="#tab-<?= default_lang() ?>">
                        <?= strtoupper(default_lang()) ?> (principal)
                    </a>
                </li>
                <?php foreach ($otherLangs as $l): ?>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#tab-<?= $l['code'] ?>">
                            <?= strtoupper($l['code']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div class="card-body tab-content">
            <div class="tab-pane fade show active" id="tab-<?= default_lang() ?>">
                <label class="form-label fw-bold">Nombre <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" required
                       value="<?= old('name', $trans[default_lang()]['name'] ?? '') ?>">
                <div class="form-text">El slug se genera automáticamente del nombre.</div>
            </div>
            <?php foreach ($otherLangs as $l): $code = $l['code']; $t = $trans[$code] ?? []; ?>
                <div class="tab-pane fade" id="tab-<?= $code ?>">
                    <label class="form-label fw-bold">Nombre (<?= strtoupper($code) ?>)</label>
                    <input type="text" name="trans[<?= $code ?>][name]" class="form-control"
                           value="<?= old("trans.$code.name", $t['name'] ?? '') ?>">
                    <div class="form-text">Vacío = usa el nombre en <?= strtoupper(default_lang()) ?>.</div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="card-footer bg-white">
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" name="active" value="1" id="act"
                    <?= old('active', $category['active'] ?? 1) ? 'checked' : '' ?>>
                <label class="form-check-label" for="act">Activa</label>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-check-lg"></i> <?= !empty($category) ? 'Guardar cambios' : 'Crear categoría' ?>
            </button>
        </div>
    </div>
</form>
<?php $this->endSection() ?>