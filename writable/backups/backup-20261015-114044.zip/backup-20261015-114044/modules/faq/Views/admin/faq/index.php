<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= esc($title) ?></h1>
    <div class="d-flex gap-2">
        <a href="<?= base_url('admin/faq/categories') ?>" class="btn btn-outline-secondary">
            <i class="bi bi-folder"></i> Categorías
        </a>
        <a href="<?= base_url('admin/faq/create') ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg"></i> Nueva pregunta
        </a>
    </div>
</div>

<form method="get" action="<?= base_url('admin/faq') ?>" class="mb-3">
    <select name="categoria" class="form-select w-auto" onchange="this.form.submit()">
        <option value="0">Todas las categorías</option>
        <?php foreach ($categories as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $catId === (int) $c['id'] ? 'selected' : '' ?>>
                <?= esc($catTrDef[$c['id']]['name'] ?? $c['slug']) ?>
            </option>
        <?php endforeach; ?>
    </select>
</form>

<div class="card shadow-sm">
    <div class="card-body">
        <table class="table table-hover align-middle mb-0">
            <thead><tr>
                <th style="width:90px">Orden</th><th>Pregunta</th><th>Categoría</th>
                <th>Idiomas</th><th>Activa</th><th class="text-end" style="width:120px">Acciones</th>
            </tr></thead>
            <tbody>
            <?php foreach ($faqs as $f): ?>
                <tr>
                    <td>
                        <form method="post" action="<?= base_url("admin/faq/move/{$f['id']}/up") ?>" class="d-inline"><?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline-secondary py-0 px-1">▲</button></form>
                        <form method="post" action="<?= base_url("admin/faq/move/{$f['id']}/down") ?>" class="d-inline"><?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline-secondary py-0 px-1">▼</button></form>
                    </td>
                    <td><?= esc($trDef[$f['id']]['pregunta'] ?? '— sin traducción —') ?></td>
                    <td><?= $f['category_id'] ? esc($catTrDef[$f['category_id']]['name'] ?? '—') : '<span class="text-muted">Sin categoría</span>' ?></td>
                    <td>
                        <?php foreach ($langsConTr[$f['id']] ?? [] as $l): ?>
                            <span class="badge text-bg-light border"><?= esc($l) ?></span>
                        <?php endforeach; ?>
                    </td>
                    <td><?= $f['active'] ? '<i class="bi bi-check-circle-fill text-success"></i>' : '<i class="bi bi-x-circle text-muted"></i>' ?></td>
                    <td class="text-end">
                        <a href="<?= base_url("admin/faq/edit/{$f['id']}") ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                        <form method="post" action="<?= base_url("admin/faq/delete/{$f['id']}") ?>" class="d-inline"
                              onsubmit="return confirm('¿Eliminar esta pregunta?')"><?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($faqs)): ?>
                <tr><td colspan="6" class="text-muted py-4 text-center">Sin preguntas todavía.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $this->endSection() ?>