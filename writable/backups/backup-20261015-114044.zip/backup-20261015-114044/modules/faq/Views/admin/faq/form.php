<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<?php $isEdit = !empty($faq); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= esc($title) ?></h1>
    <a href="<?= base_url('admin/faq') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Volver
    </a>
</div>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger"><ul class="mb-0">
        <?php foreach (session()->getFlashdata('errors') as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?>
    </ul></div>
<?php endif; ?>

<form action="<?= $action ?>" method="post">
    <?= csrf_field() ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <ul class="nav nav-tabs card-header-tabs" id="langTabs">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#tab-<?= default_lang() ?>">
                                <?= strtoupper(default_lang()) ?> (principal)
                            </a>
                        </li>
                        <?php foreach ($otherLangs as $l): ?>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#tab-<?= $l['code'] ?>">
                                    <?= strtoupper($l['code']) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="card-body tab-content">
                    <!-- Idioma por defecto: campos planos -->
                    <div class="tab-pane fade show active" id="tab-<?= default_lang() ?>">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Pregunta <span class="text-danger">*</span></label>
                            <input type="text" name="pregunta" class="form-control" required
                                   value="<?= old('pregunta', $trans[default_lang()]['pregunta'] ?? '') ?>">
                        </div>
                        <div class="mb-0">
                            <label class="form-label">Respuesta</label>
                            <textarea name="respuesta" id="respuesta-default" class="form-control" rows="8"><?= old('respuesta', $trans[default_lang()]['respuesta'] ?? '') ?></textarea>
                        </div>
                    </div>

                    <!-- Otros idiomas: trans[code][campo] -->
                    <?php foreach ($otherLangs as $l): $code = $l['code']; $t = $trans[$code] ?? []; ?>
                        <div class="tab-pane fade" id="tab-<?= $code ?>">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Pregunta (<?= strtoupper($code) ?>)</label>
                                <input type="text" name="trans[<?= $code ?>][pregunta]" class="form-control"
                                       value="<?= old("trans.$code.pregunta", $t['pregunta'] ?? '') ?>">
                                <div class="form-text">Vacío = usa la pregunta en <?= strtoupper(default_lang()) ?>.</div>
                            </div>
                            <div class="mb-0">
                                <label class="form-label">Respuesta (<?= strtoupper($code) ?>)</label>
                                <textarea name="trans[<?= $code ?>][respuesta]" id="respuesta-<?= $code ?>" class="form-control" rows="8"><?= old("trans.$code.respuesta", $t['respuesta'] ?? '') ?></textarea>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Categoría</label>
                        <select name="category_id" class="form-select">
                            <option value="">— Sin categoría —</option>
                            <?php foreach ($catList as $cid => $cname): ?>
                                <option value="<?= $cid ?>" <?= old('category_id', $faq['category_id'] ?? '') == $cid ? 'selected' : '' ?>>
                                    <?= esc($cname) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="active" value="1" id="act"
                            <?= old('active', $faq['active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="act">Activa</label>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-check-lg"></i> <?= $isEdit ? 'Guardar cambios' : 'Crear pregunta' ?>
            </button>
        </div>
    </div>
</form>
<?php $this->endSection() ?>

<?php $this->section('js') ?>
<script>
    // Summernote por ID, un init por editor (mismo patrón que News)
    document.addEventListener('DOMContentLoaded', () => {
        const ids = ['respuesta-default'<?php foreach ($otherLangs as $l): ?>, 'respuesta-<?= $l['code'] ?>'<?php endforeach; ?>];
        ids.forEach(id => {
            const el = document.getElementById(id);
            if (el && !$(el).hasClass('note-editor') && !$(el).next().hasClass('note-editor')) {
                $(el).summernote({
                    height: 250,
                    lang: 'es-ES',
                    toolbar: [
                        ['style', ['bold', 'italic', 'underline', 'clear']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        ['insert', ['link']],
                        ['view', ['codeview']]
                    ]
                });
            }
        });
    });
</script>
<?php $this->endSection() ?>