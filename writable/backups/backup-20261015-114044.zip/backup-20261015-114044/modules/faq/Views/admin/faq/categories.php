<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= esc($title) ?></h1>
    <div class="d-flex gap-2">
        <a href="<?= base_url('admin/faq') ?>" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left"></i> Preguntas
        </a>
        <a href="<?= base_url('admin/faq/category/create') ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg"></i> Nueva categoría
        </a>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <table class="table table-hover align-middle mb-0">
            <thead><tr>
                <th style="width:90px">Orden</th><th>Nombre</th><th>Slug</th>
                <th>Preguntas</th><th>Activa</th><th class="text-end" style="width:120px">Acciones</th>
            </tr></thead>
            <tbody>
            <?php foreach ($categories as $c): ?>
                <tr>
                    <td>
                        <form method="post" action="<?= base_url("admin/faq/category/move/{$c['id']}/up") ?>" class="d-inline"><?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline-secondary py-0 px-1">▲</button></form>
                        <form method="post" action="<?= base_url("admin/faq/category/move/{$c['id']}/down") ?>" class="d-inline"><?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline-secondary py-0 px-1">▼</button></form>
                    </td>
                    <td><?= esc($trDef[$c['id']]['name'] ?? '—') ?></td>
                    <td><code><?= esc($c['slug']) ?></code></td>
                    <td><span class="badge text-bg-light border"><?= $conteos[$c['id']] ?? 0 ?></span></td>
                    <td><?= $c['active'] ? '<i class="bi bi-check-circle-fill text-success"></i>' : '<i class="bi bi-x-circle text-muted"></i>' ?></td>
                    <td class="text-end">
                        <a href="<?= base_url("admin/faq/category/edit/{$c['id']}") ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                        <form method="post" action="<?= base_url("admin/faq/category/delete/{$c['id']}") ?>" class="d-inline"
                              onsubmit="return confirm('¿Eliminar esta categoría?')"><?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($categories)): ?>
                <tr><td colspan="6" class="text-muted py-4 text-center">Sin categorías todavía.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $this->endSection() ?>