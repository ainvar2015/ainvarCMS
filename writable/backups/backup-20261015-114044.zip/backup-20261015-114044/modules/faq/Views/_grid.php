<?php
/** @var array $faqs */
/** @var bool $agrupar */

if (empty($faqs)) {
    echo '<p class="text-muted">' . lang('Faq.empty') . '</p>';
    return;
}

// ¿Hay categorías reales (más allá de null)?
$conCategorias = $agrupar && count(array_filter(array_column($faqs, 'category_name'))) > 0;

if (!$conCategorias): ?>
    <?= view('App\Modules\Faq\Views\_accordion', ['faqs' => $faqs, 'id' => 'faqAccordion']) ?>
<?php else:
    $grupos = [];
    foreach ($faqs as $f) {
        $grupos[$f['category_name'] ?: lang('Faq.general')][] = $f;
    }
    foreach ($grupos as $nombre => $items):
        $id = 'faq-' . slugify($nombre); ?>
        <h3 class="h5 mt-4"><?= esc($nombre) ?></h3>
        <?= view('App\Modules\Faq\Views\_accordion', ['faqs' => $items, 'id' => $id]) ?>
    <?php endforeach;
endif; ?>