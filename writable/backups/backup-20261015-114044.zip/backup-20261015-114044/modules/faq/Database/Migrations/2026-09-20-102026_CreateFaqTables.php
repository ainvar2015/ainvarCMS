<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateFaqTables extends Migration
{
    public function up()
    {
        // Categorías
        $this->forge->addField([
            'id'         => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'slug'       => ['type' => 'VARCHAR', 'constraint' => 191],
            'position'   => ['type' => 'INT', 'constraint' => 11, 'default' => 0],
            'active'     => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'created_at' => ['type' => 'DATETIME', 'null' => true],
            'updated_at' => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('faq_categories');

        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'category_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'language'    => ['type' => 'VARCHAR', 'constraint' => 10],
            'name'        => ['type' => 'VARCHAR', 'constraint' => 191],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey(['category_id', 'language'], false, true); // único compuesto
        $this->forge->createTable('faq_category_translations');

        // Preguntas
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'category_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'position'    => ['type' => 'INT', 'constraint' => 11, 'default' => 0],
            'active'      => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('faqs');

        $this->forge->addField([
            'id'        => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'faq_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'language'  => ['type' => 'VARCHAR', 'constraint' => 10],
            'pregunta'  => ['type' => 'VARCHAR', 'constraint' => 255],
            'respuesta' => ['type' => 'TEXT'],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey(['faq_id', 'language'], false, true); // único compuesto
        $this->forge->createTable('faq_translations');
    }

    public function down()
    {
        $this->forge->dropTable('faq_translations');
        $this->forge->dropTable('faqs');
        $this->forge->dropTable('faq_category_translations');
        $this->forge->dropTable('faq_categories');
    }
}
