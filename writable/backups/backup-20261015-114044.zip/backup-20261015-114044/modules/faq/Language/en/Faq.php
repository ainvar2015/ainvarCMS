<?php

return [
    'module_name'      => 'FAQ',
    'preguntas'        => 'Questions',
    'categorias'       => 'Categories',
    'saved'            => 'FAQ saved successfully.',
    'deleted'          => 'FAQ deleted.',
    'category_saved'   => 'Category saved successfully.',
    'category_deleted' => 'Category deleted.',
    'category_in_use'  => 'Cannot delete: the category has associated questions.',
    'empty'   => 'No frequently asked questions yet.',
    'general' => 'General',
];