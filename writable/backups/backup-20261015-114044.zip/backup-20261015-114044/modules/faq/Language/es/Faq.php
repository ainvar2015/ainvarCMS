<?php

return [
    'module_name'      => 'FAQ',
    'preguntas'        => 'Preguntas',
    'categorias'       => 'Categorías',
    'saved'            => 'FAQ guardada correctamente.',
    'deleted'          => 'FAQ eliminada.',
    'category_saved'   => 'Categoría guardada correctamente.',
    'category_deleted' => 'Categoría eliminada.',
    'category_in_use'  => 'No se puede eliminar: la categoría tiene preguntas asociadas.',
    'empty'   => 'No hay preguntas frecuentes todavía.',
    'general' => 'General',
];