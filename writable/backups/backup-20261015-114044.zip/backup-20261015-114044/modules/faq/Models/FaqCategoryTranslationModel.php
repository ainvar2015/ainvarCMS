<?php

namespace App\Modules\Faq\Models;

use CodeIgniter\Model;

class FaqCategoryTranslationModel extends Model
{
    protected $table         = 'faq_category_translations';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['category_id', 'language', 'name'];
    protected $returnType    = 'array';
}