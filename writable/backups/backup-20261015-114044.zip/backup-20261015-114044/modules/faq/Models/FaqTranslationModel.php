<?php

namespace App\Modules\Faq\Models;

use CodeIgniter\Model;

class FaqTranslationModel extends Model
{
    protected $table         = 'faq_translations';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['faq_id', 'language', 'pregunta', 'respuesta'];
    protected $returnType    = 'array';
}