<?php

namespace App\Modules\Faq\Models;

use CodeIgniter\Model;

class FaqModel extends Model
{
    protected $table         = 'faqs';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['category_id', 'position', 'active'];
    protected $useTimestamps = true;
    protected $returnType    = 'array';

    public function getForFront(?string $categorySlug = null, int $limit = 0): array
    {
        $lang    = current_lang();
        $default = default_lang();

        $builder = $this->where('active', 1)->orderBy('category_id', 'ASC')->orderBy('position', 'ASC');
        if ($categorySlug !== null && $categorySlug !== '') {
            $cat = (new FaqCategoryModel())->where('slug', $categorySlug)->first();
            if (!$cat) return [];
            $builder->where('category_id', $cat['id']);
        }
        if ($limit > 0) $builder->limit($limit);

        $faqs = $builder->findAll();
        if (!$faqs) return [];

        $trs = (new FaqTranslationModel())
            ->whereIn('faq_id', array_column($faqs, 'id'))->findAll();

        $cats   = (new FaqCategoryModel())->where('active', 1)->orderBy('position', 'ASC')->findAll();
        $catTrs = (new FaqCategoryTranslationModel())
            ->whereIn('category_id', array_column($cats, 'id') ?: [0])->findAll();

        $catNames = [];
        foreach ($cats as $c) {
            $tr = $this->pickTranslation($catTrs, 'category_id', (int) $c['id'], $lang, $default);
            $catNames[$c['id']] = $tr['name'] ?? $c['slug'];
        }

        $out = [];
        foreach ($faqs as $f) {
            $tr = $this->pickTranslation($trs, 'faq_id', (int) $f['id'], $lang, $default);
            if (!$tr) continue;
            $out[] = [
                'id'            => $f['id'],
                'category_id'   => $f['category_id'],
                'category_name' => $f['category_id'] ? ($catNames[$f['category_id']] ?? '') : '',
                'pregunta'      => $tr['pregunta'],
                'respuesta'     => $tr['respuesta'],
            ];
        }
        return $out;
    }

    private function pickTranslation(array $rows, string $fk, int $id, string $lang, string $default): ?array
    {
        foreach ($rows as $r) if ((int) $r[$fk] === $id && $r['language'] === $lang)    return $r;
        foreach ($rows as $r) if ((int) $r[$fk] === $id && $r['language'] === $default) return $r;
        foreach ($rows as $r) if ((int) $r[$fk] === $id) return $r;
        return null;
    }

    public function nextPosition(?int $categoryId): int
    {
        $builder = $this->selectMax('position');
        if ($categoryId) {
            $builder->where('category_id', $categoryId);
        } else {
            $builder->where('category_id IS NULL');
        }
        return (int) ($builder->first()['position'] ?? 0) + 1;
    }
}
