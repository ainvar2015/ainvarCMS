<?php

namespace App\Modules\Faq\Models;

use CodeIgniter\Model;

class FaqCategoryModel extends Model
{
    protected $table         = 'faq_categories';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['slug', 'position', 'active'];
    protected $useTimestamps = true;
    protected $returnType    = 'array';
}