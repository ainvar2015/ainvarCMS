<?php

namespace App\Modules\Faq\Controllers\Front;

use App\Controllers\BaseController;
use App\Modules\Faq\Models\FaqModel;

class Faq extends BaseController
{
    public $embed = true;

    public function index(): string
    {
        $slug  = $this->request->getGet('categoria');
        $limit = (int) ($this->request->getGet('limite') ?: 0);

        $faqs = (new FaqModel())->getForFront($slug ?: null, $limit);

        return view('App\Modules\Faq\Views\_grid', [
            'faqs'    => $faqs,
            'agrupar' => empty($slug), // con categorías visibles se agrupa por secciones
        ]);
    }
}
