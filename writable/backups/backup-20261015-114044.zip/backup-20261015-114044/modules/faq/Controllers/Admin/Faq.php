<?php

namespace App\Modules\Faq\Controllers\Admin;

use App\Controllers\Admin\ModuleController;
use App\Modules\Faq\Models\FaqModel;
use App\Modules\Faq\Models\FaqTranslationModel;
use App\Modules\Faq\Models\FaqCategoryModel;
use App\Modules\Faq\Models\FaqCategoryTranslationModel;

class Faq extends ModuleController
{
    protected function moduleNamespace(): string
    {
        return 'App\Modules\Faq';
    }

    // ---------- PREGUNTAS ----------

    public function index()
    {
        $default  = default_lang();
        $faqModel = new FaqModel();
        $trModel  = new FaqTranslationModel();
        $catModel = new FaqCategoryModel();
        $catTr    = new FaqCategoryTranslationModel();

        $catId   = (int) ($this->request->getGet('categoria') ?: 0);
        $builder = $faqModel->orderBy('category_id', 'ASC')->orderBy('position', 'ASC');
        if ($catId) $builder->where('category_id', $catId);
        $faqs = $builder->findAll();

        $faqIds = array_column($faqs, 'id') ?: [0];
        $trDef = array_column(
            $trModel->whereIn('faq_id', $faqIds)->where('language', $default)->findAll(),
            null, 'faq_id'
        );

        $langsConTr = [];
        foreach ($trModel->whereIn('faq_id', $faqIds)->findAll() as $r) {
            $langsConTr[$r['faq_id']][] = $r['language'];
        }

        $categories = $catModel->orderBy('position', 'ASC')->findAll();
        $catTrDef = array_column(
            $catTr->whereIn('category_id', array_column($categories, 'id') ?: [0])->where('language', $default)->findAll(),
            null, 'category_id'
        );

        return $this->renderModule('faq/index', [
            'title'      => lang('Faq.preguntas'),
            'faqs'       => $faqs,
            'trDef'      => $trDef,
            'langsConTr' => $langsConTr,
            'categories' => $categories,
            'catTrDef'   => $catTrDef,
            'catId'      => $catId,
        ]);
    }

    public function create()      { return $this->form(); }
    public function edit(int $id) { return $this->form($id); }

    private function form(?int $id = null)
    {
        $faqModel = new FaqModel();
        $faq = $id ? $faqModel->find($id) : null;
        if ($id && !$faq) return redirect()->to('admin/faq')->with('errors', ['La pregunta no existe.']);

        $trans = [];
        if ($faq) {
            foreach ((new FaqTranslationModel())->where('faq_id', $faq['id'])->findAll() as $t) {
                $trans[$t['language']] = $t;
            }
        }

        // Nombres de categoría en idioma por defecto (para el select)
        $catRows = (new FaqCategoryModel())->orderBy('position', 'ASC')->findAll();
        $catTrDef = array_column(
            (new FaqCategoryTranslationModel())
                ->whereIn('category_id', array_column($catRows, 'id') ?: [0])
                ->where('language', default_lang())->findAll(),
            null, 'category_id'
        );
        $catList = [];
        foreach ($catRows as $c) {
            $catList[$c['id']] = $catTrDef[$c['id']]['name'] ?? $c['slug'];
        }

        return $this->renderModule('faq/form', [
            'title'      => $faq ? 'Editar pregunta' : 'Nueva pregunta',
            'action'     => base_url('admin/faq/save' . ($faq ? '/' . $faq['id'] : '')),
            'faq'        => $faq,
            'trans'      => $trans,
            'otherLangs' => $this->otherLangs(),
            'catList'    => $catList,
        ]);
    }

    public function save(?int $id = null)
    {
        $faqModel = new FaqModel();
        $default  = default_lang();

        $preguntaDef  = trim((string) $this->request->getPost('pregunta'));
        $respuestaDef = trim((string) $this->request->getPost('respuesta'));

        if ($preguntaDef === '') {
            return redirect()->back()->withInput()
                ->with('errors', ['La pregunta (' . strtoupper($default) . ') es obligatoria.']);
        }

        $data = [
            'category_id' => $this->request->getPost('category_id') ?: null,
            'active'      => $this->request->getPost('active') ? 1 : 0,
        ];

        if ($id) {
            if (!$faqModel->find($id)) {
                return redirect()->to('admin/faq')->with('errors', ['La pregunta no existe.']);
            }
            $faqModel->update($id, $data);
        } else {
            $data['position'] = $faqModel->nextPosition((int) $data['category_id']);
            $id = (int) $faqModel->insert($data);
        }

        $this->upsertTranslation($id, $default, $preguntaDef, $respuestaDef);

        $trans = (array) $this->request->getPost('trans');
        foreach (active_languages() as $l) {
            $code = $l['code'] ?? $l;
            if ($code === $default) continue;
            $p = trim($trans[$code]['pregunta'] ?? '');
            $r = trim($trans[$code]['respuesta'] ?? '');
            if ($p === '' && $r === '') continue; // pestaña vacía: no se guarda
            $this->upsertTranslation($id, $code, $p, $r);
        }

        return redirect()->to('admin/faq')->with('success', lang('Faq.saved'));
    }

    public function delete(int $id)
    {
        (new FaqTranslationModel())->where('faq_id', $id)->delete();
        (new FaqModel())->delete($id);
        return redirect()->to('admin/faq')->with('success', lang('Faq.deleted'));
    }

    public function move(int $id, string $dir)
    {
        $faqModel = new FaqModel();
        $faq = $faqModel->find($id);
        if (!$faq) return redirect()->back();

        // where('category_id', null) genera IS NULL en CI4: correcto aquí
        $neighbor = $faqModel->where('category_id', $faq['category_id'])
            ->where('position ' . ($dir === 'up' ? '<' : '>'), $faq['position'])
            ->orderBy('position', $dir === 'up' ? 'DESC' : 'ASC')
            ->first();

        if ($neighbor) {
            $faqModel->update($id, ['position' => $neighbor['position']]);
            $faqModel->update($neighbor['id'], ['position' => $faq['position']]);
        }
        return redirect()->back();
    }

    // ---------- CATEGORÍAS ----------

    public function categories()
    {
        $catModel = new FaqCategoryModel();
        $catTr    = new FaqCategoryTranslationModel();
        $default  = default_lang();

        $categories = $catModel->orderBy('position', 'ASC')->findAll();
        $trDef = array_column(
            $catTr->whereIn('category_id', array_column($categories, 'id') ?: [0])->where('language', $default)->findAll(),
            null, 'category_id'
        );

        $conteos = [];
        if ($categories) {
            $rows = \Config\Database::connect()->table('faqs')
                ->select('category_id, COUNT(*) AS n')
                ->whereIn('category_id', array_column($categories, 'id'))
                ->groupBy('category_id')->get()->getResultArray();
            foreach ($rows as $r) $conteos[$r['category_id']] = (int) $r['n'];
        }

        return $this->renderModule('faq/categories', [
            'title'      => lang('Faq.categorias'),
            'categories' => $categories,
            'trDef'      => $trDef,
            'conteos'    => $conteos,
        ]);
    }

    public function categoryForm(?int $id = null)
    {
        $catModel = new FaqCategoryModel();
        $category = $id ? $catModel->find($id) : null;
        if ($id && !$category) {
            return redirect()->to('admin/faq/categories')->with('errors', ['La categoría no existe.']);
        }

        $trans = [];
        if ($category) {
            foreach ((new FaqCategoryTranslationModel())->where('category_id', $category['id'])->findAll() as $t) {
                $trans[$t['language']] = $t;
            }
        }

        return $this->renderModule('faq/category_form', [
            'title'      => $category ? 'Editar categoría' : 'Nueva categoría',
            'action'     => base_url('admin/faq/category/save' . ($category ? '/' . $category['id'] : '')),
            'category'   => $category,
            'trans'      => $trans,
            'otherLangs' => $this->otherLangs(),
        ]);
    }

    public function categorySave(?int $id = null)
    {
        $catModel = new FaqCategoryModel();
        $default  = default_lang();

        $nombreDef = trim((string) $this->request->getPost('name'));
        if ($nombreDef === '') {
            return redirect()->back()->withInput()
                ->with('errors', ['El nombre (' . strtoupper($default) . ') es obligatorio.']);
        }

        $data = ['active' => $this->request->getPost('active') ? 1 : 0];

        if ($id) {
            if (!$catModel->find($id)) {
                return redirect()->to('admin/faq/categories')->with('errors', ['La categoría no existe.']);
            }
            // El slug NO se regenera al editar: no rompe [faq categoria="x"] ni enlaces existentes
            $catModel->update($id, $data);
        } else {
            $data['slug']     = $this->uniqueSlug(slugify($nombreDef));
            $data['position'] = (int) (($catModel->selectMax('position')->first())['position'] ?? 0) + 1;
            $id = (int) $catModel->insert($data);
        }

        $this->upsertCategoryTranslation($id, $default, $nombreDef);

        $trans = (array) $this->request->getPost('trans');
        foreach (active_languages() as $l) {
            $code = $l['code'] ?? $l;
            if ($code === $default) continue;
            $name = trim($trans[$code]['name'] ?? '');
            if ($name === '') continue;
            $this->upsertCategoryTranslation($id, $code, $name);
        }

        return redirect()->to('admin/faq/categories')->with('success', lang('Faq.category_saved'));
    }

    public function categoryDelete(int $id)
    {
        if ((new FaqModel())->where('category_id', $id)->countAllResults() > 0) {
            return redirect()->to('admin/faq/categories')->with('error', lang('Faq.category_in_use'));
        }
        (new FaqCategoryTranslationModel())->where('category_id', $id)->delete();
        (new FaqCategoryModel())->delete($id);
        return redirect()->to('admin/faq/categories')->with('success', lang('Faq.category_deleted'));
    }

    public function categoryMove(int $id, string $dir)
    {
        $catModel = new FaqCategoryModel();
        $cat = $catModel->find($id);
        if (!$cat) return redirect()->back();

        $neighbor = $catModel->where('position ' . ($dir === 'up' ? '<' : '>'), $cat['position'])
            ->orderBy('position', $dir === 'up' ? 'DESC' : 'ASC')->first();

        if ($neighbor) {
            $catModel->update($id, ['position' => $neighbor['position']]);
            $catModel->update($neighbor['id'], ['position' => $cat['position']]);
        }
        return redirect()->back();
    }

    // ---------- Helpers ----------

    private function otherLangs(): array
    {
        $default = default_lang();
        return array_values(array_filter(active_languages(), function ($l) use ($default) {
            return ($l['code'] ?? $l) !== $default;
        }));
    }

    private function upsertTranslation(int $faqId, string $lang, string $pregunta, string $respuesta): void
    {
        $trModel  = new FaqTranslationModel();
        $existing = $trModel->where('faq_id', $faqId)->where('language', $lang)->first();
        $row = ['faq_id' => $faqId, 'language' => $lang, 'pregunta' => $pregunta, 'respuesta' => $respuesta];
        if ($existing) $trModel->update($existing['id'], $row);
        else           $trModel->insert($row);
    }

    private function upsertCategoryTranslation(int $categoryId, string $lang, string $name): void
    {
        $catTr    = new FaqCategoryTranslationModel();
        $existing = $catTr->where('category_id', $categoryId)->where('language', $lang)->first();
        $row = ['category_id' => $categoryId, 'language' => $lang, 'name' => $name];
        if ($existing) $catTr->update($existing['id'], $row);
        else           $catTr->insert($row);
    }

    private function uniqueSlug(string $slug): string
    {
        $base = $slug; $i = 2;
        while ((new FaqCategoryModel())->where('slug', $slug)->first()) {
            $slug = $base . '-' . $i++;
        }
        return $slug;
    }
}