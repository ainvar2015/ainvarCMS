<?php

namespace App\Modules\I18n\Models;

use CodeIgniter\Model;

class LanguageModel extends Model
{
    protected $table      = 'languages';
    protected $primaryKey = 'id';
    protected $allowedFields = ['code','name','flag','is_default','active','sort_order'];

    public function getActive()
    {
        return $this->where('active', 1)->orderBy('sort_order', 'ASC')->findAll();
    }

    public function getActiveCodes()
    {
        return array_column($this->where('active', 1)->findAll(), 'code');
    }

    public function getDefault()
    {
        return $this->where('is_default', 1)->where('active', 1)->first();
    }
}