<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<?php $isEdit = !empty($language);
$l = $language ?? []; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= $title ?></h1>
    <a href="<?= base_url('admin/languages') ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Volver</a>
</div>

<div class="row">
    <div class="col-lg-6">
        <form action="<?= $action ?>" method="post">
            <?= csrf_field() ?>
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Código <span class="text-danger">*</span></label>
                        <input type="text" name="code" class="form-control" maxlength="5" value="<?= old('code', $l['code'] ?? '') ?>" placeholder="es, en, fr..." required>
                        <div class="form-text">Código ISO de 2 letras. Ej: es, en, fr, de.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nombre <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" value="<?= old('name', $l['name'] ?? '') ?>" placeholder="Español" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Bandera</label>
                        <?php
                        $presetFlags = ['🇪🇸', '🇬🇧', '🇺🇸', '🇫🇷', '🇩🇪', '🇦🇹', '🇵🇹', '🇧🇷', '🇮🇹', '🇳🇱', '🇧🇪', '🇨🇭', '🇮🇪', '🇬🇷', '🇵🇱', '🇷🇺', '🇨🇳', '🇯🇵', '🇰🇷', '🇦🇷', '🇲🇽', '🇨🇴', '🏳️'];
                        $currentFlag = old('flag', $language['flag'] ?? '');
                        ?>
                        <select name="flag" class="form-select" style="max-width:200px;">
                            <option value="">— Sin bandera —</option>
                            <?php foreach ($presetFlags as $f): ?>
                                <option value="<?= $f ?>" <?= $currentFlag === $f ? 'selected' : '' ?>><?= $f ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Se muestra en el selector de idiomas del front y en las pestañas de traducción.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Orden</label>
                        <input type="number" name="sort_order" class="form-control" value="<?= old('sort_order', $l['sort_order'] ?? 0) ?>">
                    </div>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="active" value="1" id="act" <?= old('active', $l['active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="act">Activo</label>
                    </div>
                    <?php if ($isEdit && !$l['is_default']): ?>
                        <div class="form-check form-switch mb-0">
                            <input class="form-check-input" type="checkbox" name="is_default" value="1" id="def">
                            <label class="form-check-label" for="def">Marcar como idioma por defecto</label>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-footer text-end">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Guardar</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $this->endSection() ?>