<?php

namespace App\Modules\I18n\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Modules\I18n\Models\LanguageModel;

class Languages extends BaseController
{
    protected $helpers = ['url', 'form', 'html'];

    public function index()
    {
        $model = new LanguageModel();
        return $this->renderModule('languages/index', [
            'title'     => 'Idiomas',
            'languages' => $model->orderBy('sort_order', 'ASC')->findAll(),
        ]);
    }

    public function create()
    {
        return $this->renderModule('languages/form', [
            'title'    => 'Nuevo idioma',
            'language' => null,
            'action'   => base_url('admin/languages/store'),
        ]);
    }

    public function store()
    {
        $rules = [
            'code' => 'required|min_length[2]|max_length[5]|is_unique[languages.code]',
            'name' => 'required|min_length[2]|max_length[50]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $model = new LanguageModel();
        $model->insert([
            'code'       => strtolower($this->request->getPost('code')),
            'name'       => $this->request->getPost('name'),
            'flag'       => $this->request->getPost('flag') ?: null,
            'active'     => $this->request->getPost('active') ? 1 : 0,
            'sort_order' => (int) ($this->request->getPost('sort_order') ?: 0),
        ]);

        return redirect()->to('/admin/languages')->with('success', 'Idioma creado.');
    }

    public function edit($id)
    {
        $model = new LanguageModel();
        $lang = $model->find($id);
        if (!$lang) return redirect()->to('/admin/languages')->with('error', 'No encontrado.');

        return $this->renderModule('languages/form', [
            'title'    => 'Editar idioma',
            'language' => $lang,
            'action'   => base_url('admin/languages/update/' . $id),
        ]);
    }

    public function update($id)
    {
        $model = new LanguageModel();
        $lang = $model->find($id);
        if (!$lang) return redirect()->to('/admin/languages')->with('error', 'No encontrado.');

        $rules = [
            'code' => "required|min_length[2]|max_length[5]|is_unique[languages.code,id,{$id}]",
            'name' => 'required|min_length[2]|max_length[50]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'code'       => strtolower($this->request->getPost('code')),
            'name'       => $this->request->getPost('name'),
            'flag'       => $this->request->getPost('flag') ?: null,
            'active'     => $this->request->getPost('active') ? 1 : 0,
            'sort_order' => (int) ($this->request->getPost('sort_order') ?: 0),
        ];

        // Si se marca como default, quitar el flag de los demás
        if ($this->request->getPost('is_default')) {
            $model->where('is_default', 1)->set(['is_default' => 0])->update();
            $data['is_default'] = 1;
        }

        $model->update($id, $data);
        return redirect()->to('/admin/languages')->with('success', 'Idioma actualizado.');
    }

    public function delete($id)
    {
        $model = new LanguageModel();
        $lang = $model->find($id);
        if (!$lang) return redirect()->to('/admin/languages')->with('error', 'No encontrado.');

        if ($lang['is_default']) {
            return redirect()->to('/admin/languages')->with('error', 'No puedes eliminar el idioma por defecto.');
        }

        $model->delete($id);
        return redirect()->to('/admin/languages')->with('success', 'Idioma eliminado.');
    }

    public function setDefault($id)
    {
        $model = new LanguageModel();
        $model->where('is_default', 1)->set(['is_default' => 0])->update();
        $model->update($id, ['is_default' => 1]);
        return redirect()->to('/admin/languages')->with('success', 'Idioma por defecto actualizado.');
    }

    protected function renderModule(string $view, array $data = [])
    {
        return view('App\Modules\I18n\Views\admin/' . $view, array_merge($this->data, $data));
    }
}