<?php

use App\Modules\I18n\Controllers\Admin\Languages;

$routes->group('admin/languages', ['filter' => 'auth'], function($routes) {
    $routes->get('/', [Languages::class, 'index']);
    $routes->get('create', [Languages::class, 'create']);
    $routes->post('store', [Languages::class, 'store']);
    $routes->get('edit/(:num)', [Languages::class, 'edit/$1']);
    $routes->post('update/(:num)', [Languages::class, 'update/$1']);
    $routes->get('delete/(:num)', [Languages::class, 'delete/$1']);
    $routes->get('default/(:num)', [Languages::class, 'setDefault/$1']);
});