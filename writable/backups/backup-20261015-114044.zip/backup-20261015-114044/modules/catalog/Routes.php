<?php

use App\Modules\Catalog\Controllers\Admin\Products;
use App\Modules\Catalog\Controllers\Admin\Categories;
use App\Modules\Catalog\Controllers\Front\Catalog as FrontCatalog;

// Admin
$routes->group('admin/catalog', ['filter' => 'auth'], function($routes) {
    $routes->get('products', [Products::class, 'index']);
    $routes->get('products/create', [Products::class, 'create']);
    $routes->post('products/store', [Products::class, 'store']);
    $routes->get('products/edit/(:num)', [Products::class, 'edit/$1']);
    $routes->post('products/update/(:num)', [Products::class, 'update/$1']);
    $routes->post('products/delete/(:num)', [Products::class, 'delete/$1']);
    $routes->get('products/toggle/(:num)', [Products::class, 'toggle/$1']);
    $routes->get('products/import', [Products::class, 'importForm']);
    $routes->post('products/import', [Products::class, 'import']);

    $routes->get('categories', [Categories::class, 'index']);
    $routes->get('categories/create', [Categories::class, 'create']);
    $routes->post('categories/store', [Categories::class, 'store']);
    $routes->get('categories/edit/(:num)', [Categories::class, 'edit/$1']);
    $routes->post('categories/update/(:num)', [Categories::class, 'update/$1']);
    $routes->post('categories/delete/(:num)', [Categories::class, 'delete/$1']);
});

// Front - Array callable (CI4 ejecuta initController correctamente)
// $routes->get('catalogo', [FrontCatalog::class, 'index']);
// $routes->get('catalogo/categoria/(:any)', [FrontCatalog::class, 'category/$1']);
// $routes->get('catalogo/producto/(:any)', [FrontCatalog::class, 'product/$1']);