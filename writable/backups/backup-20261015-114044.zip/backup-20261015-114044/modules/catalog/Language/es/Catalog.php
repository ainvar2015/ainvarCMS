<?php
return [
    'title'           => 'Catálogo',
    'categories'      => 'Categorías',
    'all'             => 'Todas',
    'no_products'     => 'No hay productos disponibles.',
    'view_details'    => 'Ver ficha',
    'back_to_catalog' => 'Volver al catálogo',
    'related'         => 'También te puede interesar',
];