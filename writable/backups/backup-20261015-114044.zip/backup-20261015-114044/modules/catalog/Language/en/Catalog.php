<?php
return [
    'title'           => 'Catalog',
    'categories'      => 'Categories',
    'all'             => 'All',
    'no_products'     => 'No products available.',
    'view_details'    => 'View details',
    'back_to_catalog' => 'Back to catalog',
    'related'         => 'You may also like',
];