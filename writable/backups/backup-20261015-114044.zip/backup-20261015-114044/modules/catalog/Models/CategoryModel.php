<?php

namespace App\Modules\Catalog\Models;

use CodeIgniter\Model;

class CategoryModel extends Model
{
    protected $table      = 'catalog_categories';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name','slug','description','image','sort_order','active'];
    protected $useTimestamps = true;

    public function getActive()
    {
        return $this->where('active', 1)->orderBy('sort_order', 'ASC')->findAll();
    }
}