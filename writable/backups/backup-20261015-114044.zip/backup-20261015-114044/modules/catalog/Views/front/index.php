<?php $this->extend('front/themes/' . ($themePath ?? 'default') . '/layout') ?>

<?php $this->section('content') ?>
<h1 class="mb-4"><?= esc($title) ?> Aquí</h1>
<?= $this->include('App\Modules\Catalog\Views\front\_grid') ?>
<?php $this->endSection() ?>