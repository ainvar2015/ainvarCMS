<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<?php
$isEdit = !empty($category);
$c = $category ?? [];
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= $title ?></h1>
    <a href="<?= base_url('admin/catalog/categories') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Volver
    </a>
</div>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach (session()->getFlashdata('errors') as $error): ?>
                <li><?= $error ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-8">
        <form action="<?= $action ?>" method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nombre <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" value="<?= old('name', $c['name'] ?? '') ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Slug</label>
                        <input type="text" name="slug" class="form-control" value="<?= old('slug', $c['slug'] ?? '') ?>">
                        <div class="form-text">Déjalo vacío para generar automáticamente.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Descripción</label>
                        <textarea name="description" class="form-control" rows="3"><?= old('description', $c['description'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Imagen</label>
                        <input type="file" name="image" class="form-control" accept="image/*">
                        <?php if (!empty($c['image'])): ?>
                            <img src="<?= base_url($c['image']) ?>" height="60" class="mt-2 img-thumbnail">
                        <?php endif; ?>
                    </div>

                    <div class="row g-2">
                        <div class="col-md-6">
                            <label class="form-label">Orden</label>
                            <input type="number" name="sort_order" class="form-control" value="<?= old('sort_order', $c['sort_order'] ?? 0) ?>">
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" name="active" value="1" id="catActive" <?= old('active', $c['active'] ?? 1) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="catActive">Activa</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg"></i> <?= $isEdit ? 'Guardar cambios' : 'Crear categoría' ?>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $this->endSection() ?>