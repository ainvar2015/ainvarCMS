<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Categorías</h1>
    <a href="<?= base_url('admin/catalog/categories/create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Nueva Categoría
    </a>
</div>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">Nombre</th>
                    <th>Slug</th>
                    <th>Orden</th>
                    <th>Activa</th>
                    <th class="text-end pe-3">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($categories)): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">No hay categorías creadas.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($categories as $c): ?>
                        <tr>
                            <td class="ps-3">
                                <strong><?= esc($c['name']) ?></strong>
                                <?php if ($c['description']): ?>
                                    <br><small class="text-muted"><?= esc($c['description']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td><code><?= esc($c['slug']) ?></code></td>
                            <td><?= $c['sort_order'] ?? 0 ?></td>
                            <td>
                                <span class="badge bg-<?= $c['active'] ? 'success' : 'secondary' ?>">
                                    <?= $c['active'] ? 'Sí' : 'No' ?>
                                </span>
                            </td>
                            <td class="text-end pe-3">
                                <a href="<?= base_url('admin/catalog/categories/edit/' . $c['id']) ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?= base_url('admin/catalog/categories/delete/' . $c['id']) ?>" method="post" class="d-inline"
                                    onsubmit="return confirm('¿Eliminar esta categoría? Debe estar vacía.')">
                                    <?= csrf_field() ?>
                                    <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $this->endSection() ?>