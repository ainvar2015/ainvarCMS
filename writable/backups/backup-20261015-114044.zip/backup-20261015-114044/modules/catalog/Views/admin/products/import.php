<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Importar productos</h1>
    <a href="<?= base_url('admin/catalog/products') ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Volver</a>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <p class="text-muted">Sube un archivo CSV con las siguientes columnas (separadas por <strong>punto y coma</strong>):</p>
        <code>name;slug;sku;category_id;price;price_old;stock;description;short_desc;featured;active;meta_title;meta_desc</code>
        
        <div class="alert alert-info mt-3">
            <strong>Notas:</strong>
            <ul class="mb-0">
                <li>La primera fila debe ser la cabecera con los nombres exactos de columna.</li>
                <li>Si <code>slug</code> está vacío, se genera automáticamente desde el nombre.</li>
                <li><code>category_id</code> es numérico. Si está vacío, se usa la categoría por defecto que selecciones abajo.</li>
                <li>Los decimales de precio pueden usar coma o punto.</li>
            </ul>
        </div>

        <form action="<?= base_url('admin/catalog/products/import') ?>" method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="mb-3">
                <label class="form-label fw-bold">Archivo CSV</label>
                <input type="file" name="csv_file" class="form-control" accept=".csv" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Categoría por defecto (si el CSV no especifica category_id)</label>
                <select name="default_category_id" class="form-select">
                    <option value="">-- Sin categoría --</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= $c['id'] ?>"><?= esc($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="bi bi-upload"></i> Importar
            </button>
        </form>
    </div>
</div>
<?php $this->endSection() ?>