<?php

namespace App\Modules\Catalog\Controllers\Front;

use App\Controllers\BaseController;
use App\Modules\Catalog\Models\ProductModel;
use App\Modules\Catalog\Models\CategoryModel;

class Catalog extends BaseController
{
    protected $helpers = ['url', 'html', 'menu', 'i18n'];

    /** Modo parcial: true cuando se renderiza dentro de una página-módulo */
    public $embed = false;

    private function getThemePath(): string
    {
        $themeModel = new \App\Models\ThemeModel();
        $active = $themeModel->where('active', 1)->first();
        return $active['slug'] ?? 'default';
    }

    private function getLanguages(): array
    {
        try {
            $langModel = new \App\Modules\I18n\Models\LanguageModel();
            return $langModel->where('active', 1)->orderBy('sort_order', 'ASC')->findAll();
        } catch (\Exception $e) {
            return [];
        }
    }

    private function getLangData(): array
    {
        $configModel = new \App\Models\ConfigModel();
        $defaultLang = $configModel->get('site_language', 'es');
        $currentLang = \current_lang() ?: $defaultLang;
        return [
            'current_lang' => $currentLang,
            'default_lang' => $defaultLang,
            'languages'    => $this->getLanguages(),
        ];
    }

    /** Slug traducido (idioma actual) de la página-módulo — LA base de todos los enlaces */
    private function getPageBase(): string
    {
        $page = (new \App\Models\PageModel())
            ->where('type', 'module')->where('module_name', 'catalog')->first();
        if (!$page) return 'catalogo';

        $currentLang = \current_lang();
        if ($currentLang && $currentLang !== default_lang()) {
            $trans = (new \App\Models\PageTranslationModel())
                ->where('page_id', $page['id'])->where('lang', $currentLang)->first();
            if ($trans && !empty($trans['slug'])) return $trans['slug'];
        }
        return $page['slug'];
    }

    /** Mapa slug→idioma para el switcher (igual que Gallery::album) */
    private function getTranslationSlugs(): array
    {
        $page = (new \App\Models\PageModel())
            ->where('type', 'module')->where('module_name', 'catalog')->first();
        if (!$page) return [];

        $slugs = [default_lang() => $page['slug']];
        foreach ((new \App\Models\PageTranslationModel())->where('page_id', $page['id'])->findAll() as $t) {
            $slugs[$t['lang']] = $t['slug'];
        }
        return $slugs;
    }

    public function index()
    {
        \Config\Services::language()->setLocale(\current_lang());
        $productModel = new ProductModel();
        $categoryModel = new CategoryModel();
        $request = service('request');
        $themePath = $this->getThemePath();

        $categorySlug = $request->getGet('categoria');
        $categoryId = null;
        if ($categorySlug) {
            $cat = $categoryModel->where('slug', $categorySlug)->where('active', 1)->first();
            if ($cat) $categoryId = $cat['id'];
        }

        $data = array_merge([
            'title'     => lang('Catalog.title'),
            'products'   => $productModel->getActive($categoryId),
            'categories' => $categoryModel->getActive(),
            'activeCat'  => $categorySlug,
            'base_url'  => base_url(),
            'theme_url' => base_url('themes/' . $themePath),
            'themePath' => $themePath,
            'pageBase'   => $this->getPageBase(),
        ], $this->getLangData());

        // // Modo parcial (página-módulo): solo el grid, sin layout del tema
        // if ($this->embed) {
        //     return view('App\Modules\Catalog\Views\Front\_grid', $data);
        // }

        // // Modo standalone (ya no debería usarse, se mantiene por si acaso)
        // $themePath = $this->getThemePath();
        // return view('App\Modules\Catalog\Views\Front\index', array_merge($data, [
        //     'title'     => lang('Catalog.title'),
        //     'base_url'  => base_url(),
        //     'theme_url' => base_url('themes/' . $themePath),
        //     'themePath' => $themePath,
        // ]));

        // Vista completa (ruta directa /galeria) o parcial (incrustada en página)
        $view = $this->embed
            ? 'App\Modules\Catalog\Views\front\_grid'
            : 'App\Modules\Catalog\Views\front\index';

        return view($view, $data);
    }

    public function category($slug)
    {
        $categoryModel = new CategoryModel();
        $productModel = new ProductModel();

        $category = $categoryModel->where('slug', $slug)->where('active', 1)->first();
        if (!$category) {
            return redirect()->to(localized_url($this->getPageBase()));
        }

        $products = $productModel->getActive($category['id']);
        $themePath = $this->getThemePath();

        return view('App\Modules\Catalog\Views\Front\category', array_merge([
            'title'             => $category['name'],
            'category'          => $category,
            'products'          => $products,
            'pageBase'          => $this->getPageBase(),
            'translation_slugs' => $this->getTranslationSlugs(),
            'base_url'          => base_url(),
            'theme_url'         => base_url('themes/' . $themePath),
            'themePath'         => $themePath,
        ], $this->getLangData()));
    }

    public function product($slug)
    {
        $productModel = new ProductModel();

        $product = $productModel->getWithCategory($slug);
        if (!$product) {
            return redirect()->to(localized_url($this->getPageBase()));
        }

        $gallery = json_decode($product['images_gallery'] ?? '[]', true) ?: [];
        $related = [];

        if ($product['category_id']) {
            $related = $productModel->getActive($product['category_id']);
            $related = array_filter($related, fn($r) => $r['id'] != $product['id']);
            $related = array_slice($related, 0, 3);
        }

        $themePath = $this->getThemePath();

        return view('App\Modules\Catalog\Views\front\product', array_merge([
            'title'             => $product['meta_title'] ?: $product['name'],
            'meta_desc'         => $product['meta_desc'],
            'product'           => $product,
            'gallery'           => $gallery,
            'related'           => $related,
            'pageBase'          => $this->getPageBase(),
            'translation_slugs' => $this->getTranslationSlugs(),
            'base_url'          => base_url(),
            'theme_url'         => base_url('themes/' . $themePath),
            'themePath'         => $themePath,
        ], $this->getLangData()));
    }
}
