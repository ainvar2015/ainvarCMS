<?php
// en
return [
    'title'        => 'News',
    'read_more'    => 'Read more',
    'no_articles'  => 'No news available.',
    'all'          => 'All',
    'categories'   => 'Categories',
    'back_to_news' => 'Back to news',
    'related'      => 'Related news',
];