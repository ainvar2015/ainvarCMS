<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateNewsTables extends Migration
{
    public function up()
    {
        // Categorías (canónico = idioma por defecto)
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'name'        => ['type' => 'VARCHAR', 'constraint' => 150],
            'slug'        => ['type' => 'VARCHAR', 'constraint' => 190],
            'description' => ['type' => 'TEXT', 'null' => true],
            'sort_order'  => ['type' => 'INT', 'constraint' => 11, 'default' => 0],
            'active'      => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('slug');
        $this->forge->createTable('news_categories');

        // Traducciones de categorías
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'category_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'lang'        => ['type' => 'VARCHAR', 'constraint' => 5],
            'name'        => ['type' => 'VARCHAR', 'constraint' => 150],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey(['category_id', 'lang'], false, true);   // unique, NO primary
        $this->forge->createTable('news_category_translations');

        // Artículos (title/summary/content canónicos = idioma por defecto)
        $this->forge->addField([
            'id'           => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'category_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'title'        => ['type' => 'VARCHAR', 'constraint' => 255],
            'slug'         => ['type' => 'VARCHAR', 'constraint' => 255],
            'summary'      => ['type' => 'TEXT', 'null' => true],
            'content'      => ['type' => 'LONGTEXT', 'null' => true],
            'image_main'   => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'published_at' => ['type' => 'DATETIME', 'null' => true],
            'featured'     => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0],
            'active'       => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'meta_title'   => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'meta_desc'    => ['type' => 'VARCHAR', 'constraint' => 300, 'null' => true],
            'created_at'   => ['type' => 'DATETIME', 'null' => true],
            'updated_at'   => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('slug');
        $this->forge->addKey('category_id');
        $this->forge->createTable('news_articles');

        // Traducciones de artículos
        $this->forge->addField([
            'id'         => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'article_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'lang'       => ['type' => 'VARCHAR', 'constraint' => 5],
            'title'      => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'summary'    => ['type' => 'TEXT', 'null' => true],
            'content'    => ['type' => 'LONGTEXT', 'null' => true],
            'created_at' => ['type' => 'DATETIME', 'null' => true],
            'updated_at' => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey(['article_id', 'lang'], false, true);
        $this->forge->createTable('news_translations');
    }

    public function down()
    {
        $this->forge->dropTable('news_translations');
        $this->forge->dropTable('news_articles');
        $this->forge->dropTable('news_category_translations');
        $this->forge->dropTable('news_categories');
    }
}