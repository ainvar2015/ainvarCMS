<?php

namespace App\Modules\News\Models;

use CodeIgniter\Model;

class NewsCategoryTranslationModel extends Model
{
    protected $table         = 'news_category_translations';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['category_id', 'lang', 'name'];
    protected $useTimestamps = true;
}