<?php

namespace App\Modules\News\Models;

use CodeIgniter\Model;

class NewsModel extends Model
{
    protected $table         = 'news_articles';
    protected $primaryKey    = 'id';
    protected $allowedFields = [
        'category_id', 'title', 'slug', 'summary', 'content',
        'image_main', 'published_at', 'featured', 'active',
        'meta_title', 'meta_desc',
    ];
    protected $useTimestamps = true;

    /** Artículos visibles: activos y con fecha de publicación pasada */
    public function getPublished(?int $categoryId = null, ?int $limit = null): array
    {
        $builder = $this->where('active', 1)
            ->where('published_at <=', date('Y-m-d H:i:s'))
            ->orderBy('published_at', 'DESC');

        if ($categoryId) $builder->where('category_id', $categoryId);
        if ($limit)      $builder->limit($limit);

        return $builder->findAll();
    }

    public function getFeatured(int $limit = 1): array
    {
        return $this->where('active', 1)
            ->where('featured', 1)
            ->where('published_at <=', date('Y-m-d H:i:s'))
            ->orderBy('published_at', 'DESC')
            ->limit($limit)
            ->findAll();
    }

    public function getBySlug(string $slug): ?array
    {
        $row = $this->where('slug', $slug)->first();
        return $row ?: null;
    }
}