<?php

namespace App\Modules\News\Models;

use CodeIgniter\Model;

class NewsCategoryModel extends Model
{
    protected $table         = 'news_categories';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['name', 'slug', 'description', 'sort_order', 'active'];
    protected $useTimestamps = true;

    public function getActive(): array
    {
        return $this->where('active', 1)->orderBy('sort_order', 'ASC')->findAll();
    }
}