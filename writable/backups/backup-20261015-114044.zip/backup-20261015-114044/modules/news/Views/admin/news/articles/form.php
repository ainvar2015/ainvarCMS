<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<?php $isEdit = !empty($a); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= esc($title) ?></h1>
    <a href="<?= base_url('admin/news/articles') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Volver
    </a>
</div>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger"><ul class="mb-0">
        <?php foreach (session()->getFlashdata('errors') as $e): ?><li><?= $e ?></li><?php endforeach; ?>
    </ul></div>
<?php endif; ?>

<form action="<?= $action ?>" method="post" id="articleForm">
    <?= csrf_field() ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <ul class="nav nav-tabs card-header-tabs" id="langTabs">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#tab-<?= default_lang() ?>">
                                <?= strtoupper(default_lang()) ?> (principal)
                            </a>
                        </li>
                        <?php foreach ($otherLangs as $l): ?>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#tab-<?= $l['code'] ?>">
                                    <?= strtoupper($l['code']) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="card-body tab-content">
                    <!-- Idioma por defecto -->
                    <div class="tab-pane fade show active" id="tab-<?= default_lang() ?>">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Título <span class="text-danger">*</span></label>
                            <input type="text" name="title" class="form-control" required
                                value="<?= old('title', $a['title'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Slug</label>
                            <input type="text" name="slug" class="form-control"
                                value="<?= old('slug', $a['slug'] ?? '') ?>">
                            <div class="form-text">Vacío = se genera del título.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Resumen</label>
                            <textarea name="summary" class="form-control" rows="3"><?= old('summary', $a['summary'] ?? '') ?></textarea>
                        </div>
                        <div class="mb-0">
                            <label class="form-label">Contenido</label>
                            <textarea name="content" id="content-default" class="form-control" rows="10"><?= old('content', $a['content'] ?? '') ?></textarea>
                        </div>
                    </div>

                    <!-- Otros idiomas -->
                    <?php foreach ($otherLangs as $l): $code = $l['code']; $t = $trans[$code] ?? []; ?>
                        <div class="tab-pane fade" id="tab-<?= $code ?>">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Título (<?= strtoupper($code) ?>)</label>
                                <input type="text" name="trans[<?= $code ?>][title]" class="form-control"
                                    value="<?= old("trans.$code.title", $t['title'] ?? '') ?>">
                                <div class="form-text">Vacío = usa el título en <?= strtoupper(default_lang()) ?>.</div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Resumen (<?= strtoupper($code) ?>)</label>
                                <textarea name="trans[<?= $code ?>][summary]" class="form-control" rows="3"><?= old("trans.$code.summary", $t['summary'] ?? '') ?></textarea>
                            </div>
                            <div class="mb-0">
                                <label class="form-label">Contenido (<?= strtoupper($code) ?>)</label>
                                <textarea name="trans[<?= $code ?>][content]" id="content-<?= $code ?>" class="form-control" rows="10"><?= old("trans.$code.content", $t['content'] ?? '') ?></textarea>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Categoría</label>
                        <select name="category_id" class="form-select">
                            <option value="">— Sin categoría —</option>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= old('category_id', $a['category_id'] ?? '') == $c['id'] ? 'selected' : '' ?>>
                                    <?= esc($c['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Imagen destacada</label>
                        <div class="d-grid mb-2">
                            <button type="button" class="btn btn-outline-primary" id="pickImage">
                                <i class="bi bi-image"></i> Elegir de la biblioteca
                            </button>
                        </div>
                        <input type="hidden" name="image_main" id="imageMain" value="<?= old('image_main', $a['image_main'] ?? '') ?>">
                        <div id="imagePreviewWrap" class="<?= empty($a['image_main']) ? 'd-none' : '' ?>">
                            <img id="imagePreview" src="<?= !empty($a['image_main']) ? thumb_url($a['image_main']) : '' ?>" class="img-fluid rounded">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Fecha de publicación</label>
                        <input type="datetime-local" name="published_at" class="form-control"
                            value="<?= old('published_at', !empty($a['published_at']) ? date('Y-m-d\TH:i', strtotime($a['published_at'])) : date('Y-m-d\TH:i')) ?>">
                        <div class="form-text">Fecha futura = se publicará automáticamente.</div>
                    </div>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="featured" value="1" id="feat"
                            <?= old('featured', $a['featured'] ?? 0) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="feat">Destacado</label>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="active" value="1" id="act"
                            <?= old('active', $a['active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="act">Activo</label>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Meta título (SEO)</label>
                        <input type="text" name="meta_title" class="form-control" value="<?= old('meta_title', $a['meta_title'] ?? '') ?>">
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Meta descripción (SEO)</label>
                        <textarea name="meta_desc" class="form-control" rows="2"><?= old('meta_desc', $a['meta_desc'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-check-lg"></i> <?= $isEdit ? 'Guardar cambios' : 'Crear artículo' ?>
            </button>
        </div>
    </div>
</form>
<?php $this->endSection() ?>

<?php $this->section('js') ?>
<script>
    // Media Picker para la imagen destacada
    document.getElementById('pickImage').addEventListener('click', () => {
        MediaPicker.open((url, alt, meta) => {
            const rel = url.replace('<?= base_url() ?>', '');
            document.getElementById('imageMain').value = rel;
            const wrap = document.getElementById('imagePreviewWrap');
            wrap.classList.remove('d-none');
            document.getElementById('imagePreview').src = url;
        });
    });

    // Summernote: un init por editor, por ID (regla de oro), sin duplicar al cambiar de pestaña
    document.addEventListener('DOMContentLoaded', () => {
        const ids = ['content-default'<?php foreach ($otherLangs as $l): ?>, 'content-<?= $l['code'] ?>'<?php endforeach; ?>];
        ids.forEach(id => {
            const el = document.getElementById(id);
            if (el && !$(el).hasClass('note-editor') && !$(el).next().hasClass('note-editor')) {
                $(el).summernote({
                    height: 300,
                    lang: 'es-ES',
                    toolbar: [
                        ['style', ['bold', 'italic', 'underline', 'clear']],
                        ['font', ['fontsize']],
                        ['color', ['color']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        ['insert', ['link', 'picture', 'video']],
                        ['view', ['fullscreen', 'codeview']]
                    ]
                });
            }
        });
    });
</script>
<?php $this->endSection() ?>