<?php

namespace App\Modules\News\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Modules\News\Models\NewsModel;
use App\Modules\News\Models\NewsCategoryModel;
use App\Modules\News\Models\ArticleTranslationModel;

class Articles extends BaseController
{
    protected $helpers = ['url', 'form', 'html', 'i18n', 'thumb'];

    protected function renderModule(string $view, array $data = [])
    {
        $base = isset($this->data) ? $this->data : [];
        return view('App\Modules\News\Views\admin\\' . $view, array_merge($base, $data));
    }

    private function generateSlug(string $title): string
    {
        $slug = slugify($title);
        return $slug !== 'item' ? $slug : 'noticia';
    }

    private function ensureUniqueSlug(string $slug, ?int $ignoreId = null): string
    {
        $model   = new NewsModel();
        $base    = $slug;
        $counter = 1;
        while (true) {
            $builder = $model->where('slug', $slug);
            if ($ignoreId) $builder->where('id !=', $ignoreId);
            if (!$builder->first()) return $slug;
            $slug = $base . '-' . $counter++;
        }
    }

    public function index()
    {
        $model   = new NewsModel();
        $request = service('request');

        $q       = trim((string) $request->getGet('q'));
        $catSlug = trim((string) $request->getGet('categoria'));

        $builder = $model->orderBy('published_at', 'DESC');
        if ($q !== '') {
            $builder->groupStart()->like('title', $q)->orLike('summary', $q)->groupEnd();
        }
        $activeCat = null;
        if ($catSlug !== '') {
            $cat = (new NewsCategoryModel())->where('slug', $catSlug)->first();
            if ($cat) {
                $builder->where('category_id', $cat['id']);
                $activeCat = $catSlug;
            }
        }

        return $this->renderModule('news/articles/index', [
            'title'      => 'Artículos',
            'articles'   => $builder->findAll(),
            'categories' => (new NewsCategoryModel())->orderBy('sort_order', 'ASC')->findAll(),
            'q'          => $q,
            'activeCat'  => $activeCat,
        ]);
    }

    public function create()
    {
        return $this->renderModule('news/articles/form', [
            'title'      => 'Nuevo artículo',
            'a'          => null,
            'action'     => base_url('admin/news/articles/store'),
            'categories' => (new NewsCategoryModel())->where('active', 1)->findAll(),
            'otherLangs' => array_filter(active_languages(), fn($l) => $l['code'] !== default_lang()),
            'trans'      => [],
        ]);
    }

    public function edit($id)
    {
        $model   = new NewsModel();
        $article = $model->find($id);
        if (!$article) {
            return redirect()->to('/admin/news/articles')->with('error', 'Artículo no encontrado.');
        }

        $trans = [];
        foreach ((new ArticleTranslationModel())->where('article_id', $id)->findAll() as $t) {
            $trans[$t['lang']] = $t;
        }

        return $this->renderModule('news/articles/form', [
            'title'      => 'Editar artículo',
            'a'          => $article,
            'action'     => base_url('admin/news/articles/update/' . $id),
            'categories' => (new NewsCategoryModel())->where('active', 1)->findAll(),
            'otherLangs' => array_filter(active_languages(), fn($l) => $l['code'] !== default_lang()),
            'trans'      => $trans,
        ]);
    }

    public function store()
    {
        return $this->save(null);
    }

    public function update($id)
    {
        return $this->save((int) $id);
    }

    private function save(?int $id)
    {
        $rules = [
            'title' => 'required|min_length[2]|max_length[255]',
            'slug'  => 'permit_empty|max_length[255]',
        ];
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $model = new NewsModel();

        $slug = trim((string) $this->request->getPost('slug'));
        if ($slug === '') {
            $slug = $this->generateSlug($this->request->getPost('title'));
        }
        $slug = $this->ensureUniqueSlug($slug, $id);

        $data = [
            'category_id'  => $this->request->getPost('category_id') ?: null,
            'title'        => $this->request->getPost('title'),
            'slug'         => $slug,
            'summary'      => $this->request->getPost('summary'),
            'content'      => $this->request->getPost('content'),
            'image_main'   => $this->request->getPost('image_main') ?: null,
            'published_at' => $this->request->getPost('published_at') ?: date('Y-m-d H:i:s'),
            'featured'     => $this->request->getPost('featured') ? 1 : 0,
            'active'       => $this->request->getPost('active') ? 1 : 0,
            'meta_title'   => $this->request->getPost('meta_title') ?: null,
            'meta_desc'    => $this->request->getPost('meta_desc') ?: null,
        ];

        if ($id) {
            $model->update($id, $data);
            $articleId = $id;
        } else {
            $model->insert($data);
            $articleId = (int) $model->getInsertID();
        }

        $this->saveTranslations($articleId);

        $msg = $id ? 'Artículo actualizado.' : 'Artículo creado.';
        return redirect()->to('/admin/news/articles')->with('success', $msg);
    }

    /** Upsert de traducciones: trans[lang][field] → news_translations */
    private function saveTranslations(int $articleId): void
    {
        $transModel = new ArticleTranslationModel();
        $input      = (array) $this->request->getPost('trans');

        foreach (active_languages() as $l) {
            $code = $l['code'];
            if ($code === default_lang()) continue;

            $fields = (array) ($input[$code] ?? []);
            $row    = [
                'title'   => trim((string) ($fields['title'] ?? '')),
                'summary' => trim((string) ($fields['summary'] ?? '')),
                'content' => (string) ($fields['content'] ?? ''),
            ];

            $existing = $transModel->where('article_id', $articleId)->where('lang', $code)->first();
            if ($existing) {
                $transModel->update($existing['id'], $row);
            } else {
                $row['article_id'] = $articleId;
                $row['lang']       = $code;
                $transModel->insert($row);
            }
        }
    }

    public function toggle($id)
    {
        $model   = new NewsModel();
        $article = $model->find($id);
        if ($article) {
            $model->update($id, ['active' => $article['active'] ? 0 : 1]);
        }
        return redirect()->back();
    }

    public function toggleFeatured($id)
    {
        $model   = new NewsModel();
        $article = $model->find($id);
        if ($article) {
            $model->update($id, ['featured' => $article['featured'] ? 0 : 1]);
        }
        return redirect()->back();
    }

    public function delete($id)
    {
        $model = new NewsModel();
        if (!$model->find($id)) {
            return redirect()->to('/admin/news/articles')->with('error', 'Artículo no encontrado.');
        }
        (new ArticleTranslationModel())->where('article_id', $id)->delete();
        $model->delete($id);
        return redirect()->to('/admin/news/articles')->with('success', 'Artículo eliminado.');
    }
}
