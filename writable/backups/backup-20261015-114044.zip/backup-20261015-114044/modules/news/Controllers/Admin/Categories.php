<?php

namespace App\Modules\News\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Modules\News\Models\NewsModel;
use App\Modules\News\Models\NewsCategoryModel;
use App\Modules\News\Models\NewsCategoryTranslationModel;

class Categories extends BaseController
{
    protected $helpers = ['url', 'form', 'html', 'i18n'];

    protected function renderModule(string $view, array $data = [])
    {
        $base = isset($this->data) ? $this->data : [];
        return view('App\Modules\News\Views\admin\\' . $view, array_merge($base, $data));
    }

    public function index()
    {
        return $this->renderModule('news/categories/index', [
            'title'      => 'Categorías de noticias',
            'categories' => (new NewsCategoryModel())->orderBy('sort_order', 'ASC')->findAll(),
        ]);
    }

    public function create()
    {
        return $this->renderModule('news/categories/form', [
            'title' => 'Nueva categoría',
            'c'     => null,
            'action' => base_url('admin/news/categories/store'),
            'name_trans' => [],
        ]);
    }

    public function edit($id)
    {
        $cat = (new NewsCategoryModel())->find($id);
        if (!$cat) {
            return redirect()->to('/admin/news/categories')->with('error', 'Categoría no encontrada.');
        }
        $name_trans = [];
        foreach ((new NewsCategoryTranslationModel())->where('category_id', $id)->findAll() as $t) {
            $name_trans[$t['lang']] = $t;
        }
        return $this->renderModule('news/categories/form', [
            'title' => 'Editar categoría',
            'c'     => $cat,
            'action' => base_url('admin/news/categories/update/' . $id),
            'name_trans' => $name_trans,
        ]);
    }

    public function store()
    {
        return $this->save(null);
    }

    public function update($id)
    {
        return $this->save((int) $id);
    }

    private function save(?int $id)
    {
        if (!$this->validate(['name' => 'required|min_length[2]|max_length[150]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $model = new NewsCategoryModel();

        $slug = trim((string) $this->request->getPost('slug'));
        if ($slug === '') {
            $slug = slugify($this->request->getPost('name'));
        } else {
            $slug = slugify($slug);   // saneamos también lo que el usuario escribe a mano
        }
        // unicidad
        $base = $slug;
        $i = 1;
        while (true) {
            $b = $model->where('slug', $slug);
            if ($id) $b->where('id !=', $id);
            if (!$b->first()) break;
            $slug = $base . '-' . $i++;
        }

        $data = [
            'name'        => $this->request->getPost('name'),
            'slug'        => $slug,
            'description' => $this->request->getPost('description'),
            'sort_order'  => (int) ($this->request->getPost('sort_order') ?: 0),
            'active'      => $this->request->getPost('active') ? 1 : 0,
        ];

        if ($id) {
            $model->update($id, $data);
            $catId = $id;
        } else {
            $model->insert($data);
            $catId = (int) $model->getInsertID();
        }

        // Traducciones de nombre (mismo patrón que Catalog)
        $transModel = new NewsCategoryTranslationModel();
        $labels = (array) $this->request->getPost('name_trans');
        foreach (active_languages() as $l) {
            if ($l['code'] === default_lang()) continue;
            $val = trim((string) ($labels[$l['code']] ?? ''));
            if ($val === '') continue;
            $existing = $transModel->where('category_id', $catId)->where('lang', $l['code'])->first();
            if ($existing) $transModel->update($existing['id'], ['name' => $val]);
            else $transModel->insert(['category_id' => $catId, 'lang' => $l['code'], 'name' => $val]);
        }

        return redirect()->to('/admin/news/categories')->with('success', 'Categoría guardada.');
    }

    public function delete($id)
    {
        $model = new NewsCategoryModel();
        if (!$model->find($id)) {
            return redirect()->to('/admin/news/categories')->with('error', 'Categoría no encontrada.');
        }
        if ((new NewsModel())->where('category_id', $id)->countAllResults() > 0) {
            return redirect()->to('/admin/news/categories')->with('error', 'La categoría tiene artículos. Muévelos o elimínalos primero.');
        }
        (new NewsCategoryTranslationModel())->where('category_id', $id)->delete();
        $model->delete($id);
        return redirect()->to('/admin/news/categories')->with('success', 'Categoría eliminada.');
    }
}
