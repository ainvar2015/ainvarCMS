<?php

use App\Modules\News\Controllers\Admin\Articles;
use App\Modules\News\Controllers\Admin\Categories;
use App\Modules\News\Controllers\Front\News as FrontNews;

// Admin
$routes->group('admin/news', ['filter' => 'auth'], function ($routes) {
    $routes->get('articles', [Articles::class, 'index']);
    $routes->get('articles/create', [Articles::class, 'create']);
    $routes->post('articles/store', [Articles::class, 'store']);
    $routes->get('articles/edit/(:num)', [Articles::class, 'edit/$1']);
    $routes->post('articles/update/(:num)', [Articles::class, 'update/$1']);
    $routes->post('articles/delete/(:num)', [Articles::class, 'delete/$1']);
    $routes->get('articles/toggle/(:num)', [Articles::class, 'toggle/$1']);
    $routes->get('articles/toggle-featured/(:num)', [Articles::class, 'toggleFeatured/$1']);

    $routes->get('categories', [Categories::class, 'index']);
    $routes->get('categories/create', [Categories::class, 'create']);
    $routes->post('categories/store', [Categories::class, 'store']);
    $routes->get('categories/edit/(:num)', [Categories::class, 'edit/$1']);
    $routes->post('categories/update/(:num)', [Categories::class, 'update/$1']);
    $routes->post('categories/delete/(:num)', [Categories::class, 'delete/$1']);
});

// Front: la página-módulo es la ÚNICA entrada. Sub-rutas dinámicas vía
// $registerModuleSubRoutes en Config/Routes.php (rama 'news').
// $routes->get('noticias', [FrontNews::class, 'index']);
// $routes->get('noticias/noticia/(:any)', [FrontNews::class, 'article/$1']);