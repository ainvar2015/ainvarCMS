<?php

namespace App\Modules\Gallery\Models;

use CodeIgniter\Model;

class AlbumTranslationModel extends Model
{
    protected $table         = 'gallery_album_translations';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['album', 'lang', 'title'];
    protected $useTimestamps = true;
}