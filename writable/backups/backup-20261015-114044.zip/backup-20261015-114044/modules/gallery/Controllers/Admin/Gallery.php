<?php

namespace App\Modules\Gallery\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Modules\Gallery\Models\ImageModel;
use App\Modules\Gallery\Models\AlbumTranslationModel;

class Gallery extends BaseController
{
    protected $helpers = ['url', 'form', 'html', 'i18n'];

    public function index()
    {
        $model = new ImageModel();
        $albumFilter = $this->request->getGet('album');

        $builder = $model->orderBy('id', 'DESC');
        if ($albumFilter) $builder->where('album', $albumFilter);

        return $this->renderModule('gallery/index', [
            'title'    => 'Galería',
            'images'   => $builder->findAll(),
            'albums'   => $model->getAlbums(),
            'albumFilter' => $albumFilter,
        ]);
    }

    public function create()
    {
        $model = new ImageModel();
        return $this->renderModule('gallery/form', [
            'title'  => 'Subir imágenes',
            'albums' => array_column($model->getAlbums(), 'album'),
        ]);
    }

    public function store()
    {
        $files = $this->request->getFiles();
        $album = $this->request->getPost('album') ?: 'General';
        $model = new ImageModel();
        $isAjax = $this->request->getHeaderLine('X-Requested-With') === 'XMLHttpRequest';

        $uploaded = 0;
        $errors = [];

        if (!empty($files['images'])) {
            foreach ($files['images'] as $file) {
                if ($file && $file->isValid() && !$file->hasMoved()) {
                    $mime = (string) $file->getMimeType();   // ← antes de move()

                    $newName  = $file->getRandomName();
                    $file->move(ROOTPATH . 'public/uploads/gallery', $newName);
                    $filePath = 'uploads/gallery/' . $newName;
                    $dims     = @getimagesize(ROOTPATH . 'public/' . $filePath);

                    $title = pathinfo($file->getClientName(), PATHINFO_FILENAME);
                    $slug  = $this->ensureUniqueSlug($this->generateSlug($title));

                    try {
                        $model->insert([
                            'title'       => $title,
                            'slug'        => $slug,
                            'description' => $this->request->getPost('description'),
                            'album'       => $album,
                            'file_path'   => $filePath,
                            'sort_order'  => 0,
                            'active'      => 1,
                            'created_at'  => date('Y-m-d H:i:s'),
                        ]);

                        // Registrar también en la biblioteca central de medios
                        (new \App\Models\MediaModel())->insert([
                            'folder_id'     => null,
                            'file_path'     => $filePath,
                            'original_name' => $file->getClientName(),
                            'mime_type'     => $mime,
                            'size'          => $file->getSize(),
                            'width'         => $dims[0] ?? null,
                            'height'        => $dims[1] ?? null,
                            'title'         => $title,
                            'alt_text'      => $title,
                            'uploaded_by'   => session()->get('user_id'),
                        ]);

                        $uploaded++;
                    } catch (\Exception $e) {
                        $errors[] = $title . ': ' . $e->getMessage();
                    }
                }
            }
        }

        if ($isAjax) {
            return $this->response->setJSON([
                'success'  => $uploaded > 0,
                'message'  => $uploaded > 0 ? "$uploaded imagen(es) subida(s)." : 'No se subió ninguna imagen.',
                'uploaded' => $uploaded,
                'errors'   => $errors,
            ]);
        }

        return redirect()->to('/admin/gallery/images')->with(
            $uploaded > 0 ? 'success' : 'error',
            $uploaded > 0 ? "$uploaded imagen(es) subida(s)." : 'No se subió ninguna imagen.'
        );
    }

    public function storeFromLibrary()
    {
        $mediaId = (int) $this->request->getPost('media_id');
        $album   = $this->request->getPost('album') ?: 'General';

        $media = (new \App\Models\MediaModel())->find($mediaId);
        if (!$media) {
            return $this->response->setJSON(['success' => false, 'message' => 'Imagen no encontrada en la biblioteca.']);
        }

        // Evitar duplicados: misma ruta de archivo ya en la galería
        $model = new ImageModel();
        if ($model->where('file_path', $media['file_path'])->first()) {
            return $this->response->setJSON(['success' => false, 'message' => 'Esa imagen ya está en la galería.']);
        }

        $title = pathinfo($media['original_name'], PATHINFO_FILENAME);
        $slug  = $this->ensureUniqueSlug($this->generateSlug($title));

        $model->insert([
            'title'       => $media['title'] ?: $title,
            'slug'        => $slug,
            'description' => '',
            'album'       => $album,
            'file_path'   => $media['file_path'],
            'sort_order'  => 0,
            'active'      => 1,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Imagen añadida a la galería desde la biblioteca.',
        ]);
    }

    public function delete($id)
    {
        $model = new ImageModel();
        $img = $model->find($id);

        if ($img) {
            // Imagen original
            $fullPath = FCPATH . $img['file_path'];
            if (is_file($fullPath)) {
                unlink($fullPath);
            }

            // Su miniatura, si existe
            $thumbRel = \App\Libraries\ImageThumb::thumbRel($img['file_path']);
            if ($thumbRel && is_file(FCPATH . $thumbRel)) {
                unlink(FCPATH . $thumbRel);
            }

            $model->delete($id);
        }

        return redirect()->to('/admin/gallery/images')->with('success', 'Imagen eliminada.');
    }

    public function toggle($id)
    {
        $model = new ImageModel();
        $img   = $model->find($id);

        if (!$img) {
            return redirect()->to('/admin/gallery/images')->with('error', 'Imagen no encontrada.');
        }

        $model->update($id, ['active' => $img['active'] ? 0 : 1]);

        return redirect()->back()->with(
            'success',
            $img['active'] ? 'Imagen desactivada: deja de verse en el sitio.' : 'Imagen activada.'
        );
    }

    protected function renderModule(string $view, array $data = [])
    {
        return view('App\Modules\Gallery\Views\admin/' . $view, array_merge($this->data, $data));
    }

    private function generateSlug(string $text): string
    {
        $text = strtolower($text);
        $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
        $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
        $text = preg_replace('/[\s-]+/', '-', $text);
        return trim($text, '-');
    }

    private function ensureUniqueSlug(string $slug): string
    {
        $model = new ImageModel();
        $original = $slug;
        $counter = 1;
        while ($model->where('slug', $slug)->first()) {
            $slug = $original . '-' . $counter++;
        }
        return $slug;
    }

    public function albumTranslations()
    {
        $albums = (new ImageModel())->getAlbums();

        $existing = [];
        foreach ((new AlbumTranslationModel())->findAll() as $t) {
            $existing[$t['album']][$t['lang']] = $t['title'];
        }

        return $this->renderModule('gallery/album_translations', [
            'title'    => 'Traducir álbumes',
            'albums'   => $albums,
            'existing' => $existing,
        ]);
    }

    public function saveAlbumTranslations()
    {
        $transModel = new AlbumTranslationModel();
        $titles = (array) $this->request->getPost('title');   // [album][lang]

        foreach ($titles as $album => $langs) {
            foreach ((array) $langs as $lang => $val) {
                $val = trim((string) $val);
                $row = $transModel->where('album', $album)->where('lang', $lang)->first();
                if ($val === '') {
                    if ($row) $transModel->delete($row['id']);
                    continue;
                }
                if ($row) $transModel->update($row['id'], ['title' => $val]);
                else $transModel->insert(['album' => $album, 'lang' => $lang, 'title' => $val]);
            }
        }

        return redirect()->to('/admin/gallery/album-translations')->with('success', 'Traducciones guardadas.');
    }
}
