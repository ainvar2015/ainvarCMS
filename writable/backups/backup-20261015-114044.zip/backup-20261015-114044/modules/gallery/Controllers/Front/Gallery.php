<?php

namespace App\Modules\Gallery\Controllers\Front;

use App\Controllers\BaseController;
use App\Modules\Gallery\Models\ImageModel;

class Gallery extends BaseController
{
    protected $helpers = ['url', 'html', 'menu', 'i18n', 'thumb'];

    public $embed = false; // Indica si el módulo se está renderizando en modo parcial (sin layout del tema)

    private function getThemePath(): string
    {
        $themeModel = new \App\Models\ThemeModel();
        $active = $themeModel->where('active', 1)->first();
        return $active['slug'] ?? 'default';
    }

    private function getLanguages(): array
    {
        try {
            $langModel = new \App\Modules\I18n\Models\LanguageModel();
            return $langModel->where('active', 1)->orderBy('sort_order', 'ASC')->findAll();
        } catch (\Exception $e) {
            return [];
        }
    }

    private function getLangData(): array
    {
        $configModel = new \App\Models\ConfigModel();
        $defaultLang = $configModel->get('site_language', 'es');
        $currentLang = \current_lang() ?: $defaultLang;
        return [
            'current_lang' => $currentLang,
            'default_lang' => $defaultLang,
            'languages'    => $this->getLanguages(),
        ];
    }

    public function index()
    {
        \Config\Services::language()->setLocale(\current_lang());
        $model = new ImageModel();
        $themePath = $this->getThemePath();

        $data = array_merge([
            'title'     => lang('Gallery.title'),
            'images'    => $model->getActive(),
            'albums'    => $model->getAlbums(),
            'album'     => null,
            'base_url'  => base_url(),
            'theme_url' => base_url('themes/' . $themePath),
            'themePath' => $themePath,
            'pageBase' => $this->getPageBase(),
        ], $this->getLangData());

        // Vista completa (ruta directa /galeria) o parcial (incrustada en página)
        $view = $this->embed
            ? 'App\Modules\Gallery\Views\front\_grid'
            : 'App\Modules\Gallery\Views\front\gallery';

        return view($view, $data);
    }

    // Slug de la página que representa a la galería, en el idioma actual
    private function getPageBase(): string
    {
        $page = (new \App\Models\PageModel())
            ->where('type', 'module')
            ->where('module_name', 'gallery')
            ->where('status', 'published')
            ->first();

        if (!$page) {
            return 'galeria';   // fallback si no hay página
        }

        $lang = \current_lang();
        if ($lang !== default_lang()) {
            $trans = (new \App\Models\PageTranslationModel())
                ->where('page_id', $page['id'])
                ->where('lang', $lang)
                ->first();
            if ($trans) {
                return $trans['slug'];   // 'gallery' en inglés
            }
        }
        return $page['slug'];   // 'galeria' en español
    }

    private function getModulePage(): ?array
    {
        $page = (new \App\Models\PageModel())
            ->where('type', 'module')
            ->where('module_name', 'gallery')
            ->where('status', 'published')
            ->first();

        return $page ?: null;
    }

    public function album($album)
    {
        \Config\Services::language()->setLocale(\current_lang());

        $model       = new ImageModel();
        $themePath   = $this->getThemePath();
        $configModel = new \App\Models\ConfigModel();
        $defaultLang = $configModel->get('site_language', 'es');
        $currentLang = \current_lang() ?: $defaultLang;

        $title = lang('Gallery.title') . ': ' . album_title($album);

        $data = array_merge([
            'title'     => $title,
            'images'    => $model->getActive($album),
            'albums'    => $model->getAlbums(),
            'album'     => $album,
            'pageBase'  => $this->getPageBase(),
            'base_url'  => base_url(),
            'theme_url' => base_url('themes/' . $themePath),
            'themePath' => $themePath,
        ], $this->getLangData());

        // Modo parcial (si se incrusta desde una página)
        if ($this->embed) {
            return view('App\Modules\Gallery\Views\front\_grid', $data);
        }

        $page = $this->getModulePage();
        $translationSlugs = [];

        if ($page) {
            // ¿El álbum existe? Solo entonces el switcher apunta al mismo álbum
            // en el otro idioma; si no, apunta al índice de la galería.
            $albumNames = array_column($model->getAlbums(), 'album');
            $suffix     = in_array($album, $albumNames, true)
                ? '/album/' . urlencode($album)
                : '';

            $translationSlugs[$defaultLang] = $page['slug'] . $suffix;
            foreach ((new \App\Models\PageTranslationModel())->where('page_id', $page['id'])->findAll() as $t) {
                $translationSlugs[$t['lang']] = $t['slug'] . $suffix;
            }
        }

        // Página completa: MISMA plantilla que las páginas (page.php)
        return view('front/themes/' . $themePath . '/page', [
            'title'           => $title,
            'meta_desc'       => null,
            'page'            => [
                'title'   => $title,
                'content' => view('App\Modules\Gallery\Views\front\_grid', $data),
                'type'    => 'module',
            ],
            'base_url'        => base_url(),
            'theme_url'       => base_url('themes/' . $themePath),
            'themePath'       => $themePath,
            'template_slug'   => null,
            'template_fields' => [],
            'template_data'   => [],
            'current_lang'    => $currentLang,
            'default_lang'    => $defaultLang,
            'languages'       => $this->getLanguages(),
            'translation_slugs' => $translationSlugs,
        ]);
    }
}
