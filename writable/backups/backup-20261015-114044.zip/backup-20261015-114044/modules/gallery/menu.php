<?php

return [
    'label'   => 'Galería',
    'icon'    => 'bi-images',
    'segment' => 'gallery',
    'items'   => [
        [
            'label' => 'Todas las imágenes',
            'url'   => 'admin/gallery/images',
            'icon'  => 'bi-image',
        ],
        [
            'label' => 'Subir imágenes',
            'url'   => 'admin/gallery/images/create',
            'icon'  => 'bi-cloud-upload',
        ],
    ],
];