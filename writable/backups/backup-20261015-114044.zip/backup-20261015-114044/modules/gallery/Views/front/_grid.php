<div class="container py-5">

    <?php if (!empty($albums)): ?>
        <div class="d-flex justify-content-center gap-2 flex-wrap mb-4">
            <a href="<?= localized_url($pageBase) ?>" class="btn btn-sm btn-outline-secondary <?= empty($album) ? 'active' : '' ?>"><?= lang('Gallery.filter_all') ?></a>
            <?php foreach ($albums as $a): ?>
                <a href="<?= localized_url($pageBase . '/album/' . urlencode($a['album'])) ?>" class="btn btn-sm btn-outline-secondary <?= ($album == $a['album']) ? 'active' : '' ?> ms-1">
                    <?= esc(album_title($a['album'])) ?> (<?= $a['total'] ?>)
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (empty($images)): ?>
        <div class="alert alert-info">No hay imágenes en esta galería.</div>
    <?php else: ?>
        <div class="row g-3" id="galleryGrid">
            <?php foreach ($images as $img): ?>
                <div class="col-md-4 col-lg-3">
                    <a href="<?= base_url($img['file_path']) ?>" class="d-block gallery-item" data-fancybox="gallery" data-caption="<?= esc($img['title']) ?>">
                        <img src="<?= thumb_url($img['file_path']) ?>" class="card-img-top"
                            style="height:120px;object-fit:cover;" alt="<?= esc($img['alt_text'] ?? '') ?>">
                    </a>
                    <?php if ($img['title']): ?>
                        <p class="small text-muted text-center mt-1 mb-0 text-truncate"><?= esc($img['title']) ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css" />
<script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
<script>
    Fancybox.bind("[data-fancybox]", {});
</script>