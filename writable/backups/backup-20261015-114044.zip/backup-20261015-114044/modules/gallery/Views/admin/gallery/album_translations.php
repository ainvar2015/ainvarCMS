<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Traducir álbumes</h1>
    <a href="<?= base_url('admin/gallery/images') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Volver
    </a>
</div>

<form method="post" action="<?= base_url('admin/gallery/save-album-translations') ?>">
    <?= csrf_field() ?>
    <div class="card shadow-sm">
        <div class="card-body">
            <?php foreach ($albums as $a): $album = $a['album']; ?>
                <div class="border-bottom pb-3 mb-3">
                    <strong><?= esc($album) ?></strong>
                    <small class="text-muted">(<?= $a['total'] ?> imágenes)</small>
                    <?php foreach (active_languages() as $l): if ($l['code'] === default_lang()) continue; ?>
                        <div class="row g-2 mt-1 align-items-center">
                            <div class="col-auto" style="width:60px;">
                                <span class="badge bg-light text-dark"><?= strtoupper($l['code']) ?></span>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control form-control-sm"
                                    name="title[<?= esc($album) ?>][<?= $l['code'] ?>]"
                                    value="<?= esc($existing[$album][$l['code']] ?? '') ?>">
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
            <?php if (empty($albums)): ?>
                <div class="text-muted">No hay álbumes todavía.</div>
            <?php endif; ?>
        </div>
        <div class="card-footer text-end">
            <button class="btn btn-primary"><i class="bi bi-check-lg"></i> Guardar traducciones</button>
        </div>
    </div>
</form>
<?php $this->endSection() ?>