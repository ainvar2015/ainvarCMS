<?php $this->extend('admin/layout') ?>

<?php $this->section('css') ?>
<style>
    .drop-zone {
        border: 2px dashed #dee2e6;
        border-radius: 12px;
        padding: 50px 20px;
        text-align: center;
        background: #fff;
        transition: all .2s;
        cursor: pointer;
    }

    .drop-zone:hover,
    .drop-zone.drag-active {
        border-color: #0d6efd;
        background: #f0f7ff;
    }

    .drop-zone i {
        font-size: 2.5rem;
        color: #adb5bd;
        display: block;
        margin-bottom: 12px;
    }

    .preview-list {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 20px;
    }

    .preview-thumb {
        width: 80px;
        height: 80px;
        border-radius: 8px;
        object-fit: cover;
        border: 1px solid #dee2e6;
    }

    .progress-wrapper {
        display: none;
        margin-top: 20px;
    }

    .progress {
        height: 8px;
        border-radius: 4px;
    }

    .upload-status {
        font-size: .875rem;
        color: #6c757d;
        margin-top: 6px;
    }
</style>
<?php $this->endSection() ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Subir imágenes</h1>
    <a href="<?= base_url('admin/gallery/images') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Volver
    </a>
</div>

<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="card shadow-sm">
            <div class="card-body p-4">

                <div class="drop-zone" id="dropZone">
                    <i class="bi bi-cloud-arrow-up"></i>
                    <p class="mb-1 text-muted">Arrastra imágenes aquí o haz clic</p>
                    <small class="text-muted">JPG, PNG, GIF, WebP · Máx. 5 MB</small>
                    <input type="file" id="fileInput" name="images[]" multiple accept="image/*" class="d-none">
                </div>

                <div id="previewList" class="preview-list"></div>

                <div class="progress-wrapper" id="progressWrapper">
                    <div class="d-flex justify-content-between small text-muted mb-1">
                        <span id="progressText">Subiendo...</span>
                        <span id="progressPercent">0%</span>
                    </div>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped progress-bar-animated" id="progressBar" style="width:0%"></div>
                    </div>
                </div>

                <div class="mt-3">
                    <label class="form-label small fw-bold text-uppercase text-muted">Álbum</label>
                    <input type="text" id="albumInput" class="form-control form-control-sm mb-2" list="albumList" placeholder="General" value="General">
                    <datalist id="albumList">
                        <?php foreach ($albums as $a): ?>
                            <option value="<?= esc($a) ?>">
                            <?php endforeach; ?>
                    </datalist>
                </div>

                <div class="d-grid mt-3">
                    <button type="button" class="btn btn-primary" id="btnUpload" disabled>
                        <i class="bi bi-upload"></i> Subir
                    </button>
                </div>
                <div class="d-grid mt-2">
                    <button type="button" class="btn btn-outline-primary" id="btnFromLibrary">
                        <i class="bi bi-images"></i> Añadir de la biblioteca
                    </button>
                </div>
                <div id="resultMsg" class="mt-3"></div>

            </div>
        </div>
    </div>
</div>
<?php $this->endSection() ?>

<?php $this->section('js') ?>
<script>
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const previewList = document.getElementById('previewList');
    const btnUpload = document.getElementById('btnUpload');
    const progressWrapper = document.getElementById('progressWrapper');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    const progressPercent = document.getElementById('progressPercent');
    const resultMsg = document.getElementById('resultMsg');
    const albumInput = document.getElementById('albumInput');

    let selectedFiles = [];

    dropZone.addEventListener('click', () => fileInput.click());

    ['dragenter', 'dragover'].forEach(evt => {
        dropZone.addEventListener(evt, e => {
            e.preventDefault();
            dropZone.classList.add('drag-active');
        });
    });
    ['dragleave', 'drop'].forEach(evt => {
        dropZone.addEventListener(evt, e => {
            e.preventDefault();
            dropZone.classList.remove('drag-active');
        });
    });

    dropZone.addEventListener('drop', e => {
        handleFiles(e.dataTransfer.files);
    });

    fileInput.addEventListener('change', e => {
        handleFiles(e.target.files);
    });

    function handleFiles(fileList) {
        Array.from(fileList).forEach(file => {
            if (file.type.startsWith('image/') && !selectedFiles.some(f => f.name === file.name && f.size === file.size)) {
                selectedFiles.push(file);
            }
        });
        renderPreviews();
        btnUpload.disabled = selectedFiles.length === 0;
    }

    function renderPreviews() {
        previewList.innerHTML = '';
        selectedFiles.forEach(file => {
            const reader = new FileReader();
            reader.onload = e => {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.className = 'preview-thumb';
                img.title = file.name;
                previewList.appendChild(img);
            };
            reader.readAsDataURL(file);
        });
    }

    btnUpload.addEventListener('click', () => {
        if (!selectedFiles.length) return;

        const formData = new FormData();
        selectedFiles.forEach(f => formData.append('images[]', f));
        formData.append('album', albumInput.value);
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');

        const xhr = new XMLHttpRequest();

        xhr.upload.addEventListener('progress', e => {
            if (e.lengthComputable) {
                const pct = Math.round((e.loaded / e.total) * 100);
                progressWrapper.style.display = 'block';
                progressBar.style.width = pct + '%';
                progressPercent.textContent = pct + '%';
                progressText.textContent = pct < 100 ? 'Subiendo...' : 'Procesando...';
            }
        });

        xhr.addEventListener('load', () => {
            progressBar.classList.remove('progress-bar-animated');
            let data;
            try {
                data = JSON.parse(xhr.responseText);
            } catch (e) {
                data = {
                    success: false,
                    message: 'Error del servidor'
                };
            }

            if (data.success) {
                resultMsg.innerHTML = '<div class="alert alert-success"><i class="bi bi-check-circle"></i> ' + data.message + '</div>';
                selectedFiles = [];
                previewList.innerHTML = '';
                btnUpload.disabled = true;
                progressWrapper.style.display = 'none';
                setTimeout(() => window.location.href = '<?= base_url('admin/gallery/images') ?>', 1200);
            } else {
                resultMsg.innerHTML = '<div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i> ' + data.message + '</div>';
                progressWrapper.style.display = 'none';
            }
        });

        xhr.addEventListener('error', () => {
            resultMsg.innerHTML = '<div class="alert alert-danger">Error de red al subir.</div>';
            progressWrapper.style.display = 'none';
        });

        xhr.open('POST', '<?= base_url('admin/gallery/images/store') ?>');
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.send(formData);
    });

    document.getElementById('btnFromLibrary').addEventListener('click', () => {
        MediaPicker.open(function(url, alt, meta) {
            const fd = new FormData();
            fd.append('media_id', meta.id);
            fd.append('album', albumInput.value);
            fd.append('<?= csrf_token() ?>', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));

            fetch('<?= base_url('admin/gallery/images/store-from-library') ?>', {
                    method: 'POST',
                    body: fd,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                })
                .then(r => r.json())
                .then(data => {
                    resultMsg.innerHTML = '<div class="alert alert-' + (data.success ? 'success' : 'danger') + '">' + data.message + '</div>';
                    if (data.success) {
                        setTimeout(() => window.location.href = '<?= base_url('admin/gallery/images') ?>', 900);
                    }
                })
                .catch(err => {
                    resultMsg.innerHTML = '<div class="alert alert-danger">Error de red.</div>';
                });
        });
    });
</script>
<?php $this->endSection() ?>