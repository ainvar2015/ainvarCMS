<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Galería</h1>
    <a href="<?= base_url('admin/gallery/images/create') ?>" class="btn btn-primary">
        <i class="bi bi-cloud-upload"></i> Subir imágenes
    </a>
    <a href="<?= base_url('admin/gallery/album-translations') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-translate"></i> Traducir álbumes
    </a>
</div>

<form method="get" class="row g-2 mb-3">
    <div class="col-md-3">
        <select name="album" class="form-select" onchange="this.form.submit()">
            <option value="">Todos los álbumes</option>
            <?php foreach ($albums as $a): ?>
                <option value="<?= esc($a['album']) ?>" <?= ($albumFilter == $a['album']) ? 'selected' : '' ?>>
                    <?= esc($a['album']) ?> (<?= $a['total'] ?>)
                </option>
            <?php endforeach; ?>
        </select>
    </div>
</form>

<div class="row g-3">
    <?php foreach ($images as $img): ?>
        <div class="col-md-4 col-lg-3">
            <div class="card shadow-sm h-100">
                <img src="<?= base_url($img['file_path']) ?>" class="card-img-top" style="height:180px;object-fit:cover;">
                <div class="card-body">
                    <h6 class="card-title text-truncate"><?= esc($img['title']) ?></h6>
                    <?php if (!$img['active']): ?>
                        <span class="badge bg-secondary">Inactiva</span>
                    <?php endif; ?>
                    <p class="text-muted small mb-1"><?= esc($img['album']) ?></p>
                </div>
                <div class="card-footer text-end">
                    <form action="<?= base_url('admin/gallery/images/toggle/' . $img['id']) ?>" method="post" class="d-inline">
                        <?= csrf_field() ?>
                        <button type="submit"
                            class="btn btn-sm <?= $img['active'] ? 'btn-outline-secondary' : 'btn-outline-success' ?>"
                            title="<?= $img['active'] ? 'Desactivar (deja de verse en el sitio)' : 'Activar' ?>">
                            <i class="bi bi-eye<?= $img['active'] ? '' : '-slash' ?>"></i>
                        </button>
                    </form>
                    <form action="<?= base_url('admin/gallery/images/delete/' . $img['id']) ?>" method="post" class="d-inline"
                        onsubmit="return confirm('¿Eliminar esta imagen?')">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Eliminar esta Imagen">
                            <i class="bi bi-trash"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<?php $this->endSection() ?>