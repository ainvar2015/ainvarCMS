<?php

return [
    'title'      => 'Gallery',
    'filter_all' => 'All',
];