<?php

return [
    'title'      => 'Galería',
    'filter_all' => 'Todos',
];