<?php
// en
return [
    'submit'      => 'Send',
    'required'    => 'Fields marked with * are required.',
    'success'     => 'Your message has been sent.',
    'error'       => 'There was an error sending. Please check the fields.',
];