<?php

namespace App\Modules\Forms\Models;

use CodeIgniter\Model;

class FormEntryModel extends Model
{
    protected $table         = 'form_entries';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['form_id', 'data', 'read'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = '';   // la tabla no tiene updated_at
}