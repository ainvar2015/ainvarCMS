<?php

namespace App\Modules\Forms\Models;

use CodeIgniter\Model;

class FormFieldModel extends Model
{
    protected $table         = 'form_fields';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['form_id', 'label', 'name', 'type', 'options', 'required', 'sort_order'];
    protected $useTimestamps = false;

    public function getByForm(int $formId): array
    {
        return $this->where('form_id', $formId)->orderBy('sort_order', 'ASC')->findAll();
    }
}