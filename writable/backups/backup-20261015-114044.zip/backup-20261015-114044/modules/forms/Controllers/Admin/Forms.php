<?php

namespace App\Modules\Forms\Controllers\Admin;

use App\Controllers\Admin\ModuleController;
use App\Modules\Forms\Models\FormModel;
use App\Modules\Forms\Models\FormFieldModel;
use App\Modules\Forms\Models\FormEntryModel;

class Forms extends ModuleController
{
    protected $helpers = ['url', 'form', 'html'];

    protected function moduleNamespace(): string
    {
        return 'App\Modules\Forms';
    }

    public function index()
    {
        return $this->renderModule('forms/index', [
            'title' => 'Formularios',
            'forms' => (new FormModel())->orderBy('id', 'DESC')->findAll(),
        ]);
    }

    public function create()
    {
        return $this->renderModule('forms/form', [
            'title'  => 'Nuevo formulario',
            'f'      => null,
            'action' => base_url('admin/forms/store'),
            'fields' => [],
        ]);
    }

    public function edit($id)
    {
        $form = (new FormModel())->find($id);
        if (!$form) {
            return redirect()->to('/admin/forms')->with('error', 'Formulario no encontrado.');
        }
        return $this->renderModule('forms/form', [
            'title'  => 'Editar formulario',
            'f'      => $form,
            'action' => base_url('admin/forms/update/' . $id),
            'fields' => (new FormFieldModel())->getByForm((int) $id),
        ]);
    }

    public function store()
    {
        return $this->save(null);
    }

    public function update($id)
    {
        return $this->save((int) $id);
    }

    private function save(?int $id)
    {
        if (!$this->validate(['name' => 'required|min_length[2]|max_length[150]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $model = new FormModel();

        $slug = trim((string) $this->request->getPost('slug'));
        if ($slug === '') {
            $slug = slugify($this->request->getPost('name'));
        } else {
            $slug = slugify($slug);
        }
        // unicidad
        $base = $slug; $i = 1;
        while (true) {
            $b = $model->where('slug', $slug);
            if ($id) $b->where('id !=', $id);
            if (!$b->first()) break;
            $slug = $base . '-' . $i++;
        }

        $data = [
            'name'            => $this->request->getPost('name'),
            'slug'            => $slug,
            'email_to'        => $this->request->getPost('email_to') ?: null,
            'success_message' => $this->request->getPost('success_message') ?: null,
            'active'          => $this->request->getPost('active') ? 1 : 0,
        ];

        if ($id) {
            $model->update($id, $data);
            $formId = $id;
        } else {
            $model->insert($data);
            $formId = (int) $model->getInsertID();
        }

        // Sustituir campos por los enviados
        $fieldModel = new FormFieldModel();
        $fieldModel->where('form_id', $formId)->delete();

        $labels = (array) $this->request->getPost('field_label');
        $types  = (array) $this->request->getPost('field_type');
        $reqs   = (array) $this->request->getPost('field_required');
        $opts   = (array) $this->request->getPost('field_options');
        $names  = (array) $this->request->getPost('field_name');

        $sort = 0;
        foreach ($labels as $idx => $label) {
            $label = trim((string) $label);
            if ($label === '') continue;

            $type = in_array($types[$idx] ?? 'text', ['text', 'email', 'textarea', 'select', 'checkbox', 'number', 'date'], true)
                ? $types[$idx] : 'text';

            $name = trim((string) ($names[$idx] ?? ''));
            if ($name === '') {
                $name = slugify($label);
            }
            $name = str_replace('-', '_', $name);   // nombre usable en POST

            $fieldModel->insert([
                'form_id'    => $formId,
                'label'      => $label,
                'name'       => $name,
                'type'       => $type,
                'options'    => $type === 'select' ? trim((string) ($opts[$idx] ?? '')) : null,
                'required'   => !empty($reqs[$idx]) ? 1 : 0,
                'sort_order' => $sort++,
            ]);
        }

        return redirect()->to('/admin/forms')->with('success', 'Formulario guardado. Insértalo en una página con [formulario slug="' . $slug . '"].');
    }

    public function toggle($id)
    {
        $model = new FormModel();
        $row   = $model->find($id);
        if ($row) $model->update($id, ['active' => $row['active'] ? 0 : 1]);
        return redirect()->back();
    }

    public function delete($id)
    {
        $model = new FormModel();
        if (!$model->find($id)) {
            return redirect()->to('/admin/forms')->with('error', 'Formulario no encontrado.');
        }
        (new FormFieldModel())->where('form_id', $id)->delete();
        (new FormEntryModel())->where('form_id', $id)->delete();
        $model->delete($id);
        return redirect()->to('/admin/forms')->with('success', 'Formulario y sus envíos eliminados.');
    }

    // === Envíos ===

    public function entries($formId = null)
    {
        $formModel  = new FormModel();
        $entryModel = new FormEntryModel();

        $builder = $entryModel->orderBy('id', 'DESC');
        if ($formId) $builder->where('form_id', $formId);

        $forms = $formModel->orderBy('name', 'ASC')->findAll();

        return $this->renderModule('forms/entries', [
            'title'      => 'Envíos de formularios',
            'entries'    => $builder->findAll(),
            'forms'      => $forms,
            'activeForm' => $formId ? $formModel->find($formId) : null,
            'unread'     => $entryModel->where('read', 0)->countAllResults(),
        ]);
    }

    public function markRead($id)
    {
        $model = new FormEntryModel();
        $row   = $model->find($id);
        if ($row) $model->update($id, ['read' => 1]);
        return redirect()->back();
    }

    public function deleteEntry($id)
    {
        $model = new FormEntryModel();
        if ($model->find($id)) $model->delete($id);
        return redirect()->back()->with('success', 'Envío eliminado.');
    }
}