<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Envíos <?= $unread ? '<span class="badge bg-danger">' . $unread . ' sin leer</span>' : '' ?></h1>
    <a href="<?= base_url('admin/forms') ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Formularios</a>
</div>

<form method="get" class="mb-3" style="max-width:360px;">
    <select name="form" class="form-select" onchange="this.form.submit()">
        <option value="">Todos los formularios</option>
        <?php foreach ($forms as $fm): ?>
            <option value="<?= $fm['id'] ?>" <?= ($activeForm['id'] ?? '') == $fm['id'] ? 'selected' : '' ?>><?= esc($fm['name']) ?></option>
        <?php endforeach; ?>
    </select>
</form>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3"></th>
                    <th>Fecha</th>
                    <th>Formulario</th>
                    <th>Resumen</th>
                    <th class="text-end pe-3">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($entries)): ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">No hay envíos.</td></tr>
                <?php else: foreach ($entries as $e):
                    $data  = json_decode($e['data'] ?? '[]', true) ?: [];
                    $form  = null;
                    foreach ($forms as $fm) if ($fm['id'] == $e['form_id']) $form = $fm;
                    $first = '';
                    foreach ($data as $k => $v) { $first = is_array($v) ? $k : "$k: $v"; break; }
                ?>
                    <tr class="<?= $e['read'] ? '' : 'table-warning' ?>">
                        <td class="ps-3"><?= $e['read'] ? '<i class="bi bi-envelope-open text-muted"></i>' : '<i class="bi bi-envelope-fill text-primary"></i>' ?></td>
                        <td><?= esc($e['created_at']) ?></td>
                        <td><?= esc($form['name'] ?? '—') ?></td>
                        <td class="text-truncate" style="max-width:320px;"><?= esc($first) ?>…</td>
                        <td class="text-end pe-3">
                            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#entryModal<?= $e['id'] ?>">
                                <i class="bi bi-eye"></i>
                            </button>
                            <?php if (!$e['read']): ?>
                                <form action="<?= base_url('admin/forms/entries/read/' . $e['id']) ?>" method="post" class="d-inline"><?= csrf_field() ?>
                                    <button class="btn btn-sm btn-outline-success" title="Marcar leído"><i class="bi bi-check-lg"></i></button>
                                </form>
                            <?php endif; ?>
                            <form action="<?= base_url('admin/forms/entries/delete/' . $e['id']) ?>" method="post" class="d-inline"
                                onsubmit="return confirm('¿Eliminar este envío?')"><?= csrf_field() ?>
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>

                    <div class="modal fade" id="entryModal<?= $e['id'] ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Envío · <?= esc($form['name'] ?? '') ?></h5>
                                    <button class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p class="text-muted small"><?= esc($e['created_at']) ?></p>
                                    <table class="table table-sm">
                                        <?php foreach ($data as $k => $v): ?>
                                            <tr><th style="width:40%"><?= esc($k) ?></th><td><?= esc(is_array($v) ? implode(', ', $v) : $v) ?></td></tr>
                                        <?php endforeach; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $this->endSection() ?>