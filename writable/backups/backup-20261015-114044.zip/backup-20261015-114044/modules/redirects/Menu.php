<?php

return [
    'label'   => 'Redirecciones',
    'icon'    => 'bi-signpost-split',
    'segment' => 'redirects',
    'items'   => [
        ['url' => 'admin/redirects', 'label' => 'Redirecciones', 'icon' => 'bi-arrow-left-right'],
    ],
];