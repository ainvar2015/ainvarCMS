<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<?php $isEdit = !empty($r); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= esc($title) ?></h1>
    <a href="<?= base_url('admin/redirects') ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Volver</a>
</div>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger"><ul class="mb-0">
        <?php foreach (session()->getFlashdata('errors') as $e): ?><li><?= $e ?></li><?php endforeach; ?>
    </ul></div>
<?php endif; ?>
<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-8">
        <form action="<?= $action ?>" method="post">
            <?= csrf_field() ?>
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">URL antigua (desde)</label>
                        <div class="input-group">
                            <span class="input-group-text"><code><?= base_url() ?></code></span>
                            <input type="text" name="from_path" class="form-control" required
                                value="<?= old('from_path', $r['from_path'] ?? '') ?>"
                                placeholder="quienes-somos">
                        </div>
                        <div class="form-text">Ruta sin barra inicial. Para un idioma concreto, incluye el prefijo: <code>en/old-about</code>.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">URL nueva (hacia)</label>
                        <input type="text" name="to_path" class="form-control" required
                            value="<?= old('to_path', $r['to_path'] ?? '') ?>"
                            placeholder="<?= base_url('contacto') ?>">
                        <div class="form-text">Ruta interna (con o sin barra) o URL externa completa (https://…).</div>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Tipo</label>
                            <select name="code" class="form-select">
                                <option value="301" <?= old('code', $r['code'] ?? 301) == 301 ? 'selected' : '' ?>>301 — Permanente (SEO)</option>
                                <option value="302" <?= old('code', $r['code'] ?? 301) == 302 ? 'selected' : '' ?>>302 — Temporal</option>
                            </select>
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" name="active" value="1" id="act"
                                    <?= old('active', $r['active'] ?? 1) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="act">Activa</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-end">
                    <button class="btn btn-primary"><i class="bi bi-check-lg"></i> Guardar redirección</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $this->endSection() ?>